#pragma once

#include "../IslandGA/Error.h"
#include "../IslandGA/Evaluation.h"
#include "../IslandGA/EvaluationUtils.h"
#include "../IslandGA/RandUtils.h"
#include "../IslandGA/RealCoding.h"

#include <fstream>

using namespace std;

CEvaluation<CRealCoding> *pcRealEvaluation = nullptr;

extern "C" _declspec(dllexport) bool bRealEvaluationInit(char *pcSettingsPath)
{
	bool b_initialized = false;

	delete pcRealEvaluation;

	ifstream f_settings(pcSettingsPath);

	if (f_settings.is_open())
	{
		CError c_error;

		pcRealEvaluation = EvaluationUtils::pcGetEvaluation<CRealCoding>(&f_settings, &c_error);

		if (!c_error)
		{
			b_initialized = true;
		}//if (!c_error)

		f_settings.close();
	}//if (f_settings.is_open())

	RandUtils::iInit();

	return b_initialized;
}//extern "C" _declspec(dllexport) bool bRealEvaluationInit(char *pcSettingsPath)

extern "C" _declspec(dllexport) void vRealEvaluationClear()
{
	delete pcRealEvaluation;
	pcRealEvaluation = nullptr;
}//extern "C" _declspec(dllexport) void vRealEvaluationClear()

extern "C" _declspec(dllexport) int iRealEvaluationGetNumberOfDimensions()
{
	return (int)pcRealEvaluation->iGetNumberOfElements();
}//extern "C" _declspec(dllexport) int iRealEvaluationGetNumberOfDimensions()

extern "C" _declspec(dllexport) double dRealEvaluationGetMinValue(int iDimension)
{
	CRealCoding *pc_sample_fenotype = pcRealEvaluation->pcCreateSampleFenotype();

	double d_min_value = *(pc_sample_fenotype->pdGetMinValues() + iDimension);

	////TODO: HOTFIX
	//delete pc_sample_fenotype->pdGetMinValues();
	//delete pc_sample_fenotype->pdGetMaxValues();

	delete pc_sample_fenotype;

	return d_min_value;
}//extern "C" _declspec(dllexport) double dRealEvaluationGetMinValue(int iDimension)

extern "C" _declspec(dllexport) double dRealEvaluationGetMaxValue(int iDimension)
{
	CRealCoding *pc_sample_fenotype = pcRealEvaluation->pcCreateSampleFenotype();

	double d_max_value = *(pc_sample_fenotype->pdGetMaxValues() + iDimension);

	////TODO: HOTFIX
	//delete pc_sample_fenotype->pdGetMinValues();
	//delete pc_sample_fenotype->pdGetMaxValues();

	delete pc_sample_fenotype;

	return d_max_value;
}//extern "C" _declspec(dllexport) double dRealEvaluationGetMaxValue(int iDimension)

extern "C" _declspec(dllexport) double dRealEvaluationEvaluate(double *pdValues)
{
	CRealCoding *pc_sample_fenotype = pcRealEvaluation->pcCreateSampleFenotype();
	
	double *pd_values = new double[pc_sample_fenotype->iGetNumberOfDimensions()];

	for (uint16_t i = 0; i < pc_sample_fenotype->iGetNumberOfDimensions(); i++)
	{
		*(pd_values + i) = *(pdValues + i);
	}//for (uint16_t i = 0; i < pc_sample_fenotype->iGetNumberOfDimensions(); i++)

	CRealCoding *pc_fenotype = new CRealCoding(pc_sample_fenotype->iGetNumberOfDimensions(), pd_values, pc_sample_fenotype->pdGetMinValues(),
		pc_sample_fenotype->pdGetMaxValues(), pc_sample_fenotype->dGetEqualEpsilon());

	double d_fitness_value = pcRealEvaluation->dEvaluate(pc_fenotype);

	////TODO: HOTFIX
	//delete pc_sample_fenotype->pdGetMinValues();
	//delete pc_sample_fenotype->pdGetMaxValues();

	delete pc_sample_fenotype;
	delete pc_fenotype;

	return d_fitness_value;
}//extern "C" _declspec(dllexport) double dRealEvaluationGetMaxValue(int iDimension)

extern "C" _declspec(dllexport) double dRealEvaluationGetMaxFitnessValue()
{
	return pcRealEvaluation->dGetMaxValue();
}//extern "C" _declspec(dllexport) double dRealEvaluationGetMaxFitnessValue()