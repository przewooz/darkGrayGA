/*************************************************************************
* Project: Library of Evolutionary Algoriths
*************************************************************************
* Author: Changhe Li & Ming Yang
* Email: changhe.lw@google.com Or yangming0702@gmail.com
* Language: C++
*************************************************************************
*  This file is part of EAlib. This library is free software;
*  you can redistribute it and/or modify it under the terms of the
*  GNU General Public License as published by the Free Software
*  Foundation; either version 2, or (at your option) any later version.
*************************************************************************/
// Created: 21 September 2011
// Last modified:
#ifndef DEPOPULATION_H
#define DEPOPULATION_H

#include "../Population.h"
#include "../Optima.h"
#include "../../Problems/DOPs/DynamicProblem.h"

enum DEMutationStratgy{DE_rand_1, DE_best_1,DE_targetToBest_1,DE_best_2,DE_rand_2};
template <class T>
class DEPopulation: public Population<T>
{
    public:

    float  m_F, m_CR;

    DEMutationStratgy m_mutStrategy;


    DEPopulation():Population<T>(),m_F(0.5),m_CR(0.1),m_mutStrategy(DE_rand_1){

    }
    virtual ~DEPopulation(){}

    DEPopulation(const int rPopsize,bool mode=true):Population<T>(rPopsize,mode),m_F(0.5),m_CR(0.1),m_mutStrategy(DE_rand_1){

    }
	DEPopulation(DEPopulation<T> &s):Population<T>(s){
	    *this=s;

	}
	DEPopulation(Group<T> &g):Population<T>(g),m_F(0.5),m_CR(0.1),m_mutStrategy(DE_rand_1){

	}

	void setMutationStrategy(DEMutationStratgy rS){
        m_mutStrategy=rS;
	}

    DEPopulation & operator=( DEPopulation & s){
        if(this==&s) return *this;
        for(int i=0;i<this->m_popsize;i++){
            this->mp_pop[i]=s.mp_pop[i];

        }
        m_CR=s.m_CR;
        m_F=s.m_F;
        m_mutStrategy=s.m_mutStrategy;

        return *this;

    }
    void mutate(const int idx){
        int *a=new int[this->m_popsize];
        gInitializeRandomArray(a,this->m_popsize);
        int j=0;
        while(a[j]!=idx){j++;}
        int r1,r2,r3,r4,r5;
        r1=a[(j+1)%this->m_popsize];
        r2=a[(j+2)%this->m_popsize];
        r3=a[(j+3)%this->m_popsize];
        r4=a[(j+4)%this->m_popsize];
        r5=a[(j+5)%this->m_popsize];

        switch(m_mutStrategy){
            case DE_rand_1:
                this->mp_pop[idx].mutate(m_F,&this->mp_pop[r1].m_pself,&this->mp_pop[r2].m_pself,&this->mp_pop[r3].m_pself);
                break;
            case DE_best_1:
                this->mp_pop[idx].mutate(m_F,&this->m_best,&this->mp_pop[r1].m_pself,&this->mp_pop[r2].m_pself);
                break;
            case DE_targetToBest_1:
                this->mp_pop[idx].mutate(m_F,&this->mp_pop[idx].m_pself,&this->m_best,&this->mp_pop[idx].m_pself,&this->mp_pop[r1].m_pself,&this->mp_pop[r2].m_pself);
                break;
            case DE_best_2:
                this->mp_pop[idx].mutate(m_F,&this->m_best,&this->mp_pop[r1].m_pself,&this->mp_pop[r2].m_pself,&this->mp_pop[r3].m_pself,&this->mp_pop[r4].m_pself);
                break;
            case DE_rand_2:

                this->mp_pop[idx].mutate(m_F,&this->mp_pop[r1].m_pself,&this->mp_pop[r2].m_pself,&this->mp_pop[r3].m_pself,&this->mp_pop[r4].m_pself,&this->mp_pop[r5].m_pself);
                break;
        }
        delete []a;
    }

    int evolve(){
        if(this->m_popsize<1){
            return 0;
        }

        for(int i=0;i<this->m_popsize;i++){
            mutate(i);
            this->mp_pop[i].recombine(m_CR);
        }

        this->updateIDnIndex();
        for(int i=0;i<this->m_popsize;i++){
            this->mp_pop[i].select();

            if(this->mp_pop[i].m_pself>(this->m_best)) {
                this->m_best=this->mp_pop[i].m_pself;
            }
			if(gIsTerminate()) return 0;
            if(gIsDynamicAlg()&&Global::gp_problem->getEvaluations()%(dynamic_cast<DynamicProblem*>(Global::gp_problem)->getChangeFre())==0){
                if(dynamic_cast<DynamicProblem*> (Global::gp_problem)->getFlagDimensionChange()) return 2;

                this->updateMemoryAll();
                return 1;
            }

        }
        this->m_evoNum++;
        return 0;
    }

    void setParmeter(const float cr, const float f){
        m_CR=cr;
        m_F=f;
    }

};

#endif // DEPOPULATION_H
