/*************************************************************************
* Project: Library of Evolutionary Algoriths
*************************************************************************
* Author: Changhe Li & Ming Yang
* Email: changhe.lw@google.com Or yangming0702@gmail.com
* Language: C++
*************************************************************************
*  This file is part of EAlib. This library is free software;
*  you can redistribute it and/or modify it under the terms of the
*  GNU General Public License as published by the Free Software
*  Foundation; either version 2, or (at your option) any later version.
*************************************************************************/
// Created: 21 September 2011
// Last modified:
#ifndef PARTICLELBEST_H
#define PARTICLELBEST_H

#include "../Particle.h"

class ParticleLbest: public Particle
{
    public:
        ParticleLbest();
        virtual ~ParticleLbest();
        ParticleLbest(ParticleLbest &p);
        ParticleLbest & operator =( ParticleLbest &p);
        void move2007( Chromosome & lbest,double w, double c1, double c2, Chromosome *gbest=0,bool clamping=false);

};

#endif // PARTICLELBEST_H
