#include "BinaryEvaluation.h"

#include "FloatCommandParam.h"
#include "StringCommandParam.h"
#include "UIntCommandParam.h"

#include <atlstr.h>
#include <cfloat>
#include <functional>


void CBinaryCyclicFenotypeEvaluation::v_prepare_evaluation_fenotype(CBinaryCoding *pcFenotype, uint16_t iShift)
{
	uint16_t i_index_without_shift;

	for (uint16_t i = 0; i < i_number_of_elements; i++)
	{
		i_index_without_shift = (i + i_cyclic_shift) % i_number_of_elements;
		*(pc_evaluation_fenotype->piGetBits() + i + iShift) = *(pcFenotype->piGetBits() + i_index_without_shift + iShift);
	}//for (uint16_t i = 0; i < i_number_of_elements; i++)
}//void CBinaryCyclicFenotypeEvaluation::v_prepare_evaluation_fenotype(CBinaryCoding *pcFenotype, uint16_t iShift)


CBinaryEvaluation::CBinaryEvaluation()
	: CEvaluation<CBinaryCoding>()
{

}//CBinaryEvaluation::CBinaryEvaluation()

CBinaryEvaluation::CBinaryEvaluation(uint16_t iNumberOfElements, double dMaxValue)
	: CEvaluation<CBinaryCoding>(iNumberOfElements, dMaxValue)
{

}//CBinaryEvaluation::CBinaryEvaluation(uint16_t iNumberOfElements, double dMaxValue)

CBinaryCoding * CBinaryEvaluation::pcCreateSampleFenotype()
{
	return new CBinaryCoding(i_number_of_elements);
}//CBinaryCoding * CBinaryEvaluation::pcCreateSampleFenotype()


CBinaryCooperativeCoevolutionEvaluation::CBinaryCooperativeCoevolutionEvaluation(CEvaluation<CBinaryCoding> *pcActualEvaluation)
	: CCooperativeCoevolutionEvaluation<CBinaryCoding>(pcActualEvaluation)
{

}//CBinaryCooperativeCoevolutionEvaluation::CBinaryCooperativeCoevolutionEvaluation(CEvaluation<CBinaryCoding> *pcActualEvaluation)

void CBinaryCooperativeCoevolutionEvaluation::v_prepare_evaluation_fenotype(CBinaryCoding *pcFenotype)
{
	for (uint16_t i = 0; i < pc_complementary_fenotype->iGetNumberOfBits(); i++)
	{
		*(pc_evaluation_fenotype->piGetBits() + i) = *(pc_complementary_fenotype->piGetBits() + i);
	}//for (uint16_t i = 0; i < pc_complementary_fenotype->iGetNumberOfBits(); i++)

	for (uint16_t i = 0; i < i_number_of_elements; i++)
	{
		*(pc_evaluation_fenotype->piGetBits() + v_genes_indexes.at(i)) = *(pcFenotype->piGetBits() + i);
	}//for (uint16_t i = 0; i < i_number_of_elements; i++)
}//void CBinaryCooperativeCoevolutionEvaluation::v_prepare_evaluation_fenotype(CBinaryCoding *pcFenotype)


CError CBinaryFileConfigEvaluation::eConfigure(istream *psSettings)
{
	CError c_error = CEvaluation<CBinaryCoding>::eConfigure(psSettings);

	if (!c_error)
	{
		CStringCommandParam p_config_file_path(EVALUATION_ARGUMENT_CONFIG_FILE_PATH);
		CString s_config_file_path = p_config_file_path.sGetValue(psSettings, &c_error);

		if (!c_error)
		{
			FILE *pf_config = fopen(s_config_file_path, "r");

			if (pf_config)
			{
				c_error = e_init(pf_config);
			}//if (pf_config)
			else
			{
				c_error.vSetError(CError::iERROR_CODE_SYSTEM_FILE_NOT_FOUND, s_config_file_path);
			}//else if (pf_config)
		}//if (!c_error)
	}//if (!c_error)

	return c_error;
}//CError CBinaryFileConfigEvaluation::eConfigure(istream *psSettings)


CBinaryDeceptiveEvaluation::CBinaryDeceptiveEvaluation()
{
	pc_deceptive_function = nullptr;
}//CBinaryDeceptiveEvaluation::CBinaryDeceptiveEvaluation()

CBinaryDeceptiveEvaluation::CBinaryDeceptiveEvaluation(FILE *pfConfig, CError *pcError)
{
	*pcError = e_init(pfConfig);
}//CBinaryDeceptiveEvaluation::CBinaryDeceptiveEvaluation(FILE *pfConfig, CError *pcError)

CBinaryDeceptiveEvaluation::~CBinaryDeceptiveEvaluation()
{
	delete pc_deceptive_function;
}//CBinaryDeceptiveEvaluation::~CBinaryDeceptiveEvaluation()

CError CBinaryDeceptiveEvaluation::e_init(FILE *pfConfig)
{
	delete pc_deceptive_function;
	pc_deceptive_function = nullptr;
	
	CError c_error = eLoadSingleCompProblem(pfConfig, &pc_deceptive_function);

	if (pc_deceptive_function)
	{
		i_number_of_elements = (uint16_t)pc_deceptive_function->iGetBitLength();
		d_max_value = pc_deceptive_function->dGetMaxFuncVal();
	}//if (pc_deceptive_function)

	fclose(pfConfig);

	return c_error;
}//CError CBinaryDeceptiveEvaluation::e_init(FILE *pfConfig)

double CBinaryDeceptiveEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)
{
	return pc_deceptive_function->dGetFuncValue(iShift, pcFenotype->piGetBits(), pcFenotype->iGetNumberOfBits());
}//double CBinaryDeceptiveEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)



CBinaryDeceptiveConcatenationEvaluation::CBinaryDeceptiveConcatenationEvaluation()
{
	pc_deceptive_concatenation_function = nullptr;
}//CBinaryDeceptiveConcatenationEvaluation::CBinaryDeceptiveConcatenationEvaluation()

CBinaryDeceptiveConcatenationEvaluation::CBinaryDeceptiveConcatenationEvaluation(FILE *pfConfig, CError *pcError)
{
	*pcError = e_init(pfConfig);
}//CBinaryDeceptiveConcatenationEvaluation::CBinaryDeceptiveConcatenationEvaluation(FILE *pfConfig, CError *pcError)

CBinaryDeceptiveConcatenationEvaluation::~CBinaryDeceptiveConcatenationEvaluation()
{
	delete pc_deceptive_concatenation_function;
}//CBinaryDeceptiveConcatenationEvaluation::~CBinaryDeceptiveConcatenationEvaluation()

CError CBinaryDeceptiveConcatenationEvaluation::e_init(FILE *pfConfig)
{
	delete pc_deceptive_concatenation_function;
	pc_deceptive_concatenation_function = new CConcatCompProblem();
	
	CError c_error = pc_deceptive_concatenation_function->eLoad(pfConfig);

	if (!c_error)
	{
		i_number_of_elements = (uint16_t)pc_deceptive_concatenation_function->iGetProblemBitLength();
		d_max_value = pc_deceptive_concatenation_function->dGetMaxFuncVal();
	}//if (!c_error)

	fclose(pfConfig);

	return c_error;
}//CError CBinaryDeceptiveConcatenationEvaluation::e_init(FILE *pfConfig)

double CBinaryDeceptiveConcatenationEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)
{
	double d_fitness_value;
	pc_deceptive_concatenation_function->eGetFuncValue(pcFenotype->piGetBits(), pcFenotype->iGetNumberOfBits(), &d_fitness_value);

	return d_fitness_value;
}//void CBinaryDeceptiveConcatenationEvaluation::vEvaluate(CBinaryCoding *pcFenotype, double *pdFitnessValue)


void  CBinaryDeceptiveConcatenationEvaluation::v_get_true_gene_dependencies(vector<vector<int>>  *pvDependentGenes)
{
	pc_deceptive_concatenation_function->vGetTrueGeneDependencies(pvDependentGenes);
}//vector<int>  CBinaryDeceptiveConcatenationEvaluation::vecGetTrueGeneDependencies(int  iGeneIndex)



CError CBinaryDeceptiveConcatenationEvaluation::eReport(FILE *pfReport)
{
	return pc_deceptive_concatenation_function->eCreateReport(pfReport);
}//CError CBinaryDeceptiveConcatenationEvaluation::eReport(FILE *pfReport)





CBinaryKnapsackEvaluation::CBinaryKnapsackEvaluation()
{
	
}//CBinaryKnapsackEvaluation::CBinaryKnapsackEvaluation()

CBinaryKnapsackEvaluation::CBinaryKnapsackEvaluation(FILE *pfConfig, CError *pcError)
{
	*pcError = e_init(pfConfig);
}//CBinaryKnapsackEvaluation::CBinaryKnapsackEvaluation(uint16_t iNumberOfElements, double dCapacity, double *pdValues, double *pdWeights)

CError CBinaryKnapsackEvaluation::e_init(FILE *pfConfig)
{
	CError c_error = c_knapsack.eLoadSettings(pfConfig);

	if (!c_error)
	{
		i_number_of_elements = (uint16_t)c_knapsack.iGetBitLength();
		d_max_value = c_knapsack.dGetMaxFuncVal();
	}//if (!c_error)

	fclose(pfConfig);

	return c_error;
}//CError CBinaryKnapsackEvaluation::e_init(FILE *pfConfig)

double CBinaryKnapsackEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)
{
	//c_knapsack.bRepairGreedy(iShift, pcFenotype->piGetBits(), pcFenotype->iGetNumberOfBits());
	return c_knapsack.dGetFuncValue(iShift, pcFenotype->piGetBits(), pcFenotype->iGetNumberOfBits());
}//double CBinaryKnapsackEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)


CBinaryMaxSatEvaluation::CBinaryMaxSatEvaluation()
{

}//CBinaryMaxSatEvaluation::CBinaryMaxSatEvaluation()

CBinaryMaxSatEvaluation::CBinaryMaxSatEvaluation(FILE *pfConfig, CError *pcError)
{
	*pcError = e_init(pfConfig);
}//CBinaryMaxSatEvaluation::CBinaryMaxSatEvaluation(FILE *pfConfig, CError *pcError)

CError CBinaryMaxSatEvaluation::e_init(FILE *pfConfig)
{
	CError c_error = c_max_sat.eLoadSettings(pfConfig);

	if (!c_error)
	{
		i_number_of_elements = (uint16_t)c_max_sat.iGetBitLength();
		d_max_value = c_max_sat.dGetMaxFuncVal();
	}//if (!c_error)

	fclose(pfConfig);

	return c_error;
}//CError CBinaryMaxSatEvaluation::e_init(FILE *pfConfig)

double CBinaryMaxSatEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)
{
	return c_max_sat.dGetFuncValue(iShift, pcFenotype->piGetBits(), pcFenotype->iGetNumberOfBits());
}//double CBinaryMaxSatEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)


CBinaryDeceptiveStepTrapEvaluation::CBinaryDeceptiveStepTrapEvaluation()
{
	d_max_value = 1.0;
}//CBinaryDeceptiveStepTrapEvaluation::CBinaryDeceptiveStepTrapEvaluation()

CError CBinaryDeceptiveStepTrapEvaluation::eConfigure(istream *psSettings)
{
	CError c_error = CBinaryEvaluation::eConfigure(psSettings);

	if (!c_error)
	{
		CUIntCommandParam p_number_of_elements(EVALUATION_ARGUMENT_NUMBER_OF_ELEMENTS, 1, UINT16_MAX);
		i_number_of_elements = p_number_of_elements.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		CUIntCommandParam p_trap_size(EVALUATION_BINARY_DECEPTIVE_STEP_TRAP_ARGUMENT_TRAP_SIZE, 1, UINT16_MAX);
		i_trap_size = p_trap_size.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		CUIntCommandParam p_step_size(EVALUATION_BINARY_DECEPTIVE_STEP_TRAP_ARGUMENT_STEP_SIZE, 1, i_trap_size);
		i_step_size = p_step_size.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		i_offset = (i_trap_size - i_step_size) % i_step_size;
	}//if (!c_error)

	return c_error;
}//CError CBinaryDeceptiveStepTrapEvaluation::eConfigure(istream *psSettings)

double CBinaryDeceptiveStepTrapEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)
{
	uint16_t i_total = 0;

	uint16_t i_trap_maximum = (i_offset + i_trap_size) / i_step_size;

	uint16_t i_partial;

	for (uint16_t i = 0; i < i_number_of_elements; i += i_trap_size)
	{
		i_partial = 0;

		for (uint16_t j = i; j < i + i_trap_size; j++)
		{
			i_partial += (uint16_t)(*(pcFenotype->piGetBits() + j + iShift));
		}//for (uint16_t j = 0; j < i + i_trap_size; j++)

		if (i_partial < i_trap_size)
		{
			i_partial = i_trap_size - i_partial - 1;
		}//if (i_partial < i_trap_size)

		i_total += (i_offset + i_partial) / i_step_size;
	}//for (uint16_t i = 0; i < i_number_of_elements; i += i_trap_size)

	return (double)(i_total * i_trap_size) / (double)(i_number_of_elements * i_trap_maximum);
}//double CBinaryDeceptiveStepTrapEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)


CBinaryNearestNeighborNKEvaluation::CBinaryNearestNeighborNKEvaluation()
{
	d_max_value = 1.0;
	pc_native_nearest_neighbor_nk = nullptr;
}//CBinaryNearestNeighborNKEvaluation::CBinaryNearestNeighborNKEvaluation()

CBinaryNearestNeighborNKEvaluation::~CBinaryNearestNeighborNKEvaluation()
{
	v_clear();
}//CBinaryNearestNeighborNKEvaluation::~CBinaryNearestNeighborNKEvaluation()

CError CBinaryNearestNeighborNKEvaluation::eConfigure(istream *psSettings)
{
	v_clear();

	CError c_error = CBinaryEvaluation::eConfigure(psSettings);

	if (!c_error)
	{
		CUIntCommandParam p_number_of_elements(EVALUATION_ARGUMENT_NUMBER_OF_ELEMENTS, 1, UINT16_MAX);
		i_number_of_elements = (uint16_t)p_number_of_elements.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		CUIntCommandParam p_problem_seed(EVALUATION_BINARY_P3_ARGUMENT_PROBLEM_SEED);
		i_problem_seed = p_problem_seed.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		CUIntCommandParam p_precision(EVALUATION_BINARY_P3_ARGUMENT_PRECISION);
		i_precision = p_precision.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		CUIntCommandParam p_k(EVALUATION_BINARY_NEAREST_NEIGHBOR_NK_ARGUMENT_K, 1, UINT16_MAX);
		i_k = (uint16_t)p_k.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		Configuration c_config;

		c_config.set("length", (int)i_number_of_elements);
		
		c_config.set("problem_seed", (int)i_problem_seed);
		
		c_config.set("precision", (int)i_precision);
		c_config.set("k", (int)i_k);

		c_config.set("problem_folder", string(""));

		pc_native_nearest_neighbor_nk = new NearestNeighborNK(c_config, 0);

		v_native_solution.resize(i_number_of_elements);
	}//if (!c_error)

	return c_error;
}//CError CBinaryNearestNeighborNKEvaluation::eConfigure(istream *psSettings)

double CBinaryNearestNeighborNKEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)
{
	for (uint16_t i = 0; i < pcFenotype->iGetNumberOfBits(); i++)
	{
		v_native_solution.at(i) = *(pcFenotype->piGetBits() + i + iShift) == 1;
	}//for (uint16_t i = 0; i < pcFenotype->iGetNumberOfBits(); i++)

	return (double)pc_native_nearest_neighbor_nk->evaluate(v_native_solution);
}//double CBinaryNearestNeighborNKEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)


double CBinaryNearestNeighborNKEvaluation::d_evaluate_double(CBinaryCoding *pcFenotype, uint16_t iShift)
{
	for (uint16_t i = 0; i < pcFenotype->iGetNumberOfBits(); i++)
	{
		v_native_solution.at(i) = *(pcFenotype->piGetBits() + i + iShift) == 1;
	}//for (uint16_t i = 0; i < pcFenotype->iGetNumberOfBits(); i++)

	return (double)pc_native_nearest_neighbor_nk->evaluateDouble(v_native_solution);
}//double CBinaryNearestNeighborNKEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)



void CBinaryNearestNeighborNKEvaluation::v_clear()
{
	delete pc_native_nearest_neighbor_nk;
	pc_native_nearest_neighbor_nk = nullptr;
}//void CBinaryNearestNeighborNKEvaluation::v_clear()


CBinaryIsingSpinGlassEvaluation::CBinaryIsingSpinGlassEvaluation()
{
	d_max_value = 1.0;
	pc_native_ising_spin_glass = nullptr;
}//CBinaryIsingSpinGlassEvaluation::CBinaryIsingSpinGlassEvaluation()

CBinaryIsingSpinGlassEvaluation::~CBinaryIsingSpinGlassEvaluation()
{
	v_clear();
}//CBinaryIsingSpinGlassEvaluation::~CBinaryIsingSpinGlassEvaluation()

CError CBinaryIsingSpinGlassEvaluation::eConfigure(istream *psSettings)
{
	v_clear();

	CError c_error = CBinaryEvaluation::eConfigure(psSettings);

	if (!c_error)
	{
		CUIntCommandParam p_number_of_elements(EVALUATION_ARGUMENT_NUMBER_OF_ELEMENTS, 1, UINT16_MAX);
		i_number_of_elements = (uint16_t)p_number_of_elements.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	uint32_t i_problem_seed = 0;

	if (!c_error)
	{
		CUIntCommandParam p_problem_seed(EVALUATION_BINARY_P3_ARGUMENT_PROBLEM_SEED);
		i_problem_seed = p_problem_seed.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		Configuration c_config;

		c_config.set("length", (int)i_number_of_elements);
		c_config.set("problem_seed", (int)i_problem_seed);
		c_config.set("precision", 65536);
		c_config.set("ising_type", string("pm"));
		c_config.set("problem_folder", string(""));

		pc_native_ising_spin_glass = new IsingSpinGlass(c_config, 0);

		v_native_solution.resize(i_number_of_elements);
	}//if (!c_error)

	return c_error;
}//CError CBinaryIsingSpinGlassEvaluation::eConfigure(istream *psSettings)

double CBinaryIsingSpinGlassEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)
{
	for (uint16_t i = 0; i < pcFenotype->iGetNumberOfBits(); i++)
	{
		v_native_solution.at(i) = *(pcFenotype->piGetBits() + i + iShift) == 1;
	}//for (uint16_t i = 0; i < pcFenotype->iGetNumberOfBits(); i++)

	return (double)pc_native_ising_spin_glass->evaluate(v_native_solution);
}//double CBinaryIsingSpinGlassEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)

void CBinaryIsingSpinGlassEvaluation::v_clear()
{
	delete pc_native_ising_spin_glass;
	pc_native_ising_spin_glass = nullptr;
}//void CBinaryIsingSpinGlassEvaluation::v_clear()




CBinaryLeading1::CBinaryLeading1()
{
	
}//CBinaryLeading1::CBinaryLeading1()


CBinaryLeading1::~CBinaryLeading1()
{

}//CBinaryLeading1::~CBinaryLeading1()


CError CBinaryLeading1::eConfigure(istream *psSettings)
{
	CError c_err = CBinaryEvaluation::eConfigure(psSettings);

	CUIntCommandParam p_number_of_elements(EVALUATION_ARGUMENT_NUMBER_OF_ELEMENTS, 1, UINT16_MAX);
	i_number_of_elements = (uint16_t)p_number_of_elements.iGetValue(psSettings, &c_err);

	d_max_value = 1.0;

	return(c_err);
}//CError CBinaryLeading1::eConfigure(istream *psSettings)



double CBinaryLeading1::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)
{
	int  i_leading_1;
	bool  b_first_0;

	i_leading_1 = 0;
	b_first_0 = false;
	for (uint16_t ii = 0; ii < pcFenotype->iGetNumberOfBits(); ii++)
	{
		if (pcFenotype->piGetBits()[ii] == 0)
		{
			b_first_0 = true;
		}//if (pcFenotype->piGetBits()[ii] == 0)
		else
		{
			if (b_first_0 == false)  i_leading_1++;
		}//else if (pcFenotype->piGetBits()[ii] == 0)
	}//for (uint16_t ii = 0; ii < pcFenotype->iGetNumberOfBits(); ii++)
	
	double  d_result;
	d_result = i_leading_1;
	d_result = d_result / pcFenotype->iGetNumberOfBits();


	return(d_result);
}//double CBinaryLeading1::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)





CBinaryJumpFunc::CBinaryJumpFunc()
{
	i_jump_size = 0;
}//CBinaryJumpFunc::CBinaryJumpFunc()


CBinaryJumpFunc::~CBinaryJumpFunc()
{

}//CBinaryJumpFunc::~CBinaryJumpFunc()


CError CBinaryJumpFunc::eConfigure(istream *psSettings)
{
	CError c_err = CBinaryEvaluation::eConfigure(psSettings);

	CUIntCommandParam p_number_of_elements(EVALUATION_ARGUMENT_NUMBER_OF_ELEMENTS, 1, UINT16_MAX);
	i_number_of_elements = (uint16_t)p_number_of_elements.iGetValue(psSettings, &c_err);

	CUIntCommandParam p_jump_size(EVALUATION_ARGUMENT_JUMP_FUNC_JUM_SIZE, 1, UINT16_MAX);
	i_jump_size = (uint16_t)p_jump_size.iGetValue(psSettings, &c_err);
	
	d_max_value = 1.0;

	return(c_err);
}//CError CBinaryJumpFunc::eConfigure(istream *psSettings)




//definition from https://cs.adelaide.edu.au/users/markus/pub/2018gecco-escaping-slides.pdf
double CBinaryJumpFunc::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)
{
	double  d_result;

	int  i_unitation;
	i_unitation = pcFenotype->iGetUnitation();

	if ( (i_unitation < i_number_of_elements - i_jump_size)|| (i_unitation == i_number_of_elements) )
	{
		d_result = i_unitation + i_jump_size;
	}//if ( (i_unitation < i_number_of_elements - i_jump_size)|| (i_unitation == i_number_of_elements) )
	else
	{
		d_result = i_number_of_elements - i_unitation;
	}//else  if ( (i_unitation < i_number_of_elements - i_jump_size)|| (i_unitation == i_number_of_elements) )

	d_result = d_result / (i_unitation + i_jump_size);

	return(0);
}//double CBinaryJumpFunc::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)










CBinaryMax3SatEvaluation::CBinaryMax3SatEvaluation()
{
	d_max_value = 1.0;
	pc_native_max_sat = nullptr;
}//CBinaryMax3SatEvaluation::CBinaryMax3SatEvaluation()

CBinaryMax3SatEvaluation::~CBinaryMax3SatEvaluation()
{
	v_clear();
}//CBinaryMax3SatEvaluation::~CBinaryMax3SatEvaluation()

CError CBinaryMax3SatEvaluation::eConfigure(istream *psSettings)
{
	v_clear();

	CError c_error = CBinaryEvaluation::eConfigure(psSettings);

	if (!c_error)
	{
		CUIntCommandParam p_number_of_elements(EVALUATION_ARGUMENT_NUMBER_OF_ELEMENTS, 1, UINT16_MAX);
		i_number_of_elements = (uint16_t)p_number_of_elements.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	uint32_t i_problem_seed = 0;

	if (!c_error)
	{
		CUIntCommandParam p_problem_seed(EVALUATION_BINARY_P3_ARGUMENT_PROBLEM_SEED);
		i_problem_seed = p_problem_seed.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	float f_clause_ratio = 0;

	if (!c_error)
	{
		CFloatCommandParam p_clause_ratio(EVALUATION_BINARY_MAX_3_SAT_ARGUMENT_CLAUSE_RATIO, 0, FLT_MAX);
		f_clause_ratio = p_clause_ratio.fGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		Configuration c_config;

		c_config.set("length", (int)i_number_of_elements);
		c_config.set("problem_seed", (int)i_problem_seed);
		c_config.set("precision", 65536);
		c_config.set("clause_ratio", f_clause_ratio);

		pc_native_max_sat = new MAXSAT(c_config, 0);

		v_native_solution.resize(i_number_of_elements);
	}//if (!c_error)

	return c_error;
}//CError CBinaryMax3SatEvaluation::eConfigure(istream *psSettings)

void CBinaryMax3SatEvaluation::v_clear()
{
	delete pc_native_max_sat;
	pc_native_max_sat = nullptr;
}//void CBinaryMax3SatEvaluation::v_clear()

double CBinaryMax3SatEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)
{
	for (uint16_t i = 0; i < pcFenotype->iGetNumberOfBits(); i++)
	{
		v_native_solution.at(i) = *(pcFenotype->piGetBits() + i + iShift) == 1;
	}//for (uint16_t i = 0; i < pcFenotype->iGetNumberOfBits(); i++)

	return (double)pc_native_max_sat->evaluate(v_native_solution);
}//double CBinaryMax3SatEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)


CBinaryDiscretizedRastriginEvaluation::CBinaryDiscretizedRastriginEvaluation()
{
	d_max_value = 1.0;
	pc_native_rastrigin = nullptr;
}//CBinaryDiscretizedRastriginEvaluation::CBinaryDiscretizedRastriginEvaluation()

CBinaryDiscretizedRastriginEvaluation::~CBinaryDiscretizedRastriginEvaluation()
{
	v_clear();
}//CBinaryDiscretizedRastriginEvaluation::~CBinaryDiscretizedRastriginEvaluation()

CError CBinaryDiscretizedRastriginEvaluation::eConfigure(istream *psSettings)
{
	v_clear();

	CError c_error = CBinaryEvaluation::eConfigure(psSettings);

	if (!c_error)
	{
		CUIntCommandParam p_number_of_elements(EVALUATION_ARGUMENT_NUMBER_OF_ELEMENTS, 1, UINT16_MAX);
		i_number_of_elements = p_number_of_elements.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		Configuration c_config;

		c_config.set("length", (int)i_number_of_elements);
		c_config.set("precision", 65536);
		c_config.set("bits_per_float", 10);

		pc_native_rastrigin = new Rastrigin(c_config, 0);

		v_native_solution.resize(i_number_of_elements);
	}//if (!c_error)

	return c_error;
}//CError CBinaryDiscretizedRastriginEvaluation::eConfigure(istream *psSettings)

double CBinaryDiscretizedRastriginEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)
{
	for (uint16_t i = 0; i < pcFenotype->iGetNumberOfBits(); i++)
	{
		v_native_solution.at(i) = *(pcFenotype->piGetBits() + i + iShift) == 1;
	}//for (uint16_t i = 0; i < pcFenotype->iGetNumberOfBits(); i++)

	return (double)pc_native_rastrigin->evaluate(v_native_solution);
}//double CBinaryDiscretizedRastriginEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)

void CBinaryDiscretizedRastriginEvaluation::v_clear()
{
	delete pc_native_rastrigin;
	pc_native_rastrigin = nullptr;
}//void CBinaryDiscretizedRastriginEvaluation::v_clear()


CBinaryDiscretizedRosenbrockEvaluation::CBinaryDiscretizedRosenbrockEvaluation()
{
	d_max_value = 1.0;
	pc_native_rosenbrock = nullptr;
}//CBinaryDiscretizedRosenbrockEvaluation::CBinaryDiscretizedRosenbrockEvaluation()

CBinaryDiscretizedRosenbrockEvaluation::~CBinaryDiscretizedRosenbrockEvaluation()
{
	v_clear();
}//CBinaryDiscretizedRosenbrockEvaluation::~CBinaryDiscretizedRosenbrockEvaluation()

CError CBinaryDiscretizedRosenbrockEvaluation::eConfigure(istream *psSettings)
{
	v_clear();

	CError c_error = CBinaryEvaluation::eConfigure(psSettings);

	if (!c_error)
	{
		CUIntCommandParam p_number_of_elements(EVALUATION_ARGUMENT_NUMBER_OF_ELEMENTS, 1, UINT16_MAX);
		i_number_of_elements = (uint16_t)p_number_of_elements.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	uint8_t i_bits_per_float = 0;

	if (!c_error)
	{
		CUIntCommandParam p_bits_per_float(EVALUATION_BINARY_P3_ARGUMENT_BITS_PER_FLOAT, 1, UINT8_MAX);
		i_bits_per_float = (uint8_t)p_bits_per_float.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		Configuration c_config;

		c_config.set("length", (int)i_number_of_elements);
		c_config.set("precision", 65536);
		c_config.set("bits_per_float", (int)i_bits_per_float);

		pc_native_rosenbrock = new Rosenbrock(c_config, 0);

		v_native_solution.resize(i_number_of_elements);
	}//if (!c_error)

	return c_error;
}//CError CBinaryDiscretizedRosenbrockEvaluation::eConfigure(istream *psSettings)

double CBinaryDiscretizedRosenbrockEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)
{
	for (uint16_t i = 0; i < pcFenotype->iGetNumberOfBits(); i++)
	{
		v_native_solution.at(i) = *(pcFenotype->piGetBits() + i + iShift) == 1;
	}//for (uint16_t i = 0; i < pcFenotype->iGetNumberOfBits(); i++)

	return (double)pc_native_rosenbrock->evaluate(v_native_solution);
}//double CBinaryDiscretizedRosenbrockEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)

void CBinaryDiscretizedRosenbrockEvaluation::v_clear()
{
	delete pc_native_rosenbrock;
	pc_native_rosenbrock = nullptr;
}//void CBinaryDiscretizedRosenbrockEvaluation::v_clear()


CBinaryHIFFEvaluation::CBinaryHIFFEvaluation()
{
	d_max_value = 1.0;
	pc_native_hiff = nullptr;
}//CBinaryHIFFEvaluation::CBinaryHIFFEvaluation()

CBinaryHIFFEvaluation::~CBinaryHIFFEvaluation()
{
	v_clear();
}//CBinaryHIFFEvaluation::~CBinaryHIFFEvaluation()

CError CBinaryHIFFEvaluation::eConfigure(istream *psSettings)
{
	v_clear();

	CError c_error = CBinaryEvaluation::eConfigure(psSettings);

	if (!c_error)
	{
		Configuration c_config;

		i_number_of_elements = 2048;

		c_config.set("length", (int)i_number_of_elements);
		c_config.set("precision", 65536);

		pc_native_hiff = new HIFF(c_config, 0);

		v_native_solution.resize(i_number_of_elements);
	}//if (!c_error)

	return c_error;
}//CError CBinaryHIFFEvaluation::eConfigure(istream *psSettings)

double CBinaryHIFFEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)
{
	for (uint16_t i = 0; i < pcFenotype->iGetNumberOfBits(); i++)
	{
		v_native_solution.at(i) = *(pcFenotype->piGetBits() + i + iShift) == 1;
	}//for (uint16_t i = 0; i < pcFenotype->iGetNumberOfBits(); i++)

	return (double)pc_native_hiff->evaluate(v_native_solution);
}//double CBinaryHIFFEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)

void CBinaryHIFFEvaluation::v_clear()
{
	delete pc_native_hiff;
	pc_native_hiff = nullptr;
}//void CBinaryHIFFEvaluation::v_clear()


CBinaryDSMGA2BasedEvaluation::CBinaryDSMGA2BasedEvaluation()
{
	pc_native_chromosome = nullptr;
}//CBinaryDSMGA2BasedEvaluation::CBinaryDSMGA2BasedEvaluation()

CBinaryDSMGA2BasedEvaluation::~CBinaryDSMGA2BasedEvaluation()
{
	v_clear();
}//CBinaryDSMGA2BasedEvaluation::~CBinaryDSMGA2BasedEvaluation()

CError CBinaryDSMGA2BasedEvaluation::eConfigure(istream *psSettings)
{
	v_clear();

	CError c_error = CBinaryEvaluation::eConfigure(psSettings);

	if (!c_error)
	{
		CUIntCommandParam p_number_of_elements(EVALUATION_ARGUMENT_NUMBER_OF_ELEMENTS, 1, UINT16_MAX);
		i_number_of_elements = p_number_of_elements.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		pc_native_chromosome = new Chromosome((int)i_number_of_elements);
	}//if (!c_error)

	return c_error;
}//CError CBinaryDSMGA2BasedEvaluation::eConfigure(istream *psSettings)

void CBinaryDSMGA2BasedEvaluation::v_clear()
{
	delete pc_native_chromosome;
	pc_native_chromosome = nullptr;
}//void CBinaryDSMGA2BasedEvaluation::v_clear()


CError CBinaryCyclicTrapEvaluation::eConfigure(istream *psSettings)
{
	CError c_error = CBinaryDSMGA2BasedEvaluation::eConfigure(psSettings);

	if (!c_error)
	{
		Chromosome::function = Chromosome::Function::CYCTRAP;
		d_max_value = pc_native_chromosome->getMaxFitness() + 1e-8;
	}//if (!c_error)

	return c_error;
}//CError CBinaryCyclicTrapEvaluation::eConfigure(istream *psSettings)

double CBinaryCyclicTrapEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)
{
	for (uint16_t i = 0; i < i_number_of_elements; i++)
	{
		pc_native_chromosome->setVal((int)i, (int)*(pcFenotype->piGetBits() + i + iShift));
	}//for (uint16_t i = 0; i < i_number_of_elements; i++)

	return pc_native_chromosome->cycTrap(1, 0.8);
}//double CBinaryCyclicTrapEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)


CError CBinarySteinerTreeSetDynamicEvaluation::eConfigure(istream *psSettings)
{
	CError c_error = CEvaluation<CBinaryCoding>::eConfigure(psSettings);

	if (!c_error)
	{
		CStringCommandParam p_config_file_path(EVALUATION_ARGUMENT_CONFIG_FILE_PATH);
		CString s_config_file_path = p_config_file_path.sGetValue(psSettings, &c_error);

		FILE *pf_config = fopen(s_config_file_path, "r");

		if (pf_config)
		{
			c_error = c_steiner_tree_set_function.eLoadSettings(pf_config);

			if (!c_error)
			{
				d_max_value = DBL_MAX;
			}//if (!c_error)

			fclose(pf_config);
		}//if (pf_config)
		else
		{
			c_error.vSetError(CError::iERROR_CODE_SYSTEM_FILE_NOT_FOUND, s_config_file_path);
		}//else if (pf_config)
	}//if (!c_error)

	return c_error;
}//CError CBinarySteinerTreeSetDynamicEvaluation::eConfigure(istream *psSettings)

void CBinarySteinerTreeSetDynamicEvaluation::vChange()
{
	double d_penalty_factor = 1.2 * c_steiner_tree_set_function.dGetPenaltyFactor();
	c_steiner_tree_set_function.vPenaltyFactorSet(d_penalty_factor);
}//void CBinarySteinerTreeSetDynamicEvaluation::vChange()

double CBinarySteinerTreeSetDynamicEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)
{
	return c_steiner_tree_set_function.dGetFuncValue(iShift, pcFenotype->piGetBits(), pcFenotype->iGetNumberOfBits());
}//double CBinarySteinerTreeSetDynamicEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)

CBinaryUncapacitatedWarehouseLocationEvaluation::CBinaryUncapacitatedWarehouseLocationEvaluation()
{

}//CBinaryUncapacitatedWarehouseLocationEvaluation::CBinaryUncapacitatedWarehouseLocationEvaluation()


CError CBinaryUncapacitatedWarehouseLocationEvaluation::eConfigure(istream* psSettings)
{
	CError c_error = CBinaryEvaluation::eConfigure(psSettings);

	if (!c_error)
	{
		CFilePathCommandParam p_config_file_path(EVALUATION_ARGUMENT_CONFIG_FILE_PATH);
		CString s_config_file_path = p_config_file_path.sGetValue(psSettings, &c_error);

		if (!c_error)
		{
			ifstream f_config(s_config_file_path);

			string s_line;

			getline(f_config, s_line);
			istringstream iss_line(s_line);
			iss_line >> i_warehouses >> i_customers;
			i_number_of_elements = i_warehouses;

			string s_warehouse_capacity; //ignored
			double d_warehouse_cost;

			for (int i = 0; i < i_warehouses; i++)
			{
				getline(f_config, s_line);
				istringstream iss_line(s_line);
				iss_line >> s_warehouse_capacity >> d_warehouse_cost;
				v_warehouse_costs.push_back(d_warehouse_cost);
			}//for (int i = 0; i < i_warehouses; i++)

			for (int i = 0; i < i_customers; i++)
			{
				int customer_demand;
				getline(f_config, s_line);
				istringstream iss_line(s_line);
				iss_line >> customer_demand;
				v_customer_costs.emplace_back(vector<double>());
				while(v_customer_costs[i].size() != i_warehouses)
				{
					getline(f_config, s_line);
					istringstream iss_line(s_line);
					copy(istream_iterator<double>{iss_line},
						istream_iterator<double>{},
						back_inserter(v_customer_costs[i]));
				}//while(v_customer_costs[i].size() != i_warehouses)
			}//for (int i = 0; i < i_customers; i++)

			getline(f_config, s_line);
			if (s_line != "")
			{
				istringstream iss_line(s_line);
				iss_line >> d_max_value;
				//::MessageBox(NULL, s_line.c_str(), s_line.c_str(), MB_OK);

				//CString  s_buf;
				//s_buf.Format("MaxVal: %.4lf", d_max_value);
				//::MessageBox(NULL, s_buf, s_buf, MB_OK);


				getline(f_config, s_line);

				i_evaluation_precision = atoi(s_line.c_str());
				d_max_value = ::Tools::dRound(d_max_value, i_evaluation_precision);
				d_max_value = -d_max_value;
				/*::MessageBox(NULL, s_line.c_str(), s_line.c_str(), MB_OK);
				iss_line >> i_evaluation_precision;
				s_buf.Format("Precision: %d", i_evaluation_precision);
				::MessageBox(NULL, s_buf, s_buf, MB_OK);

				s_buf.Format("ResultAfterRound: %.8lf", ::Tools::dRound(d_max_value, i_evaluation_precision));
				::MessageBox(NULL, s_buf, s_buf, MB_OK);*/
				
			}//if (s_line != "")

			f_config.close();
		}//if (!c_error)
	}//if (!c_error)

	return c_error;

}//CError CBinaryUncapacitatedWarehouseLocationEvaluation::eConfigure(istream* psSettings)

double CBinaryUncapacitatedWarehouseLocationEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)
{
	uint16_t i_selected_warehouses = 0;
	double d_warehouse_costs = 0;
	double d_customer_costs = 0;

	int32_t* piArgument = pcFenotype->piGetBits();
	
	for (uint16_t i = 0; i < i_warehouses; i++)
	{
		if (piArgument[i + iShift] == 1)
		{
			i_selected_warehouses++;
			d_warehouse_costs += v_warehouse_costs[i];
		}//if(piArgument[i] == 1)
	}//for (uint16_t i = 0; i < i_warehouses; i++)

	if (i_selected_warehouses == 0)
	{
		return -DBL_MAX; //penalize incorrect solution 
	}//if (i_selected_warehouses == 0)

	for (uint16_t i = 0; i < i_customers; i++)
	{
		vector<double>& v_current_customer_costs = v_customer_costs[i];
		double minimal_customer_cost = DBL_MAX;
		for (uint16_t j = 0; j < i_warehouses; j++)
		{
			if (piArgument[j + iShift] == 1 && v_current_customer_costs[j] < minimal_customer_cost)
			{
				minimal_customer_cost = v_current_customer_costs[j];
			}//if(piArgument[j] == 1 && v_current_customer_costs[j] < minimal_warehouse_cost)
		}//for(uint16_t j = 0; j < i_warehouses; j++)

		d_customer_costs += minimal_customer_cost;
	}//for (uint16_t i = 0; i < i_customers; i++)

	double  d_result;
	d_result = d_warehouse_costs + d_customer_costs;
	d_result = ::Tools::dRound(d_result, i_evaluation_precision);


	//if (d_result == d_max_value)  ::Tools::vShow("JEST");

	return -(d_result);
}//double CBinaryUncapacitatedWarehouseLocationEvaluation::d_evaluate(CBinaryCoding *pcFenotype, uint16_t iShift)




CBinaryTDMkLandscapesEvaluation::CBinaryTDMkLandscapesEvaluation()
{
	s_codomain_folder = S_CODOMAIN_FOLDER;
	s_problem_folder = S_PROBLEM_FOLDER;

	i_instance_id = 0;
}

CBinaryTDMkLandscapesEvaluation::CBinaryTDMkLandscapesEvaluation(string sRunId)
{
	s_codomain_folder = S_CODOMAIN_FOLDER + "_" + sRunId;
	s_problem_folder = S_PROBLEM_FOLDER + "_" + sRunId;

	i_instance_id = 0;
}

CError CBinaryTDMkLandscapesEvaluation::eConfigure(istream * psSettings)
{
	CError c_error = CBinaryEvaluation::eConfigure(psSettings);

	if (!c_error)
	{
		CFilePathCommandParam p_config_file_path(EVALUATION_ARGUMENT_MK_CONFIG_FILE_PATH, false);
		c_error = p_config_file_path.eSetValue(psSettings);
		CFilePathCommandParam p_codomain_file_path(EVALUATION_ARGUMENT_MK_CODOMAIN_FILE_PATH, false);
		c_error = p_codomain_file_path.eSetValue(psSettings);
		CUIntCommandParam p_num_instances(EVALUATION_ARGUMENT_MK_NUM_INSTANCES, false);
		c_error = p_num_instances.eSetValue(psSettings);

		CStringCommandParam p_instance_name(EVALUATION_ARGUMENT_MK_INSTANCE_NAME, false);
		c_error = p_instance_name.eSetValue(psSettings);
		CUIntCommandParam p_instance_id(EVALUATION_ARGUMENT_MK_INSTANCE_ID, false);
		c_error = p_instance_id.eSetValue(psSettings);

		CBoolCommandParam p_from_codomain(EVALUATION_ARGUMENT_MK_FROM_CODOMAIN, false);
		c_error = p_from_codomain.eSetValue(psSettings);

		CUIntCommandParam p_seed(EVALUATION_ARGUMENT_MK_PROBLEM_SEED, false);
		c_error = p_seed.eSetValue(psSettings);

		if (c_error)
		{
			return c_error;
		}

		uint32_t i_num_instances = p_num_instances.bHasValue() ? p_num_instances.iGetValue() : 1;

		string s_command_params;
		string s_file_path;

		bool b_seed_provided = false;

		if (p_seed.bHasValue())
		{
			i_seed = p_seed.iGetValue();
			b_seed_provided = true;
		}

		if (p_config_file_path.bHasValue())
		{
			if (b_seed_provided)
			{
				s_command_params = "-s " + to_string(i_seed) + " ";
			}
			s_file_path = p_config_file_path.sGetValue(psSettings, &c_error);
			s_command_params += "configuration_file -n " + to_string(i_num_instances) + " " + s_file_path + " " + s_codomain_folder + " " + s_problem_folder;
			v_run_generator(s_command_params, &c_error);
			b_from_codomain = false;
		}
		else if (p_codomain_file_path.bHasValue())
		{
			s_file_path = p_codomain_file_path.sGetValue(psSettings, &c_error);

			CString  s_folder_name;
			s_folder_name.Format("%s", s_file_path.c_str());
			s_folder_name.Replace(".txt", "");


			s_codomain_folder = string((LPCTSTR)s_folder_name);
			s_codomain_folder += s_CODOMAIN_POSTFIX;
			s_problem_folder = string((LPCTSTR)s_folder_name);
			s_problem_folder += s_PROBLEM_POSTFIX;
			string  s_file_instance_name = string((LPCTSTR)s_folder_name);
			uint32_t i_current_seed = this->i_seed;
			for (uint32_t i = 0; i < i_num_instances; i++)
			{
				s_command_params = "";
				if (b_seed_provided)
				{
					s_command_params = "-s " + to_string(i_current_seed) + " ";
				}

				//s_command_params += "codomain_file " + s_file_path + " " + s_problem_folder + "\\Mk_problem_" + to_string(i) + ".txt";
				s_command_params += "codomain_file " + s_file_path + " " + s_problem_folder + "\\" + s_file_instance_name + "_" + to_string(i_current_seed) + ".txt";
				v_run_generator(s_command_params, &c_error, i == 0);
				CopyFile(s_file_path.c_str(), (s_codomain_folder + "\\" + s_file_instance_name + "_" + to_string(i_current_seed) + ".txt").c_str(), FALSE);
				if (b_seed_provided)
				{
					i_current_seed++;
				}
			}
			b_from_codomain = true;
		}
		else if (p_instance_name.bHasValue() && p_instance_id.bHasValue() && p_from_codomain.bHasValue())
		{
			s_instance_name = p_instance_name.sGetValue();
			i_instance_id = p_instance_id.iGetValue();
			b_from_codomain = p_from_codomain.bGetValue();

			//s_problem_folder = S_PROBLEM_FOLDER + "_" + s_instance_name;
			//s_codomain_folder = S_CODOMAIN_FOLDER + "_" + s_instance_name;
			s_problem_folder = s_instance_name + s_PROBLEM_POSTFIX;
			s_codomain_folder = s_instance_name + s_CODOMAIN_POSTFIX;
		}
		else
		{
			c_error.vSetError("Either config/codomain file must be set or instance name, id  and from_comain provided");
			return c_error;
		}
	}

	if (!c_error)
	{
		v_load_problem();
		v_load_codomain();
	}

	return c_error;
}

double CBinaryTDMkLandscapesEvaluation::d_evaluate(CBinaryCoding * pcFenotype, uint16_t iShift)
{
	double d_fitness = 0.0;

	int32_t* pi_solution = pcFenotype->piGetBits();

	for (size_t i = 0; i < v_cliques.size(); i++)
	{
		size_t i_codomain_idx = 0;

		vector<uint16_t> v_clique = v_cliques[i];

		for (size_t j = 0; j < v_clique.size(); j++)
		{
			i_codomain_idx += pi_solution[v_clique[j] + iShift] << (v_clique.size() - j - 1);
		}

		d_fitness += v_codomain_values[i][i_codomain_idx];
	}

	return d_fitness;
}


bool  CBinaryTDMkLandscapesEvaluation::b_check_if_contained(vector<int>  *pvDependentGenes, int iGeneOffsetToCheck)
{
	for (int ii = 0; ii < pvDependentGenes->size(); ii++)
	{
		if (pvDependentGenes->at(ii) == iGeneOffsetToCheck)  return(true);
	}//for (int ii = 0; ii < pvDependentGenes->size(); ii++)

	return(false);
}//bool  CBinaryTDMkLandscapesEvaluation::b_check_if_contained(vector<int>  *pvDependentGenes, int iGeneOffsetToCheck)

void  CBinaryTDMkLandscapesEvaluation::v_get_true_gene_dependencies(vector<vector<int>>  *pvDependentGenes)
{
	pvDependentGenes->clear();
	for (int ii = 0; ii < this->i_number_of_elements; ii++)
		pvDependentGenes->push_back(vector<int>());



	for (int i_clause = 0; i_clause < v_cliques.size(); i_clause++)
	{
		for (int i_clause_elem_first = 0; i_clause_elem_first < v_cliques.at(i_clause).size(); i_clause_elem_first++)
		{
			for (int i_clause_elem_second = i_clause_elem_first + 1; i_clause_elem_second < v_cliques.at(i_clause).size(); i_clause_elem_second++)
			{
				if (i_clause_elem_first != i_clause_elem_second)
				{
					if (b_check_if_contained(&(pvDependentGenes->at(v_cliques.at(i_clause).at(i_clause_elem_first))), v_cliques.at(i_clause).at(i_clause_elem_second)) == false)
						pvDependentGenes->at(v_cliques.at(i_clause).at(i_clause_elem_first)).push_back(v_cliques.at(i_clause).at(i_clause_elem_second));
					if (b_check_if_contained(&(pvDependentGenes->at(v_cliques.at(i_clause).at(i_clause_elem_second))), v_cliques.at(i_clause).at(i_clause_elem_first)) == false)
						pvDependentGenes->at(v_cliques.at(i_clause).at(i_clause_elem_second)).push_back(v_cliques.at(i_clause).at(i_clause_elem_first));
				}//if (i_clause_elem_first != i_clause_elem_second)
			}//for (int i_clause_elem_second = i_clause_elem_first+1; i_clause_elem_second < 3; i_clause_elem_second++)
		}//for (int i_clause_elem_first = 0; i_clause_elem_first < 3; i_clause_elem_first++)

	}//for (int i_clause = 0; i_clause < clauses.size(); i_clause++)
}//void  CBinaryTDMkLandscapesEvaluation::v_get_true_gene_dependencies(vector<vector<int>>  *pvDependentGenes)

const string CBinaryTDMkLandscapesEvaluation::S_PROBLEM_GENERATOR_EXECUTABLE = "problem-generator"; //TODO replace with proper path or make sure this is ok
const string CBinaryTDMkLandscapesEvaluation::S_CODOMAIN_FOLDER = "Mk_codomain";
const string CBinaryTDMkLandscapesEvaluation::S_PROBLEM_FOLDER = "Mk_problem";


void CBinaryTDMkLandscapesEvaluation::v_run_generator(string s_arguments, CError *pcError, bool b_clear)
{
	CreateDirectoryA(s_codomain_folder.c_str(), NULL);
	CreateDirectoryA(s_problem_folder.c_str(), NULL);

	if (b_clear)
	{
		for (string file : list_folder(s_codomain_folder))
		{
			DeleteFileA((s_codomain_folder + "\\" + file).c_str());
		}

		for (string file : list_folder(s_problem_folder))
		{
			DeleteFileA((s_problem_folder + "\\" + file).c_str());
		}
	}

	string s_full_command = S_PROBLEM_GENERATOR_EXECUTABLE + " " + s_arguments + " > Mk_err.txt 2>&1";
	int i_status_code = system(s_full_command.c_str());

	if (i_status_code != 0)
	{
		ifstream err_file("Mk_err.txt");
		stringstream buffer;

		buffer << err_file.rdbuf();
		pcError->vSetError(("Error from problem_generator: \n" + buffer.str()).c_str());
	}
}

void CBinaryTDMkLandscapesEvaluation::v_load_problem()
{
	/*string s_filename = s_problem_folder + "\\" + list_folder(s_problem_folder)[0];

	for (string f : list_folder(s_problem_folder))
	{
		if (ends_with(f, "_" + to_string(i_instance_id) + ".txt"))
		{
			s_filename = s_problem_folder + "\\" + f;
		}
	}*/
	string s_filename = s_problem_folder + "\\" + s_instance_name + "_" + to_string(i_instance_id) + ".txt";

	ifstream f_config(s_filename);
	string s_line;

	getline(f_config, s_line);
	istringstream iss_line_MKOB(s_line);

	iss_line_MKOB >> i_m >> i_k >> i_o >> i_b;
	i_number_of_elements = (i_m - 1) * (i_k - i_o) + i_k;

	getline(f_config, s_line);
	istringstream iss_line_maxval(s_line);
	iss_line_maxval >> d_max_value;

	getline(f_config, s_line);
	istringstream iss_line_numopt(s_line);
	uint16_t i_num_optims;
	iss_line_numopt >> i_num_optims;

	for (uint16_t i = 0; i < i_num_optims; i++)
	{
		getline(f_config, s_line); //skip
	}

	v_cliques = vector<vector<uint16_t>>(i_m, vector<uint16_t>(i_k, 0));

	for (uint16_t i = 0; i < i_m; i++)
	{
		getline(f_config, s_line);
		istringstream iss_line(s_line);

		for (uint16_t j = 0; j < i_k; j++)
		{
			iss_line >> v_cliques[i][j];
		}
	}
}

void CBinaryTDMkLandscapesEvaluation::v_load_codomain()
{
	/*string s_filename = s_codomain_folder + "\\" + list_folder(s_codomain_folder)[0];

	for (string f : list_folder(s_codomain_folder))
	{
		if (ends_with(f, "_" + to_string(i_instance_id) + ".txt"))
		{
			s_filename = s_codomain_folder + "\\" + f;
		}
	}*/
	string s_filename = s_codomain_folder + "\\" + s_instance_name + "_" + to_string(i_instance_id) + ".txt";

	ifstream f_config(s_filename);
	string s_line;

	if (!b_from_codomain)
	{
		getline(f_config, s_line); //skip
	}
	getline(f_config, s_line); //skip

	v_codomain_values = vector<vector<double>>(i_m, vector<double>(pow(2, i_k), 0.0));

	for (size_t i = 0; i < v_codomain_values.size(); i++)
	{
		for (size_t j = 0; j < v_codomain_values[i].size(); j++)
		{
			getline(f_config, s_line);
			istringstream iss_line(s_line);
			iss_line >> v_codomain_values[i][j];
		}
	}
}


// implementation from: https://stackoverflow.com/a/20847429
vector<string> CBinaryTDMkLandscapesEvaluation::list_folder(string folder)
{
	vector<string> names;
	string search_path = folder + "/*.*";
	WIN32_FIND_DATA fd;
	HANDLE hFind = ::FindFirstFile(search_path.c_str(), &fd);
	if (hFind != INVALID_HANDLE_VALUE) {
		do {
			// read all (real) files in current folder
			// , delete '!' read other 2 default folder . and ..
			if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
				names.push_back(fd.cFileName);
			}
		} while (::FindNextFile(hFind, &fd));
		::FindClose(hFind);
	}
	return names;
}


bool CBinaryTDMkLandscapesEvaluation::ends_with(string const & value, string const & ending)
{
	if (value.length() >= ending.length()) {
		return (0 == value.compare(value.length() - ending.length(), ending.length(), ending));
	}
	else {
		return false;
	}
}

