#include "DynamicFromStaticOptimizer.h"

#include "BinaryCoding.h"
#include "Individual.h"
#include "OptimizerUtils.h"
#include "RealCoding.h"

#include <cstdint>
#include <ctime>

using namespace DynamicOptimizer;

template <class TGenotype, class TFenotype>
CDynamicFromStaticOptimizer<TGenotype, TFenotype>::CDynamicFromStaticOptimizer(CProblem<TGenotype, TFenotype> *pcProblem, CLog *pcLog, uint32_t iRandomSeed)
	: CDynamicOptimizer<TGenotype, TFenotype>(pcProblem, pcLog, iRandomSeed)
{
	pc_static_optimizer = nullptr;
}//CDynamicFromStaticOptimizer<TGenotype, TFenotype>::CDynamicFromStaticOptimizer(CProblem<TGenotype, TFenotype> *pcProblem, CLog *pcLog, uint32_t iRandomSeed)

template <class TGenotype, class TFenotype>
CDynamicFromStaticOptimizer<TGenotype, TFenotype>::~CDynamicFromStaticOptimizer()
{
	delete pc_static_optimizer;
}//CDynamicFromStaticOptimizer<TGenotype, TFenotype>::~CDynamicFromStaticOptimizer()

template <class TGenotype, class TFenotype>
CError CDynamicFromStaticOptimizer<TGenotype, TFenotype>::eConfigure(istream *psSettings)
{
	delete pc_static_optimizer;

	CError c_error = CDynamicOptimizer<TGenotype, TFenotype>::eConfigure(psSettings);

	if (!c_error)
	{
		c_error = e_configure_static_optimizer(psSettings);
	}//if (!c_error)

	return c_error;
}//CError CDynamicFromStaticOptimizer<TGenotype, TFenotype>::eConfigure(istream *psSettings)

template <class TGenotype, class TFenotype>
void CDynamicFromStaticOptimizer<TGenotype, TFenotype>::vInitialize()
{
	c_optimizer_timer.vSetStartNow();
	CDynamicOptimizer<TGenotype, TFenotype>::vInitialize();
	pc_static_optimizer->vInitialize();
}//void CDynamicFromStaticOptimizer<TGenotype, TFenotype>::vInitialize(time_t tStartTime)

template <class TGenotype, class TFenotype>
void CDynamicFromStaticOptimizer<TGenotype, TFenotype>::vRunState(uint64_t iStartFFE)
{
	uint32_t i_iteration_number = 0;

	while (!pc_stop_condition->bStop(&c_optimizer_timer, i_iteration_number, pc_problem->pcGetEvaluation()->iGetFFE() - iStartFFE, pc_static_optimizer->pcGetBestIndividual()))
	{
		pc_static_optimizer->bRunIteration(i_iteration_number);
		i_iteration_number++;
	}//while (!pc_stop_condition->bStop(tStartTime, i_iteration_number, pc_problem->pcGetEvaluation()->iGetFFE() - iStartFFE, pc_static_optimizer->pcGetBestIndividual()))

	*(ppc_best_individuals + i_current_state_index) = new CIndividual<TGenotype, TFenotype>(pc_static_optimizer->pcGetBestIndividual());

	*(pd_best_times + i_current_state_index) = pc_static_optimizer->dGetBestTime();
	*(pi_best_ffes + i_current_state_index) = pc_static_optimizer->iGetBestFFE() - iStartFFE;
}//void CDynamicFromStaticOptimizer<TGenotype, TFenotype>::vRunState(uint64_t iStartFFE)

template <class TGenotype, class TFenotype>
void CDynamicFromStaticOptimizer<TGenotype, TFenotype>::vChangeState(uint64_t iStartFFE)
{
	CDynamicOptimizer<TGenotype, TFenotype>::vChangeState(iStartFFE);
	pc_static_optimizer->vResetBestIndividual();
}//void CDynamicFromStaticOptimizer<TGenotype, TFenotype>::vChangeState(time_t tStartTime, uint64_t iStartFFE)

template <class TGenotype, class TFenotype>
CError CDynamicFromStaticOptimizer<TGenotype, TFenotype>::e_configure_static_optimizer(istream *psSettings)
{
	CError c_error;

	pc_static_optimizer = OptimizerUtils::pcGetOptimizer(pc_problem, pc_log, i_random_seed, psSettings, &c_error);

	return c_error;
}//CError CDynamicFromStaticOptimizer<TGenotype, TFenotype>::e_configure_static_optimizer(istream *psSettings)

template class CDynamicFromStaticOptimizer<CBinaryCoding, CBinaryCoding>;
template class CDynamicFromStaticOptimizer<CRealCoding, CRealCoding>;