#include "GenePatternTree.h"

using namespace Linkage;

CGenePatternTree::CGenePatternTree(vector<pair<uint32_t, uint32_t>*> *pvClusterIndexes)
	: CGenePatternTree(0, pvClusterIndexes)
{

}//CGenePatternTree::CGenePatternTree(vector<pair<uint32_t, uint32_t>*>  *pvClusterIndexes)

CGenePatternTree::CGenePatternTree(uint16_t iSignificantIndex, vector<pair<uint32_t, uint32_t>*> *pvClusterIndexes)
{
	i_significant_index = iSignificantIndex;

	if (!pvClusterIndexes->empty())
	{
		v_all_gene_patterns.reserve(2 * pvClusterIndexes->size() + 1);

		v_init_leaves((uint16_t)(pvClusterIndexes->size() + 1));
		v_init_nodes(pvClusterIndexes);

		pc_root = v_all_gene_patterns.back();
	}//if (!pvClusterIndexes->empty())
	else
	{
		pc_root = nullptr;
	}//else if (!pvClusterIndexes->empty())
}//CGenePatternTree::CGenePatternTree(uint16_t iSignificantIndex, vector<pair<uint32_t, uint32_t>*> *pvClusterIndexes)

CGenePattern * CGenePatternTree::pcGetClosestGenePattern(CGenePattern *pcGenePattern, uint16_t iMaxSize)
{
	return pcGetClosestGenePattern(pcGenePattern->piGetPattern(), pcGenePattern->iGetSize(), iMaxSize);
}//CGenePattern * CGenePatternTree::pcGetClosestGenePattern(CGenePattern *pcGenePattern, uint16_t iMaxSize)

CGenePattern * CGenePatternTree::pcGetClosestGenePattern(vector<uint16_t> *pvGenePatternElements, uint16_t iMaxSize)
{
	return pcGetClosestGenePattern(pvGenePatternElements->data(), (uint16_t)pvGenePatternElements->size(), iMaxSize);
}//CGenePattern * CGenePatternTree::pcGetClosestGenePattern(vector<uint16_t> *pvGenePatternElements, uint16_t iMaxSize)

CGenePattern * CGenePatternTree::pcGetClosestGenePattern(uint16_t * piGenePatternElements, uint16_t iNumberOfGenePatternElements, uint16_t iMaxSize)
{
	CGenePattern *pc_closest_gene_pattern = nullptr;

	if (iNumberOfGenePatternElements > 0)
	{
		vector<CGenePattern*> v_gene_patterns_buf;
		v_gene_patterns_buf.reserve(iNumberOfGenePatternElements);

		bool b_finish = false;

		for (size_t i = 0; i < iNumberOfGenePatternElements && !b_finish; i++)
		{
			v_gene_patterns_buf.push_back(v_all_gene_patterns.at((size_t)*(piGenePatternElements + i)));
			b_finish = v_gene_patterns_buf.back()->iGetSize() > iMaxSize;
		}//for (size_t i = 0; i < iNumberOfGenePatternElements && !b_finish; i++)

		uint16_t i_size;
		uint16_t i_size_min, i_size_max;

		while (!b_finish)
		{
			b_finish = true;

			for (size_t i = 1; i < v_gene_patterns_buf.size() && b_finish; i++)
			{
				b_finish = v_gene_patterns_buf.at(i - 1) == v_gene_patterns_buf.at(i);
			}//for (size_t i = 1; i < v_gene_patterns_buf.size() && b_finish; i++)

			if (!b_finish)
			{
				i_size_min = UINT16_MAX;
				i_size_max = 0;

				for (size_t i = 0; i < v_gene_patterns_buf.size(); i++)
				{
					i_size = v_gene_patterns_buf.at(i)->iGetSize();

					i_size_min = min(i_size_min, i_size);
					i_size_max = max(i_size_max, i_size);
				}//for (size_t i = 0; i < v_gene_patterns_buf.size(); i++)

				for (size_t i = 0; i < v_gene_patterns_buf.size() && !b_finish; i++)
				{
					if (i_size_min == i_size_max || v_gene_patterns_buf.at(i)->iGetSize() < i_size_max)
					{
						v_gene_patterns_buf.at(i) = v_gene_patterns_buf.at(i)->pcGetParentPattern();
						b_finish = v_gene_patterns_buf.at(i)->iGetSize() > iMaxSize;
					}//if (i_size_min == i_size_max || v_gene_patterns_buf.at(i)->iGetSize() < i_size_max)
				}//for (size_t i = 0; i < v_gene_patterns_buf.size() && !b_finish; i++)
			}//if (!b_finish)
			else
			{
				pc_closest_gene_pattern = v_gene_patterns_buf.front();
			}//else if (!b_finish)
		}//while (!b_finish)
	}//if (iNumberOfGenePatternElements > 0)

	return pc_closest_gene_pattern;
}//CGenePattern * CGenePatternTree::pcGetClosestGenePattern(uint16_t * piGenePatternElements, uint16_t iNumberOfGenePatternElements, uint16_t iMaxSize)

CGenePatternTree::~CGenePatternTree()
{
	delete pc_root;
}//CGenePatternTree::~CGenePatternTree()

void CGenePatternTree::v_init_leaves(uint16_t iNumberOfLeaves)
{
	v_leaves.reserve((size_t)iNumberOfLeaves);

	CGenePattern *pc_gene_pattern;

	for (uint16_t i = 0; i < iNumberOfLeaves; i++)
	{
		pc_gene_pattern = new CGenePattern(i_significant_index);
		pc_gene_pattern->vAdd(i);

		v_all_gene_patterns.push_back(pc_gene_pattern);
		v_leaves.push_back(pc_gene_pattern);
	}//for (uint16_t i = 0; i < iNumberOfLeaves; i++)
}//void CGenePatternTree::v_init_leaves(uint16_t iNumberOfLeaves)

void CGenePatternTree::v_init_nodes(vector<pair<uint32_t, uint32_t>*> *pvClusterIndexes)
{
	CGenePattern *pc_gene_pattern;

	CGenePattern *pc_nested_gene_pattern_0, *pc_nested_gene_pattern_1;

	for (size_t i = 0; i < pvClusterIndexes->size(); i++)
	{
		pc_gene_pattern = new CGenePattern(i_significant_index);

		pc_nested_gene_pattern_0 = v_all_gene_patterns.at((size_t)pvClusterIndexes->at(i)->first);
		pc_nested_gene_pattern_1 = v_all_gene_patterns.at((size_t)pvClusterIndexes->at(i)->second);

		pc_gene_pattern->vAdd(pc_nested_gene_pattern_0);
		pc_gene_pattern->vAdd(pc_nested_gene_pattern_1);

		pc_gene_pattern->vAddNestedPattern(pc_nested_gene_pattern_0);
		pc_gene_pattern->vAddNestedPattern(pc_nested_gene_pattern_1);

		v_all_gene_patterns.push_back(pc_gene_pattern);
	}//for (size_t i = 0; i < pvClusterIndexes->size(); i++)
}//void CGenePatternTree::v_init_nodes(vector<pair<uint32_t, uint32_t>*> *pvClusterIndexes)
