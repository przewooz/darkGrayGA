#include "PermutationGOMEA.h"

#include "CommandParam.h"
#include "UIntCommandParam.h"

CPermutationGOMEA::CPermutationGOMEA(CProblem<CRealCoding, CPermutationCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed)
	: COptimizer<CRealCoding, CPermutationCoding>(pcProblem, pcLog, iRandomSeed), c_permutation_gomea(pcProblem->pcGetEvaluation(), pcProblem->pcGetTransformation(), pcLog, (int64_t)RandUtils::iRandNumber((uint32_t)0, UINT32_MAX - 1))
{

}//CPermutationGOMEA::CPermutationGOMEA(CProblem<CRealCoding, CPermutationCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed

CPermutationGOMEA::CPermutationGOMEA(CPermutationGOMEA *pcOther)
	: COptimizer<CRealCoding, CPermutationCoding>(pcOther), c_permutation_gomea(pcOther->pc_problem->pcGetEvaluation(), pcOther->pc_problem->pcGetTransformation(), pcOther->pc_log, (int64_t)RandUtils::iRandNumber((uint32_t)0, UINT32_MAX - 1))
{

}//CPermutationGOMEA::CPermutationGOMEA(CPermutationGOMEA *pcOther)

CError CPermutationGOMEA::eConfigure(istream *psSettings)
{
	CError c_error = COptimizer<CRealCoding, CPermutationCoding>::eConfigure(psSettings);

	if (!c_error)
	{
		CUIntCommandParam p_FOSs_structure_index(PERMUTATION_GOMEA_ARGUMENT_FOSS_STRUCTURE_INDEX, 0, 6);
		uint32_t i_FOSs_structure_index = p_FOSs_structure_index.iGetValue(psSettings, &c_error);

		if (!c_error)
		{
			c_permutation_gomea.setFOSsStructureIndex(i_FOSs_structure_index);
		}//if (!c_error)
	}//if (!c_error)

	if (!c_error)
	{
		CUIntCommandParam p_count_empirical_dsm(PERMUTATION_GOMEA_ARGUMENT_COUNT_EMPIRICAL_DSM);
		int  i_count_empirical_dsm = p_count_empirical_dsm.iGetValue(psSettings, &c_error);

		if (!c_error)
		{
			c_permutation_gomea.setCountEmpiricalDSM(i_count_empirical_dsm);
		}//if (!c_error)
	}//if (!c_error)

	return c_error;
}//CError CPermutationGOMEA::eConfigure(istream *psSettings)

void CPermutationGOMEA::vInitialize()
{
	c_optimizer_timer.vSetStartNow();
	c_permutation_gomea.initialize();
}//void CPermutationGOMEA::vInitialize(time_t tStartTime)

bool CPermutationGOMEA::bRunIteration(uint32_t iIterationNumber)
{
	bool b_updated = false;

	c_permutation_gomea.runAllPopulationsSingleGeneration([&]() 
	{
		b_updated = b_update_best_individual(iIterationNumber);
		
		return pc_stop_condition->bStop(&c_optimizer_timer, iIterationNumber, pc_problem->pcGetEvaluation()->iGetFFE(), pcGetBestIndividual());
	});//c_permutation_gomea.runAllPopulationsSingleGeneration([&]() 

	b_updated = b_update_best_individual(iIterationNumber) || b_updated;

	CString s_log_message;

	s_log_message.Format
	(
		"best fitness: %f; ffe: %u; time: %.2lf",
		pc_best_individual->dGetFitnessValue(), 
		pc_problem->pcGetEvaluation()->iGetFFE(),
		c_optimizer_timer.dGetTimePassed()
	);//s_log_message.Format

	pc_log->vPrintLine(s_log_message, true);

	return b_updated;
}//bool CPermutationGOMEA::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)

void CPermutationGOMEA::vRun()
{
	COptimizer<CRealCoding, CPermutationCoding>::vRun();
	c_permutation_gomea.ezilaitini();
}//void CPermutationGOMEA::vRun()

bool CPermutationGOMEA::b_update_best_individual(uint32_t iIterationNumber)
{
	bool b_updated = b_update_best_individual(iIterationNumber, c_permutation_gomea.getElitistSolutionObjectiveValue(), [&](CRealCoding *pcBestGenotype)
	{
		for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
		{
			*(pcBestGenotype->pdGetValues() + i) = *(c_permutation_gomea.getElitistSolution() + i);
		}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
	});//bool b_updated = b_update_best_individual(iIterationNumber, tStartTime, c_permutation_gomea.getElitistSolutionObjectiveValue(), [&](CRealCoding *pcBestGenotype)

	return b_updated;
}//bool CPermutationGOMEA::b_update_best_individual(uint32_t iIterationNumber, time_t tStartTime)