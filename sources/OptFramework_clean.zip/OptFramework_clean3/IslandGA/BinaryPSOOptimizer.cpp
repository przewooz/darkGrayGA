#include "BinaryPSOOptimizer.h"

uint32_t CBinaryPSOOptimizer::iERROR_PARENT_CBinaryPSOOptimizer = CError::iADD_ERROR_PARENT("iERROR_PARENT_CBinaryPSOOptimizer");
const float CBinaryPSOOptimizer::F_DEFAULT_V_MAX = 6.0;
const float CBinaryPSOOptimizer::F_DEFAULT_MAX_PHI = 1.0;
const float CBinaryPSOOptimizer::F_DEFAULT_OMEGA = 0.9;
const uint32_t CBinaryPSOOptimizer::I_DEFAULT_POPULATION_SIZE = 20;

CBinaryPSOOptimizer::CBinaryPSOOptimizer(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed) :
	CPopulationSizingSingleOptimizer(pcProblem, pcLog, iRandomSeed),
	c_individual_distribution(0, F_DEFAULT_V_MAX),
	c_uniform_distribution(0, 1),
	c_phi_distribution(0, F_DEFAULT_MAX_PHI),
	v_population(I_DEFAULT_POPULATION_SIZE, nullptr)
{
	c_random_engine.seed(iRandomSeed);

	d_v_max = F_DEFAULT_V_MAX;
	d_max_phi = F_DEFAULT_MAX_PHI;
	d_omega = F_DEFAULT_OMEGA;
	i_population_size = I_DEFAULT_POPULATION_SIZE;

	pc_best = nullptr;
	i_genotype_length = pcProblem->pcGetEvaluation()->iGetNumberOfElements();
}//CBinaryPSOOptimizer::CBinaryPSOOptimizer(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)

CBinaryPSOOptimizer::CBinaryPSOOptimizer(CBinaryPSOOptimizer * pcOther) :
	CPopulationSizingSingleOptimizer(pcOther),
	v_population(pcOther->v_population.size(), nullptr),
	c_individual_distribution(pcOther->c_individual_distribution),
	c_uniform_distribution(pcOther->c_uniform_distribution),
	c_phi_distribution(pcOther->c_phi_distribution),
	c_random_engine(pcOther->c_random_engine)
{
	i_genotype_length = pcOther->i_genotype_length;
	d_v_max = pcOther->d_v_max;
	d_max_phi = pcOther->d_max_phi;
	d_omega = pcOther->d_omega;
	i_population_size = pcOther->i_population_size;
	pc_best = pcOther->pc_best != nullptr ? new CBinaryPSOIndividual(pcOther->pc_best) : nullptr;
	d_best_fitness = pcOther->d_best_fitness;
	b_use_stale_detection = pcOther->b_use_stale_detection;

	for (size_t ii = 0; ii < v_population.size(); ii++)
	{
		if (pcOther->v_population[ii] != nullptr)
		{
			v_population[ii] = new CBinaryPSOIndividual(pcOther->v_population[ii]);
		}//if (pcOther->v_population[ii] != nullptr)
	}//for (size_t ii = 0; ii < v_population.size(); ii++)
}//CBinaryPSOOptimizer::CBinaryPSOOptimizer(CBinaryPSOOptimizer * pcOther)

CBinaryPSOOptimizer::~CBinaryPSOOptimizer()
{
	v_delete_population();
}//CBinaryPSOOptimizer::~CBinaryPSOOptimizer()

COptimizer<CBinaryCoding, CBinaryCoding>* CBinaryPSOOptimizer::pcCopy()
{
	return new CBinaryPSOOptimizer(this);
}//COptimizer<CBinaryCoding, CBinaryCoding>* CBinaryPSOOptimizer::pcCopy()

CError CBinaryPSOOptimizer::eConfigure(istream * psSettings)
{
	CError c_error(iERROR_PARENT_CBinaryPSOOptimizer);
	c_error = COptimizer::eConfigure(psSettings);

	if (!c_error)
	{
		CUIntCommandParam p_population_size(BINARY_PSO_OPTIMIZER_ARGUMENT_POPULATION_SIZE, 2, UINT32_MAX);
		i_population_size = p_population_size.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		CFloatCommandParam p_v_max(BINARY_PSO_OPTIMIZER_ARGUMENT_V_MAX, F_DEFAULT_V_MAX);
		d_v_max = static_cast<double>(p_v_max.fGetValue(psSettings, &c_error));

		c_individual_distribution = uniform_real_distribution<double>(0, d_v_max);
	}//if (!c_error)

	if (!c_error)
	{
		CFloatCommandParam p_max_phi(BINARY_PSO_OPTIMIZER_ARGUMENT_MAX_PHI, F_DEFAULT_V_MAX);
		d_max_phi = static_cast<double>(p_max_phi.fGetValue(psSettings, &c_error));

		c_phi_distribution = uniform_real_distribution<double>(0, d_max_phi);
	}//if (!c_error)

	if (!c_error)
	{
		CFloatCommandParam p_omega(BINARY_PSO_OPTIMIZER_ARGUMENT_OMEGA, F_DEFAULT_OMEGA);
		d_omega = static_cast<double>(p_omega.fGetValue(psSettings, &c_error));
	}//if (!c_error)

	if (!c_error)
	{
		CBoolCommandParam p_stale_detection(BINARY_PSO_OPTIMIZER_ARGUMENT_STALE_DETECTION, true, false);
		b_use_stale_detection = p_stale_detection.bGetValue(psSettings, &c_error);
	}//if (!c_error)

	return c_error;
}//CError CBinaryPSOOptimizer::eConfigure(istream * psSettings)

bool CBinaryPSOOptimizer::bRunIteration(uint32_t iIterationNumber)
{
	for (size_t ii = 0; ii < v_population.size(); ii++)
	{
		v_population[ii]->vUpdateVelocity(*pc_best, c_phi_distribution, c_random_engine);
		v_population[ii]->vGenotypeProbing(c_uniform_distribution, c_random_engine);
		v_population[ii]->vUpdateBest(pc_problem);
	}//for (size_t ii = 0; ii < v_population.size(); ii++)

	vEvaluate();

	v_update_best();

	bool b_updated = b_update_best_individual(iIterationNumber, pc_best->d_fitness, [&](CBinaryCoding *pcBestGenotype)
	{
		for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
		{
			*(pcBestGenotype->piGetBits() + i) = pc_best->v_genotype[i];
		}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
	});

	CString s_log_message;
	s_log_message.Format(
		"Best fitness: %f; ffe: %llu; time: %.2lf; population size: %u", 
		pc_best_individual->dGetFitnessValue(), 
		pc_problem->pcGetEvaluation()->iGetFFE(),  
		c_optimizer_timer.dGetTimePassed(),
		i_population_size);
	pc_log->vPrintLine(s_log_message, true);
	
	return b_updated;
}//bool CBinaryPSOOptimizer::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)

void CBinaryPSOOptimizer::vInitialize()
{
	c_optimizer_timer.vSetStartNow();
	vResetBestIndividual();
	v_delete_population();
	v_initialize_population();
	v_update_best();
}//void CBinaryPSOOptimizer::vInitialize(time_t tStartTime)

void CBinaryPSOOptimizer::vEvaluate()
{
	for (size_t ii = 0; ii < v_population.size(); ii++)
	{
		d_evaluate(v_population[ii]);
		v_population[ii]->vUpdateBest(pc_problem);
	}//for (size_t ii = 0; ii < v_population.size(); ii++)
}//void CBinaryPSOOptimizer::vEvaluate()

bool CBinaryPSOOptimizer::bIsSteadyState()
{
	if (!b_use_stale_detection)
	{
		return false;
	}//if (!b_stale_detection)

	bool b_different_found = false;

	for (size_t ii = 1; !b_different_found && ii < v_population.size(); ii++)
	{
		bool b_all_same = true;

		for (size_t j = 0; b_all_same && j < i_genotype_length; j++)
		{
			if (v_population[0]->v_genotype[j] != v_population[ii]->v_genotype[j])
			{
				b_all_same = false;
			}//if (v_population[0]->v_genotype[j] != v_population[ii]->v_genotype[j])
		}//for (size_t j = 0; b_all_same && j < i_genotype_length; j++)

		if (!b_all_same)
		{
			b_different_found = true;
		}//if (!b_all_same)
	}//for (size_t ii = 1; !b_different_found && ii < v_population.size(); ii++)

	return !b_different_found;
}//bool CBinaryPSOOptimizer::bIsSteadyState()

double CBinaryPSOOptimizer::dComputeAverageFitnessValue()
{
	double d_fitness_sum = 0;

	for (size_t ii = 0; ii < v_population.size(); ii++)
	{
		d_fitness_sum += v_population[ii]->d_fitness;
	}//for (size_t ii = 0; ii < v_population.size(); ii++)

	return d_fitness_sum / static_cast<double>(v_population.size());

}//double DBinaryPSOOptimizer::dComputeAverageFitnessValue()

void CBinaryPSOOptimizer::v_delete_population()
{
	delete pc_best;
	pc_best = nullptr;

	for (size_t ii = 0; ii < v_population.size(); ii++)
	{
		delete v_population[ii];
		v_population[ii] = nullptr;
	}//for (size_t ii = 0; ii < v_population.size(); ii++)
}//void CBinaryPSOOptimizer::v_delete_population()

void CBinaryPSOOptimizer::v_initialize_population()
{
	v_population.clear();

	for (uint32_t ii = 0; ii < i_population_size; ii++)
	{
		v_population.push_back(
			CBinaryPSOIndividual::pcGetRandomIndividual(
				i_genotype_length,
				d_max_phi,
				d_omega,
				c_individual_distribution,
				c_uniform_distribution,
				c_random_engine
			)
		);
	}//for (uint32_t ii = 0; ii < i_population_size; ii++)

	vEvaluate();
}//void CBinaryPSOOptimizer::v_initialize_population()

double CBinaryPSOOptimizer::d_evaluate(CBinaryPSOIndividual * pc_individual)
{
	CBinaryCoding c_coding(i_genotype_length, pc_individual->v_genotype.data());
	double d_fitness_value = pcGetProblem()->pcGetEvaluation()->dEvaluate(&c_coding);
	pc_individual->d_fitness = d_fitness_value;

	return d_fitness_value;
}//double CBinaryPSOOptimizer::d_evaluate(CBinaryPSOIndividual * pc_individual)

void CBinaryPSOOptimizer::v_update_best()
{
	uint32_t i_best_id = 0;

	for (uint32_t ii = 1; ii < i_population_size; ii++)
	{
		if (pc_problem->bIsBetterFitnessValue(v_population[ii]->d_fitness, v_population[i_best_id]->d_fitness))
		{
			i_best_id = ii;
		}//if (pc_problem->bIsBetterFitnessValue(v_population[ii]->d_fitness, v_population[i_best_id]->d_fitness))
	}//for (uint32_t ii = 1; ii < i_population_size; ii++)

	delete pc_best;
	pc_best = new CBinaryPSOIndividual(v_population[i_best_id]);
	d_best_fitness = pc_best->d_fitness;
}//void CBinaryPSOOptimizer::v_update_best()

/////////////////////////////////////////////////////////////////////////////////////////////////

CBinaryPSOIndividual::CBinaryPSOIndividual(uint16_t iGenotypeLength, double dMaxPhi, double dOmega) :
	v_velocity(iGenotypeLength, static_cast<double>(0)),
	v_genotype(iGenotypeLength, static_cast<uint16_t>(0)),
	v_individual_best(iGenotypeLength, static_cast<uint16_t>(0)),
	d_max_phi(dMaxPhi),
	d_omega(dOmega)
{
}//CBinaryPSOIndividual::CBinaryPSOIndividual(uint16_t iGenotypeLength, double dMaxPhi, double dOmega)

CBinaryPSOIndividual::CBinaryPSOIndividual(CBinaryPSOIndividual * pcOther)
{
	d_max_phi = pcOther->d_max_phi;
	d_omega = pcOther->d_omega;
	d_fitness = pcOther->d_fitness;
	d_best_fitness = pcOther->d_best_fitness;

	v_velocity = pcOther->v_velocity;
	v_genotype = pcOther->v_genotype;
	v_individual_best = pcOther->v_individual_best;
}//CBinaryPSOIndividual::CBinaryPSOIndividual(CBinaryPSOIndividual * pcOther)

CBinaryPSOIndividual * CBinaryPSOIndividual::pcGetRandomIndividual(
	uint16_t iGenotypeLength,
	double dMaxPhi,
	double dOmega,
	uniform_real_distribution<double>& cIndividualDistribution,
	uniform_real_distribution<double>& cUniformDistribution,
	default_random_engine& cRandomEngine
)
{
	CBinaryPSOIndividual* pc_individual = new CBinaryPSOIndividual(
		iGenotypeLength, dMaxPhi, dOmega);

	for (uint16_t ii = 0; ii < iGenotypeLength; ii++)
	{
		pc_individual->v_velocity[ii] = cIndividualDistribution(cRandomEngine);
	}//for (uint16_t ii = 0; ii < iGenotypeLength; ii++)

	pc_individual->d_max_phi = dMaxPhi;
	pc_individual->d_omega = dOmega;

	pc_individual->vGenotypeProbing(cUniformDistribution, cRandomEngine);

	for (uint16_t ii = 0; ii < iGenotypeLength; ii++)
	{
		pc_individual->v_individual_best[ii] = pc_individual->v_genotype[ii];
	}//for (uint16_t ii = 0; ii < iGenotypeLength; ii++)

	return pc_individual;
}//CBinaryPSOIndividual * CBinaryPSOIndividual::pcGetRandomIndividual(uint16_t iGenotypeLength, double dMaxPhi, double dOmega,
//uniform_real_distribution<double>& cIndividualDistribution, uniform_real_distribution<double>& cUniformDistribution, default_random_engine& cRandomEngine)

void CBinaryPSOIndividual::vUpdateVelocity(CBinaryPSOIndividual & pcGlobalBest, uniform_real_distribution<double>& cPhiDistribution, default_random_engine& cRandomEngine)
{
	for (size_t ii = 0; ii < v_velocity.size(); ii++)
	{
		double d_phi = cPhiDistribution(cRandomEngine);

		v_velocity[ii] = d_omega * v_velocity[ii]
			+ d_phi * (v_individual_best[ii] - v_genotype[ii])
			+ d_phi * (pcGlobalBest.v_genotype[ii] - v_genotype[ii]);
	}//for (size_t ii = 0; ii < v_velocity.size(); ii++)
}//void CBinaryPSOIndividual::vUpdateVelocity(CBinaryPSOIndividual & pcGlobalBest, uniform_real_distribution<double>& cPhiDistribution, default_random_engine& cRandomEngine)

void CBinaryPSOIndividual::vGenotypeProbing(
	uniform_real_distribution<double>& c_uniform_distribution,
	default_random_engine & c_random_engine
)
{
	for (size_t ii = 0; ii < v_genotype.size(); ii++)
	{
		double d_rand = c_uniform_distribution(c_random_engine);

		if (d_rand < 1.0 / (1.0 + exp(-1 * this->v_velocity[ii])))
		{
			v_genotype[ii] = 1;
		}//if (d_rand < 1.0 / (1.0 + exp(-1 * this->v_velocity[ii])))
		else
		{
			v_genotype[ii] = 0;
		}//else if (d_rand < 1.0 / (1.0 + exp(-1 * this->v_velocity[ii])))
	}//for (size_t ii = 0; ii < v_genotype.size(); ii++)
}//void CBinaryPSOIndividual::vGenotypeProbing(uniform_real_distribution<double>& pc_uniform_distribution, default_random_engine & pc_random_engine)

void CBinaryPSOIndividual::vUpdateBest(CProblem<CBinaryCoding, CBinaryCoding>* pc_problem)
{
	if (pc_problem->bIsBetterFitnessValue(d_fitness, d_best_fitness))
	{
		d_best_fitness = d_fitness;

		for (size_t ii = 0; ii < v_genotype.size(); ii++)
		{
			v_individual_best[ii] = v_genotype[ii];
		}//for (size_t ii = 0; ii < v_genotype.size(); ii++)
	}//if (pc_problem->bIsBetterFitnessValue(d_fitness, d_best_fitness))
}//void CBinaryPSOIndividual::vUpdateBest(CProblem<CBinaryCoding, CBinaryCoding>* pc_problem)
