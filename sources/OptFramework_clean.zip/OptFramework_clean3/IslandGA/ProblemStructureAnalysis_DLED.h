#ifndef PROBLEM_STRUCTURE_ANALYSIS_H
#define PROBLEM_STRUCTURE_ANALYSIS_H


#include "BinaryCoding.h"
#include "BinaryOptimizer.h"
#include "CommandParam.h"
#include "Error.h"
#include "Log.h"
#include "MathUtils.h"
#include "Optimizer.h"
#include "Problem.h"
#include  "util\timer.h"
#include  "util\tools.h"



#include <istream>
#include <algorithm>





namespace ProblemStructureAnalysis
{
	#define  _PROB_STRUCT_ANAL_DSM_DLED_POSFIX									"dsm_dled" 
	#define  _PROB_STRUCT_ANAL_DSM_DLED_DISTANCES_POSTFIX									"dsm_dled_distances" 
	#define  _PROB_STRUCT_ANAL_DSM_DLED_DISTANCES_DET_REP_POSTFIX									"dsm_dled_distances_detailed_rep" 

	class CProblemStructAnal_DLED : public CBinaryOptimizer
	{
	public:
		static uint32_t iERROR_PARENT_CProblemStructAnal_DLED;
		static uint32_t iERROR_CODE_PSA_DLED_GENOTYPE_LEN_BELOW_0;
		static uint32_t iERROR_CODE_PSA_DLED_SAVE_ERR;


		CProblemStructAnal_DLED(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed);
		CProblemStructAnal_DLED(CProblemStructAnal_DLED *pcOther);
		~CProblemStructAnal_DLED();


		CError  eSaveDSM_DetailedDistanceReport(CString  sDest);
		void  vSaveDSM_DetailedDistanceReport(FILE  *pfDest);


		void  vCopyFrom(CProblemStructAnal_DLED *pcOther);

		virtual COptimizer<CBinaryCoding, CBinaryCoding> *pcCopy() { return new CProblemStructAnal_DLED(this); };
		virtual bool bRunIteration(uint32_t iIterationNumber);

		virtual CError eConfigure(istream *psSettings);
		virtual void vInitialize() override;

		CLog  *pcGetLog() { return(pc_log); }
		CString  sAdditionalSummaryInfo() override;

		double dComputeFitness(int32_t *piBits);


	private:
		void  v_get_min_max_avr_hop_for_gene(int  iGene, int  *piHopMin, int  *piHopMax, double  *pdHopAvr);

		double  d_psa_update_last_time_time;
		double  d_psa_update_last_time_ffe;
		int  i_templ_length;

		vector<CDledDistanceStats>  v_dled_distances;
		CLinkageInformationPack *pc_link_pack;
		CLinkageAnalyzer *pc_linkage_analyzer;
	};//class CProblemStructAnal_DLED : public CBinaryOptimizer



	class  CProblemStructAnal_Ind
	{
	public:
		CProblemStructAnal_Ind(int  iTemplLength, CProblem<CBinaryCoding, CBinaryCoding > *pcProblem, CProblemStructAnal_DLED *pcParent);
		CProblemStructAnal_Ind(CProblemStructAnal_Ind &pcOther);
		~CProblemStructAnal_Ind();

		bool  bIsTheSame(CProblemStructAnal_Ind  *pcOther);
		double  dGetSimilarity(CProblemStructAnal_Ind  *pcOther, int  *piGenesTheSame);
		void  vRandomizeGenotype();
		int*  piGetGenotype() { return(pi_genotype); }

		void  vCopyFrom(CProblemStructAnal_Ind  *pcNewInd);

		
		double  dComputeFitness();
		double  dComputeFitnessOptimize(vector<int>  *pvOrder = NULL);

		void  vClearOptOrder() { v_opt_order.clear(); }

	private:
		void  v_create_opt_order(vector<int>  *pvOrder);
		double  d_optimize_single_gene(int  iOptGene);

		

		CProblemStructAnal_DLED  *pc_parent;
		int  i_templ_length;
		int  *pi_genotype;
		vector<int>  v_opt_order;

		double  d_fitnes_buf;
		bool  b_fitness_actual;

		int  i_level;
		CProblem<CBinaryCoding, CBinaryCoding > *pc_problem;
	};//class  CProblemStructAnal_Ind


}//namespace ProblemStructureAnalysis

#endif//PROBLEM_STRUCTURE_ANALYSIS_H