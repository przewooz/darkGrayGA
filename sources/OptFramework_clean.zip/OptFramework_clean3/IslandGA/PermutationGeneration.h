#ifndef PERMUTATION_GENERATION_H
#define PERMUTATION_GENERATION_H

#include "Generation.h"
#include "PermutationCoding.h"

class CPermutationGeneration : public CGeneration<CPermutationCoding>
{
public:
	CPermutationGeneration(uint16_t iSize);
	CPermutationGeneration(CPermutationCoding *pcSample);

	virtual CPermutationCoding *pcGenerate() { return pcGenerateEmpty(); };
	virtual CPermutationCoding *pcGenerateEmpty() { return new CPermutationCoding(i_size); };

protected:
	uint16_t i_size;
};//class CPermutationGeneration : public CGeneration<CPermutationCoding>

#endif//PERMUTATION_GENERATION_H