#ifndef PERMUTATION_CODING_H
#define PERMUTATION_CODING_H

#include "GenePattern.h"

#include <atlstr.h>
#include <cstdint>
#include <ostream>

using namespace std;

class CPermutationCoding
{
public:
	CPermutationCoding(uint16_t iSize);
	CPermutationCoding(uint16_t iSize, int32_t *piPermutation, bool bOwnPermutation = false); 
	CPermutationCoding(CPermutationCoding *pcOther);

	~CPermutationCoding();

	void vMerge(CPermutationCoding *pcOther);

	uint16_t iGetSize() { return i_size; }
	int32_t *piGetPermutation() { return pi_permutation; };

	void vSetPermutation(int32_t *piPermutation, bool bOwnPermutation = false);

	CString sToString();

	bool operator==(CPermutationCoding &cOther);
	bool operator!=(CPermutationCoding &cOther);

	friend ostream& operator<<(ostream &sOutput, CPermutationCoding *pcPermutationCoding);

private:
	uint16_t i_size;
	int32_t *pi_permutation;

	bool b_own_permutation;
};//class CPermutationCoding

#endif//PERMUTATION_CODING_H