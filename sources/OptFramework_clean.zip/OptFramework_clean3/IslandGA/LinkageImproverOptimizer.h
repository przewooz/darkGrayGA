#ifndef CLINKAGE_UPDATE_OPTIMIZER_H
#define CLINKAGE_UPDATE_OPTIMIZER_H


#include "BinaryCoding.h"
#include "BinaryOptimizer.h"
#include "CommandParam.h"
#include "StringCommandParam.h"
#include "Error.h"
#include "Log.h"
#include "MathUtils.h"
#include "Optimizer.h"
#include "OptimizerUtils.h"
#include "Problem.h"
#include  "util\timer.h"
#include  "util\tools.h"

#include "MultiObjectiveOptimizer.h"
#include "BinaryOptimizer.h"
#include "BinaryEvaluationMultiObjective.h"

#include "P3.h"
#include "../P3/Pyramid.h"

#include <atlstr.h>
#include <cstdint>
#include <ctime>
#include <istream>

#include <istream>
#include <algorithm>



#define LINKAGE_IMPROVER_ARGUMENT_MODE "li_mode (0-LinkageImporverFramework; 1-OutsideLinkage; 2-MeasureLinkage)"

#define LINKAGE_IMPROVER_MODE_STANDARD			0
#define LINKAGE_IMPROVER_MODE_OUTSIDE_LINKAGE	1
#define LINKAGE_IMPROVER_MODE_TEST_LINKAGE		2

#define LINKAGE_IMPROVER_MODE_TEST_LINKAGE_REPORT_LINK_QUALITY_INTERVAL_SECONDS		60




namespace LinkImproverOpt
{
	class  CLinkageImproverOptimizer : public CBinaryOptimizer
	{
	public:
		static uint32_t iERROR_PARENT_CLinkImprove_Optimizer;
		static uint32_t iERROR_CODE_CLinkImprove_GENOTYPE_LEN_BELOW_0;


		CLinkageImproverOptimizer(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed);
		CLinkageImproverOptimizer(CLinkageImproverOptimizer *pcOther);
		~CLinkageImproverOptimizer();

		virtual COptimizer<CBinaryCoding, CBinaryCoding> *pcCopy() { return new CLinkageImproverOptimizer(this); };

		virtual CError eConfigure(istream *psSettings);

		virtual void vInitialize();
		virtual bool bRunIteration(uint32_t iIterationNumber);

		virtual void  vExecuteBeforeEnd();
		virtual  CString  sLinkageSummaryReport() override;
		virtual  void  vGetSlideInformation(double  *pdSlides, double  *pdBlockedSlides) override { pc_optimizer->vGetSlideInformation(pdSlides, pdBlockedSlides); };
		

	private:
		bool b_update_best_individual(uint32_t iIterationNumber, COptimizer<CBinaryCoding, CBinaryCoding> *pcOptimizer);

		TimeCounters::CTimeCounter  c_time_counter;
		TimeCounters::CTimeCounter  c_linkage_test_report_period;

		int  i_templ_length;


		int  i_mode;

		double  d_ffe_linkage_optimizer;
		double  d_ffe_optimizer;
		CP3  *pc_linkage_optimizer;
		COptimizer<CBinaryCoding, CBinaryCoding>  *pc_optimizer;

	};//class  CLinkageImproverOptimizer : public CBinaryOptimizer
}//namespace LinkImproverOpt

#endif//CLINKAGE_UPDATE_OPTIMIZER_H

