#include "PermutationGeneration.h"

CPermutationGeneration::CPermutationGeneration(uint16_t iSize)
{
	i_size = iSize;
}//CPermutationGeneration::CPermutationGeneration(uint16_t iSize)

CPermutationGeneration::CPermutationGeneration(CPermutationCoding *pcSample)
	: CPermutationGeneration(pcSample->iGetSize())
{

}//CPermutationGeneration::CPermutationGeneration(CPermutationCoding *pcSample)