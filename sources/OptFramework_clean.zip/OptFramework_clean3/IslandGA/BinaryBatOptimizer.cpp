#include "BinaryBatOptimizer.h"

//https://github.com/jppbsi/LibDEV/blob/master/examples/FeatureSelection/model_files/ba_model.txt
uint32_t CBinaryBatOptimizer::iERROR_PARENT_CBinaryBatOptimizer = CError::iADD_ERROR_PARENT("iERROR_PARENT_CBinaryBatOptimizer");
const float CBinaryBatOptimizer::F_DEFAULT_LOUDNESS_A = 1.5;
const float CBinaryBatOptimizer::F_DEFAULT_PULSE_RATE_R = 0.5;
const float CBinaryBatOptimizer::F_DEFAULT_FREQUENCY_Q_MIN = 0;
const float CBinaryBatOptimizer::F_DEFAULT_FREQUENCY_Q_MAX = 100; //they stated they used 1 in the paper, while they use 100 in code
const double CBinaryBatOptimizer::D_DEFAULT_ALPHA = 0.9;
const double CBinaryBatOptimizer::D_DEFAULT_LOWER_BOUND = -20; //https://github.com/jppbsi/LibDEV/blob/master/examples/FeatureSelection/FeatureSelectionOPF_BA.c lines 28,29
const double CBinaryBatOptimizer::D_DEFAULT_UPPER_BOUND = 20;


CBinaryBatOptimizer::CBinaryBatOptimizer(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog* pcLog, uint32_t iRandomSeed) : CPopulationSizingSingleOptimizer<CBinaryCoding, CBinaryCoding>(pcProblem, pcLog, iRandomSeed),
	c_position_distribution(D_DEFAULT_LOWER_BOUND, D_DEFAULT_UPPER_BOUND),
	d_lower_bound(D_DEFAULT_LOWER_BOUND),
	d_upper_bound(D_DEFAULT_UPPER_BOUND),
	c_uniform_zero_one_distribution(0, 1),
	b_is_initialized(false)
{
	c_random_engine.seed(iRandomSeed);
	pc_best = nullptr;
	i_genotype_length = pcProblem->pcGetEvaluation()->iGetNumberOfElements();
	d_alpha = D_DEFAULT_ALPHA;
}//CBinaryBatOptimizer::CBinaryBatOptimizer(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog* pcLog, uint32_t iRandomSeed)


CBinaryBatOptimizer::CBinaryBatOptimizer(CBinaryBatOptimizer* pcOther) :
	CPopulationSizingSingleOptimizer<CBinaryCoding, CBinaryCoding>(pcOther),
	c_position_distribution(pcOther->c_position_distribution),
	c_uniform_zero_one_distribution(pcOther->c_uniform_zero_one_distribution),
	c_random_engine(pcOther->c_random_engine)
{
	b_is_initialized = pcOther->b_is_initialized;
	i_genotype_length = pcOther->i_genotype_length;
	i_population_size = pcOther->i_population_size;
	d_loudness_a = pcOther->d_loudness_a;
	d_pulse_rate_r = pcOther->d_pulse_rate_r;
	d_frequency_q_min = pcOther->d_frequency_q_min;
	d_frequency_q_max = pcOther->d_frequency_q_max;
	d_lower_bound = pcOther->d_lower_bound;
	d_upper_bound = pcOther->d_upper_bound;
	d_alpha = pcOther->	d_alpha;
	b_use_stale_detection = pcOther->b_use_stale_detection;

	for(size_t i = 0; i < pcOther->v_population.size(); i++)
	{
		v_population.push_back(new CBinaryBatIndividual(*pcOther->v_population[i]));
	}//for(size_t i = 0; i < pcOther->v_population.size(); i++)

	if(pcOther->pc_best != nullptr)
	{
		pc_best = new CBinaryBatIndividual(*pcOther->pc_best);
	}//if(pcOther->pc_best != nullptr)
	else
	{
		pc_best = nullptr;
	}//else if(pcOther->pc_best != nullptr)
	
} //CBinaryBatOptimizer::CBinaryBatOptimizer(CBinaryBatOptimizer* pcOther) : CPopulationSizingSingleOptimizer<CBinaryCoding, CBinaryCoding>(pcOther)

CBinaryBatOptimizer::~CBinaryBatOptimizer()
{
	for (size_t i = 0; i < v_population.size(); i++)
	{
		delete v_population[i];
	}//for (size_t i = 0; i < v_population.size(); i++)

	if (pc_best != nullptr)
	{
		delete pc_best;
		pc_best = nullptr;
	}//if (pc_best != nullptr)
}//CBinaryBatOptimizer::~CBinaryBatOptimizer()


COptimizer<CBinaryCoding, CBinaryCoding>* CBinaryBatOptimizer::pcCopy()
{
	CBinaryBatOptimizer* pc_copy = new CBinaryBatOptimizer(this);
	return pc_copy;
}//COptimizer<CBinaryCoding, CBinaryCoding>* CBinaryBatOptimizer::pcCopy()

double CBinaryBatOptimizer::dComputeAverageFitnessValue()
{
	double d_sum = 0;

	CBinaryBatIndividual *pc_individual;

	for (uint32_t i = 0; i < i_population_size; i++)
	{
		pc_individual = v_population[i];

		d_sum += pc_individual->d_fitness;
	}//for (uint32_t i = 0; i < i_population_size; i++)

	return d_sum / (double)i_population_size;
}//double CBinaryBatOptimizer::dComputeAverageFitnessValue()

bool CBinaryBatOptimizer::bIsSteadyState()
{
	if (!b_use_stale_detection)
	{
		return false;
	}//if (!b_stale_detection)

	bool b_different_found = false;

	for (size_t ii = 1; !b_different_found && ii < v_population.size(); ii++)
	{
		bool b_all_same = true;

		for (size_t j = 0; b_all_same && j < i_genotype_length; j++)
		{
			if (v_population[0]->v_genotype[j] != v_population[ii]->v_genotype[j])
			{
				b_all_same = false;
			}//if (v_population[0]->v_genotype[j] != v_population[ii]->v_genotype[j])
		}//for (size_t j = 0; b_all_same && j < i_genotype_length; j++)

		if (!b_all_same)
		{
			b_different_found = true;
		}//if (!b_all_same)
	}//for (size_t ii = 1; !b_different_found && ii < v_population.size(); ii++)

	return !b_different_found;

}//bool CBinaryBatOptimizer::bIsSteadyState()

bool CBinaryBatOptimizer::bRunIteration(uint32_t iIterationNumber)
{
	CString s_log_message;

	s_log_message.Format("Best fitness: %f; ffe: %llu; time: %2.lf; pop_size: %u", pc_best_individual->dGetFitnessValue(), pc_problem->pcGetEvaluation()->iGetFFE(), c_optimizer_timer.dGetTimePassed(), i_population_size);
	pc_log->vPrintLine(s_log_message, true);
	bool b_best_updated = false;

	for (size_t i = 0; i < i_population_size; i++)
	{
		CBinaryBatIndividual* pc_individual = v_population[i];
		pc_individual->vUpdateFrequency(d_frequency_q_min, d_frequency_q_max, c_uniform_zero_one_distribution, c_random_engine);
		pc_individual->vUpdateVelocity(*pc_best);
		
		CBinaryBatIndividual* pc_temp_individual = new CBinaryBatIndividual(*pc_individual);
		pc_temp_individual->vUpdatePosition();

		double d_prob = c_uniform_zero_one_distribution(c_random_engine);
		if (d_prob > pc_individual->d_pulse_rate_r)
		{
			delete pc_temp_individual;
			pc_temp_individual = pcGetRandomIndividual();
			for (size_t j = 0; j < i_genotype_length; j++)
			{
				double d_random_number = c_uniform_zero_one_distribution(c_random_engine);
				pc_temp_individual->v_position[j] = pc_best->v_position[j] + 0.001 * d_random_number;
			}//for (size_t j = 0; j < i_genotype_length; j++)
		}//if (d_prob > pc_individual->d_pulse_rate_r)
		pc_temp_individual->v_check_bounds(d_lower_bound, d_upper_bound);

		double d_fitness = dEvaluate(*pc_temp_individual);

		d_prob = c_uniform_zero_one_distribution(c_random_engine);

		if (pc_problem->bIsBetterFitnessValue(d_fitness, v_population[i]->d_fitness) && (d_prob < v_population[i]->d_loudness_a))
		{
			delete v_population[i];
			v_population[i] = pc_temp_individual;
			v_population[i]->vUpdatePulseRateR(d_alpha, d_pulse_rate_r, (iIterationNumber + 1)); //+1 because they start counting iterations at 1
			v_population[i]->vUpdateLoudnessA(d_alpha, d_loudness_a);
		}//if (pc_problem->bIsBetterFitnessValue(d_fitness, v_population[i]->d_fitness) && (d_prob < v_population[i]->d_loudness_a))
		else
		{
			delete pc_temp_individual;
		}//else

		b_best_updated = bMaybeUpdateBest(*v_population[i], iIterationNumber) || b_best_updated;
	}//for (size_t i = 0; i < i_population_size; i++)
	return b_best_updated;
}//bool CBinaryBatOptimizer::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)

CError CBinaryBatOptimizer::eConfigure(istream* psSettings)
{
	CError c_error(iERROR_PARENT_CBinaryBatOptimizer);
	c_error = COptimizer::eConfigure(psSettings);

	if (!c_error)
	{
		CUIntCommandParam p_population_size(BINARY_BAT_OPTIMIZER_ARGUMENT_POPULATION_SIZE, 2, UINT32_MAX);
		i_population_size = p_population_size.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		CFloatCommandParam p_frequency_q_min(BINARY_BAT_OPTIMIZER_ARGUMENT_FREQUENCY_Q_MIN, F_DEFAULT_FREQUENCY_Q_MIN);
		d_frequency_q_min = static_cast<double>(p_frequency_q_min.fGetValue(psSettings, &c_error));
	}//if (!c_error)

	if (!c_error)
	{
		CFloatCommandParam p_frequency_q_max(BINARY_BAT_OPTIMIZER_ARGUMENT_FREQUENCY_Q_MAX, F_DEFAULT_FREQUENCY_Q_MAX);
		d_frequency_q_max = static_cast<double>(p_frequency_q_max.fGetValue(psSettings, &c_error));
	}//if (!c_error)

	if (!c_error)
	{
		CFloatCommandParam p_loudness_a(BINARY_BAT_OPTIMIZER_ARGUMENT_LOUDNESS_A, F_DEFAULT_LOUDNESS_A);
		d_loudness_a = static_cast<double>(p_loudness_a.fGetValue(psSettings, &c_error));
	}//if (!c_error)

	if (!c_error)
	{
		CFloatCommandParam p_pulse_rate_r(BINARY_BAT_OPTIMIZER_ARGUMENT_PULSE_RATE_R, F_DEFAULT_PULSE_RATE_R);
		d_pulse_rate_r = static_cast<double>(p_pulse_rate_r.fGetValue(psSettings, &c_error));
	}//if (!c_error)

	if (!c_error)
	{
		CBoolCommandParam p_stale_detection(BINARY_BAT_OPTIMIZER_ARGUMENT_STALE_DETECTION, true, false);
		b_use_stale_detection = p_stale_detection.bGetValue(psSettings, &c_error);
	}//if (!c_error)


	return c_error;
}//CError CBinaryBatOptimizer::eConfigure(istream* psSettings)

CBinaryBatIndividual* CBinaryBatOptimizer::pcGetRandomIndividual()
{
	return CBinaryBatIndividual::pcGetRandomIndividual(i_genotype_length, d_frequency_q_min, d_frequency_q_max,
		d_pulse_rate_r, d_loudness_a, c_position_distribution, c_uniform_zero_one_distribution, c_random_engine);
}//CBinaryBatIndividual* CBinaryBatOptimizer::pcGetRandomIndividual()

void CBinaryBatOptimizer::vDeleteIndividuals()
{
	if(b_is_initialized)
	{
		delete pc_best;
		pc_best = nullptr;
		for (size_t i = 0; i < v_population.size(); i++)
		{
			delete v_population[i];
			v_population[i] = nullptr;
		}//for (size_t i = 0; i < i_population_size; i++)
	}//if(b_is_initialized)
	b_is_initialized = false;
}//void CBinaryBatOptimizer::vDeleteIndividuals()

void CBinaryBatOptimizer::vEvaluate(uint32_t iIterationNumber)
{
	for(size_t i = 0; i < i_population_size; i++)
	{
		dEvaluate(*v_population[i]);
		bMaybeUpdateBest(*v_population[i], iIterationNumber);
	}//for(size_t i = 0; i < i_population_size; i++)
}//void CBinaryBatOptimizer::vEvaluate(uint32_t iIterationNumber, time_t tStartTime)

double CBinaryBatOptimizer::dEvaluate(CBinaryBatIndividual& cIndividual)
{
	CBinaryCoding c_coding(i_genotype_length, cIndividual.v_genotype.data());
	double d_fitness_value = pcGetProblem()->pcGetEvaluation()->dEvaluate(&c_coding);
	cIndividual.d_fitness = d_fitness_value;
	return d_fitness_value;
}//double CBinaryBatOptimizer::dEvaluate(CBinaryBatIndividual& cIndividual)

void CBinaryBatOptimizer::vInitializeIndividuals()
{
	//https://github.com/jppbsi/LibOPT/blob/d2128e9f0715583b8a31830269aa1b6395dcc404/src/common.c#L920
	v_population.resize(i_population_size, nullptr);

	for(size_t i = 0; i < i_population_size; i++)
	{
		v_population[i] = pcGetRandomIndividual();
	}//for(size_t i = 0; i < i_population_size; i++)
	vEvaluate(0);
}//void CBinaryBatOptimizer::vInitializeIndividuals()

void CBinaryBatOptimizer::vInitialize()
{
	c_optimizer_timer.vSetStartNow();
	vResetBestIndividual();
	vDeleteIndividuals();
	vInitializeIndividuals();
	b_is_initialized = true;
}//void CBinaryBatOptimizer::vInitialize(time_t tStartTime)

bool CBinaryBatOptimizer::bMaybeUpdateBest(CBinaryBatIndividual& cPossiblyNewBest, uint32_t iIterationNumber)
{
	if (pc_best == nullptr || pc_problem->bIsBetterFitnessValue(cPossiblyNewBest.d_fitness, pc_best->d_fitness))
	{
		delete pc_best;
		pc_best = new CBinaryBatIndividual(cPossiblyNewBest);
		b_update_best_individual(iIterationNumber, pc_best->d_fitness, [&](CBinaryCoding *pcBestGenotype)
		{
			for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
			{
				*(pcBestGenotype->piGetBits() + i) = pc_best->v_genotype[i];
			}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
		});
		return true;
	}//if (pc_best == nullptr || pc_problem->bIsBetterFitnessValue(cPossiblyNewBest.d_fitness, pc_best->d_fitness))
	return false;
}//void CBinaryBatOptimizer::vMaybeUpdateBest(CBinaryBatIndividual& cPossiblyNewBest, uint32_t iIterationNumber, time_t tStartTime)

CBinaryBatIndividual::CBinaryBatIndividual(uint16_t iGenotypeLength) : d_frequency(0), d_base_pulse_rate(0), d_pulse_rate_r(0), d_loudness_a(0),
                                                                  d_fitness(0),
                                                                  v_position(iGenotypeLength, static_cast<double>(0)),
                                                                  v_velocity(iGenotypeLength, static_cast<double>(0)),
                                                                  v_genotype(iGenotypeLength, static_cast<int32_t>(0))
{
}//CBinaryBatIndividual::CBinaryBatIndividual(uint16_t iGenotypeLength)

CBinaryBatIndividual* CBinaryBatIndividual::pcGetRandomIndividual(
	uint16_t iGenotypeLength,
	double dFMin,
	double dFMax,
	double dMaxPulseRateR,
	double dMaxLoudnessA,
	uniform_real_distribution<double>& cPositionDistribution,
	uniform_real_distribution<double>& cUniformDistribution,
	default_random_engine& cRandomEngine)
{
	CBinaryBatIndividual* pc_individual = new CBinaryBatIndividual(iGenotypeLength);
	for(size_t i = 0; i < iGenotypeLength; i++)
	{
		pc_individual->v_position[i] = cPositionDistribution(cRandomEngine);
	}//for(size_t i = 0; i < iGenotypeLength; i++)

	pc_individual->d_frequency = uniform_real_distribution<double>(dFMin, dFMax)(cRandomEngine);
	pc_individual->d_base_pulse_rate = uniform_real_distribution<double>(0, dMaxPulseRateR)(cRandomEngine);
	pc_individual->d_pulse_rate_r = pc_individual->d_base_pulse_rate;
	pc_individual->d_loudness_a = uniform_real_distribution<double>(0, dMaxLoudnessA)(cRandomEngine);
	
	pc_individual->v_transform_sigmoid(cUniformDistribution, cRandomEngine);
	
	return pc_individual;
}//CBinaryBatIndividual* CBinaryBatIndividual::pcGetRandomIndividual(

void CBinaryBatIndividual::vUpdatePosition()
{
	size_t i_position_length = v_position.size();
	for (size_t i = 0; i < i_position_length; i++)
	{
		v_position[i] = v_position[i] + v_velocity[i];
	}//for (size_t i = 0; i < i_position_length; i++)
}//void CBinaryBatIndividual::vUpdatePosition()


void CBinaryBatIndividual::vUpdateVelocity(CBinaryBatIndividual& cGlobalBest)
{
	size_t i_velocity_length = v_velocity.size();
	for (size_t i = 0; i < i_velocity_length; i++)
	{
		v_velocity[i] = v_velocity[i] + (v_position[i] - cGlobalBest.v_position[i]) * d_frequency;
	}//for (size_t i = 0; i < i_velocity_length; i++)
}//void CBinaryBatIndividual::vUpdateVelocity(CBinaryBatIndividual& cGlobalBest)

void CBinaryBatIndividual::vUpdateFrequency(
	double dFMin,
	double dFMax,
	uniform_real_distribution<double>& pcBetaValueDistribution,
	default_random_engine& cRandomEngine)
{
	double dBeta = pcBetaValueDistribution(cRandomEngine);
	d_frequency = dFMin + (dFMin - dFMax) * dBeta;
}//void CBinaryBatIndividual::vUpdateFrequency(

void CBinaryBatIndividual::vUpdatePulseRateR(double dAlpha, double dBasePulseRate, uint32_t iIterationNumber)
{
	d_pulse_rate_r = dBasePulseRate * (1 - exp(-dAlpha * iIterationNumber));
}//void CBinaryBatIndividual::vUpdatePulseRateR(double dAlpha, double dBasePulseRate, uint32_t iIterationNumber)

void CBinaryBatIndividual::vUpdateLoudnessA(double dAlpha, double dBaseLoudness)
{
	d_loudness_a = dBaseLoudness * dAlpha;
}//void CBinaryBatIndividual::vUpdateLoudnessA(double dAlpha, double dBaseLoudness)

void CBinaryBatIndividual::v_transform_sigmoid(uniform_real_distribution<double>& cThresholdDistribution, default_random_engine& cRandomEngine)
{
	size_t i_position_length = v_position.size();
	for (size_t i = 0; i < i_position_length; i++)
	{
		double d_threshold = cThresholdDistribution(cRandomEngine);
		double d_transformed_position = 1.0 / (1.0 + exp(-1 * v_position[i])); //S2TransferFunction: https://github.com/jppbsi/LibDEV/blob/master/src/_featureselection_.c
		if (d_transformed_position > d_threshold)
		{
			v_genotype[i] = 1;
		}//if (dTransformedPosition > dThreshold)
		else
		{
			v_genotype[i] = 0;
		}//else if (dTransformedPosition > dThreshold)
	}//for (size_t i = 0; i < i_position_length; i++)
}//void CBinaryBatIndividual::v_transform_sigmoid(uniform_real_distribution<double>& cThresholdDistribution, default_random_engine& cRandomEngine)

void CBinaryBatIndividual::v_check_bounds(double dLowerBound, double dUpperBound)
{
	for (size_t i = 0; i < v_position.size(); i++) 
	{
		if (v_position[i] < dLowerBound)
		{
			v_position[i] = dLowerBound;
		}//if (v_position[i] < dLowerBound)
		else if (v_position[i] > dUpperBound)
		{
			v_position[i] = dUpperBound;
		}//else if (v_position[i] > dUpperBound)
	}//for (size_t i = 0; i < v_position.size(); i++)
}//void CBinaryBatIndividual::v_check_bounds(double dLowerBound, double dUpperBound)
