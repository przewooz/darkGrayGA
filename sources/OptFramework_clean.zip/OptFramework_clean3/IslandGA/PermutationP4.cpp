#include "PermutationP4.h"

#include "CommandParam.h"
#include "UIntCommandParam.h"

CPermutationP4::CPermutationP4(CProblem<CRealCoding, CPermutationCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed)
	: COptimizer<CRealCoding, CPermutationCoding>(pcProblem, pcLog, iRandomSeed)
{
	//pc_permut_p4_problem = new IGA_frameworkProblem();

	pc_permutation_p4 = new NPermutationP4::Pyramid(pcProblem->pcGetEvaluation(), pcProblem->pcGetTransformation(), pcLog, iRandomSeed);
}//CPermutationGOMEA::CPermutationGOMEA(CProblem<CRealCoding, CPermutationCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed

CPermutationP4::CPermutationP4(CPermutationP4 *pcOther)
	: COptimizer<CRealCoding, CPermutationCoding>(pcOther)
{
	pc_permutation_p4 = NULL;
}//CPermutationGOMEA::CPermutationGOMEA(CPermutationGOMEA *pcOther)

CError CPermutationP4::eConfigure(istream *psSettings)
{
	CError c_error = COptimizer<CRealCoding, CPermutationCoding>::eConfigure(psSettings);

	if (!c_error)
	{
		CUIntCommandParam p_count_empirical_dsm(
			PERMUTATION_P4_ARGUMENT_COUNT_EMPIRICAL_DSM, 
			PERMUTATION_P4_ARGUMENT_COUNT_EMPIRICAL_DSM_NONE, PERMUTATION_P4_ARGUMENT_COUNT_EMPIRICAL_DSM_RANDOM
		);
		i_count_empirical_dsm = p_count_empirical_dsm.iGetValue(psSettings, &c_error);

		if (!c_error)
		{
			if (i_count_empirical_dsm == PERMUTATION_P4_ARGUMENT_COUNT_EMPIRICAL_DSM_PURE_EMPIRICAL)
			{
				pc_permutation_p4->setNullLinkage(true);
			}//if (i_count_empirical_dsm == PERMUTATION_P4_ARGUMENT_COUNT_EMPIRICAL_DSM_PURE_EMPIRICAL)


			if (i_count_empirical_dsm == PERMUTATION_P4_ARGUMENT_COUNT_EMPIRICAL_DSM_RANDOM)
			{
				pc_permutation_p4->setRandomLinkage(1);
			}//if (i_count_empirical_dsm == PERMUTATION_P4_ARGUMENT_COUNT_EMPIRICAL_DSM_PURE_EMPIRICAL)
		}//if (!c_error)
	}//if (!c_error)

	return c_error;
}//CError CPermutationGOMEA::eConfigure(istream *psSettings)

void CPermutationP4::vInitialize()
{
	c_optimizer_timer.vSetStartNow();
	if (i_count_empirical_dsm == PERMUTATION_P4_ARGUMENT_COUNT_EMPIRICAL_DSM_HYBRID || i_count_empirical_dsm == PERMUTATION_P4_ARGUMENT_COUNT_EMPIRICAL_DSM_PURE_EMPIRICAL)
	{
		pc_permutation_p4->updateEmpiricalDSM();
	}//if (i_count_empirical_dsm == PERMUTATION_P4_ARGUMENT_COUNT_EMPIRICAL_DSM_HYBRID || i_count_empirical_dsm == PERMUTATION_P4_ARGUMENT_COUNT_EMPIRICAL_DSM_PURE_EMPIRICAL)
}//void CPermutationP4::vInitialize(time_t tStartTime)

bool CPermutationP4::bRunIteration(uint32_t iIterationNumber)
{
	pc_permutation_p4->runSingleIteration();

	bool b_updated = b_update_best_individual(iIterationNumber);

	CString s_log_message;

	s_log_message.Format
	(
		"best fitness: %f; ffe: %u; time: %.2lf",
		pc_best_individual->dGetFitnessValue(),
		pc_problem->pcGetEvaluation()->iGetFFE(),
		c_optimizer_timer.dGetTimePassed()
	);//s_log_message.Format

	pc_log->vPrintLine(s_log_message, true);

	return b_updated;
}//bool CPermutationP4::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)

void CPermutationP4::vRun()
{
	COptimizer<CRealCoding, CPermutationCoding>::vRun();
	//c_permutation_gomea.ezilaitini();
}//void CPermutationP4::vRun()


bool CPermutationP4::b_update_best_individual(uint32_t iIterationNumber)
{
	bool b_updated = b_update_best_individual(iIterationNumber, pc_permutation_p4->getBestSolution()->getFitness(), [&](CRealCoding *pcBestGenotype)
	{
		bool  b_can_rate;

		//::MessageBox(NULL, "a", "a", MB_OK);

		b_can_rate = false;
		if (pc_permutation_p4 != NULL)
		{
			//::MessageBox(NULL, "a1", "a1", MB_OK);
			if (pc_permutation_p4->getBestSolution() != NULL)	b_can_rate = true;
		}//if (pc_permutation_p4 != NULL)

		if (b_can_rate == true)
		{
			//CString  s_buf;
			//FILE  *pf_test;
			//pf_test = fopen("zzzzzzzztest.txt", "w+");

			//s_buf.Format("Fit: %lf\n", pc_permutation_p4->getBestSolution()->getFitness());			
			//fprintf(pf_test, s_buf);

			//double  d_test_fitness;
			//d_test_fitness = pc_permutation_p4->evaluate(pc_permutation_p4->getBestSolution()->getPhenotype());
			//s_buf.Format("FitTest: %lf\n", d_test_fitness);
			//fprintf(pf_test, s_buf);
			
			for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
			{
				*(pcBestGenotype->pdGetValues() + i) = pc_permutation_p4->getBestSolution()->getGenotype().at(i);
				//s_buf.Format("%lf\n", pc_permutation_p4->getBestSolution()->getGenotype().at(i));
				//fprintf(pf_test, s_buf);
			}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)

			//fprintf(pf_test, "\n");

			/*for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
			{
				*(pcBestGenotype->pdGetValues() + i) = pc_permutation_p4->getBestSolution()->getPhenotype().at(i);
				*(pcBestGenotype->pdGetValues() + i) = *(pcBestGenotype->pdGetValues() + i) / pc_problem->pcGetEvaluation()->iGetNumberOfElements();


				//s_buf.Format("%d\n", pc_permutation_p4->getBestSolution()->getPhenotype().at(i));
				//fprintf(pf_test, s_buf);
			}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)*/



			//fclose(pf_test);
			//::MessageBox(NULL, "ok", "ok", MB_OK);
		}//if (b_can_rate)
	});//bool b_updated = b_update_best_individual(iIterationNumber, tStartTime, c_permutation_gomea.getElitistSolutionObjectiveValue(), [&](CRealCoding *pcBestGenotype)

	return b_updated;
}//bool CPermutationGOMEA::b_update_best_individual(uint32_t iIterationNumber, time_t tStartTime)