#ifndef PERMUTATION_GOMEA_H
#define PERMUTATION_GOMEA_H

#define PERMUTATION_GOMEA_ARGUMENT_FOSS_STRUCTURE_INDEX "FOSs_structure_index"
#define PERMUTATION_GOMEA_ARGUMENT_COUNT_EMPIRICAL_DSM "count_empirical_dsm (0-none; 1-hybrid; 2-pureEmpirical)"

#include "Error.h"
#include "Log.h"
#include "Optimizer.h"
#include "PermutationCoding.h"
#include "Problem.h"
#include "RealCoding.h"

#include "../PermutationGOMEA/PermutationGOMEA.h"

#include <ctime>
#include <cstdint>
#include <istream>

using namespace std;

class CPermutationGOMEA : public COptimizer<CRealCoding, CPermutationCoding>
{
public:
	CPermutationGOMEA(CProblem<CRealCoding, CPermutationCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed);
	CPermutationGOMEA(CPermutationGOMEA *pcOther);

	virtual COptimizer<CRealCoding, CPermutationCoding> *pcCopy() { return new CPermutationGOMEA(this); };

	virtual CError eConfigure(istream *psSettings);

	virtual void vInitialize();
	virtual bool bRunIteration(uint32_t iIterationNumber);

	virtual void vRun();

private:
	using COptimizer<CRealCoding, CPermutationCoding>::b_update_best_individual;
	bool b_update_best_individual(uint32_t iIterationNumber);

	NPermutationGOMEA::PermutationGOMEA c_permutation_gomea;
};//class CPermutationGOMEA : public COptimizer<CRealCoding, CPermutationCoding>

#endif//PERMUTATION_GOMEA_H