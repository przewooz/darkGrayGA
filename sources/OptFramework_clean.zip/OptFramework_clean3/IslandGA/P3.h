#ifndef P3_H
#define P3_H

#define P3_ARGUMENT_FEEDBACK "with_feedback"
#define P3_ARGUMENT_FEEDBACK_PROBABILITY "feedback_probability"

#define P3_ARGUMENT_CLUSTERS_ORDER_SEP_LINKAGE "clustersOrder(0-ordered; 1-random)"
#define P3_ARGUMENT_OPT_AT_INIT "opt_at_init(0-randInit; 1-fihcInit)"

#define P3_ARGUMENT_SUPERCROSS_WITH_BEST "super_cross_with_best"
#define P3_ARGUMENT_SUPERCROSS_WITH_BEST_ONLY_FINAL_CLIMB "super_cross_with_best_only_final_climb"
#define P3_ARGUMENT_SUPERCROSS_WITH_BEST_ONLY_FINAL_CLIMB_LINKAGE_ACCUMULATION "super_cross_with_best_only_final_climb_linkage_accumulation"


#define P3_ARGUMENT_MAX_PYRAMID_LEVEL "max_pyramid_level"
#define P3_ARGUMENT_MAX_PYRAMID_POP "max_pyramid_pop"
#define P3_ARGUMENT_MAX_PYRAMID_POP_UNLIMITED_LINKAGE "max_pyramid_pop_unlimited_linkage"

#define P3_ARGUMENT_BBEMPOWER "bb_empower"
#define P3_ARGUMENT_GB_BEST_BREAKER "gb_best_breaker"


#include "BinaryCoding.h"
#include "Error.h"
#include "Log.h"
#include "LinkageAnalyzer.h"
#include "P3BasedOptimizer.h"
#include "Optimizer.h"
#include "Problem.h"

#include "MultiObjectiveOptimizer.h"
#include "BinaryOptimizer.h"
#include "BinaryEvaluationMultiObjective.h"

#include "../P3/Pyramid.h"

#include <atlstr.h>
#include <cstdint>
#include <ctime>
#include <istream>

using namespace std;

class CIncrementalP3;
class CIslandModelP3;

namespace DynamicOptimizer
{
	class CDynamicP3;
}//namespace DynamicOptimizer

class CP3 : public CP3BasedOptimizer
{
friend class CIncrementalP3;
friend class CIslandModelP3;
friend class DynamicOptimizer::CDynamicP3;

public:
	CP3(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed);
	CP3(CP3 *pcOther);

	virtual CError eConfigure(istream *psSettings);

	virtual COptimizer<CBinaryCoding, CBinaryCoding> *pcCopy() { return new CP3(this); };


	virtual void vInitialize();
	virtual bool bRunIteration(uint32_t iIterationNumber);
	virtual bool bRunIterationSeparateLinkage(uint32_t iIterationNumber, CLinkageAnalyzer  *pcSeparateLinkage);
	virtual void vReportLinkage();
	void vReportPopStats(CString  sFileName);
	virtual void vExecuteBeforeEnd();
	
	void  vGetSlideInformation(double  *pdSlides, double  *pdBlockedSlides) { *pdSlides = pc_p3->iGetSlideOK(); *pdBlockedSlides = pc_p3->iGetSlideBlocked(); };

	virtual void vRun();


	vector<bool> * pvGetLastAdded();

	int  iLevelsGetNumber();
	void  vLevelsRemoveLowest();
	bool bClimb(CBinaryCoding *pcGenotype, uint32_t iIterationNumber);
	bool bAdd(CBinaryCoding *pcGenotype, uint32_t iIterationNumber);

private:
	CString s_create_linkage_report();
	void v_log_linkage(bool bEcho = false);

	bool b_with_feedback;
	float f_feedback_probability;

	int  i_sep_link_clusters_order;
	int  i_opt_at_init;

	int  i_max_pyramid_level;
	int  i_max_pop_size;
	int  i_max_pop_unlimited_linkage;
	
	uint32_t i_feedback_counter;
	uint32_t i_effective_feedback_counter;

	shared_ptr<Pyramid> pc_p3;
};//class CP3 : public COptimizer<CBinaryCoding, CBinaryCoding>





class  CMO_MPP3 : public CBinaryMultiObjectiveOptimizer  //CBinaryOptimizer
{
public:
	static uint32_t iERROR_PARENT_CMO_MPP3_Optimizer;
	static uint32_t iERROR_CODE_CMO_MPP3_GENOTYPE_LEN_BELOW_0;


	CMO_MPP3(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed);
	CMO_MPP3(CMO_MPP3 *pcOther);
	~CMO_MPP3();


	virtual COptimizer<CBinaryCoding, CBinaryCoding> *pcCopy() { return new CMO_MPP3(this); };

	virtual CError eConfigure(istream *psSettings);

	virtual void vInitialize();
	virtual bool bRunIteration(uint32_t iIterationNumber);
	bool bRunIteration_dummy(uint32_t iIterationNumber);

	
private:
	bool b_update_best_individual(uint32_t iIterationNumber);


	TimeCounters::CTimeCounter  c_time_counter;
	time_t t_start;

	int  i_templ_length;

	CP3  *pc_clear_p3;

	vector<CP3 *>  v_p3;
	vector<int>  v_improved_pf_tool;
	int  i_pop_p3_number;


};//class  CMO_MPP3 : public CBinaryMultiObjectiveOptimizer  //CBinaryOptimizer

#endif//P3_H