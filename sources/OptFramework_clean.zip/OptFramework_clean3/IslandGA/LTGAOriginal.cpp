#include "LTGAOriginal.h"

#include "CommandParam.h"
#include "PopulationOptimizer.h"
#include "RandUtils.h"
#include "UIntCommandParam.h"

#include <algorithm>

CLTGAOriginal::CLTGAOriginal(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed)
	: COptimizer<CBinaryCoding, CBinaryCoding>(pcProblem, pcLog, iRandomSeed), c_ltga(pcProblem->pcGetEvaluation(), pcLog, (int64_t)RandUtils::iRandNumber((uint32_t)0, UINT32_MAX - 1))
{
	v_ltga_individual.resize((size_t)pcProblem->pcGetEvaluation()->iGetNumberOfElements());
}//CLTGAOriginal::CLTGAOriginal(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed)

CLTGAOriginal::CLTGAOriginal(CLTGAOriginal *pcOther)
	: COptimizer<CBinaryCoding, CBinaryCoding>(pcOther), c_ltga(pcOther->pc_problem->pcGetEvaluation(), pcOther->pc_log, (int64_t)RandUtils::iRandNumber((uint32_t)0, UINT32_MAX - 1))
{
	c_ltga.setPopulationSize(pcOther->c_ltga.getPopulationSize());
	c_ltga.setDoLocalSearch(pcOther->c_ltga.getDoLocalSearch());
	c_ltga.setSlide(pcOther->c_ltga.getSlide());
	c_ltga.setAvoidFI(pcOther->c_ltga.getAvoidFI());
	c_ltga.setLocalSearchOneIteration(pcOther->c_ltga.getLocalSearchOneIteration());
	c_ltga.setWithoutTournamentSelection(pcOther->c_ltga.getWithoutTournamentSelection());
	c_ltga.setLinkageTreeRandomOrder(pcOther->c_ltga.getLinkageTreeRandomOrder());
	
	v_ltga_individual.resize(pcOther->v_ltga_individual.size());
}//CLTGAOriginal::CLTGAOriginal(CLTGAOriginal *pcOther)

CError CLTGAOriginal::eConfigure(istream *psSettings)
{
	CError c_error = COptimizer<CBinaryCoding, CBinaryCoding>::eConfigure(psSettings);

	if (!c_error)
	{
		CUIntCommandParam p_population_size(POPULATION_OPTIMIZER_ARGUMENT_POPULATION_SIZE);
		vSetPopulationSize(p_population_size.iGetValue(psSettings, &c_error));
	}//if (!c_error)

	if (!c_error)
	{
		CBoolCommandParam p_do_local_search(LTGA_ORIGINAL_ARGUMENT_DO_LOCAL_SEARCH);
		c_ltga.setDoLocalSearch(p_do_local_search.bGetValue(psSettings, &c_error));
	}//if (!c_error)

	if (!c_error)
	{
		if (c_ltga.getDoLocalSearch())
		{
			CBoolCommandParam p_local_search_one_iteration(LTGA_ORIGINAL_ARGUMENT_LOCAL_SEARCH_ONE_ITERATION);
			c_ltga.setLocalSearchOneIteration(p_local_search_one_iteration.bGetValue(psSettings, &c_error));
		}//if (c_ltga.getDoLocalSearch())
	}//if (!c_error)

	
	if (!c_error)
	{
		CFloatCommandParam p_slide(OPTIMIZER_ARGUMENT_SLIDE,false);

		double  d_slide;
		d_slide = p_slide.fGetValue(psSettings, &c_error);
		if (p_slide.bHasValue() == false)  d_slide = 1;
		if (d_slide >= 0)//-1 is the automatic slide
		{
			if ((d_slide < 0) || (d_slide > 1))  d_slide = 1;
		}//if (d_slide != -1)
		c_ltga.setSlide(d_slide);
	}//if (!c_error)


	if (!c_error)
	{
		CBoolCommandParam p_avoid_fi(LTGA_ORIGINAL_ARGUMENT_AVOID_FI);
		c_ltga.setAvoidFI(p_avoid_fi.bGetValue(psSettings, &c_error));
	}//if (!c_error)


	
	if (!c_error)
	{
		//CBoolCommandParam p_without_tournament_selection(LTGA_ORIGINAL_ARGUMENT_WITHOUT_TOURNAMENT_SELECTION, false, false);
		CBoolCommandParam p_without_tournament_selection(LTGA_ORIGINAL_ARGUMENT_WITHOUT_TOURNAMENT_SELECTION);
		c_ltga.setWithoutTournamentSelection(p_without_tournament_selection.bGetValue(psSettings, &c_error));
	}//if (!c_error)

	if (!c_error)
	{
		//CBoolCommandParam p_linkage_tree_random_order(LTGA_ORIGINAL_ARGUMENT_LINKAGE_TREE_RANDOM_ORDER, false, false);
		CBoolCommandParam p_linkage_tree_random_order(LTGA_ORIGINAL_ARGUMENT_LINKAGE_TREE_RANDOM_ORDER);
		c_ltga.setLinkageTreeRandomOrder(p_linkage_tree_random_order.bGetValue(psSettings, &c_error));
	}//if (!c_error)

	return c_error;
}//CError CLTGAOriginal::eConfigure(istream *psSettings)

void CLTGAOriginal::vInitialize()
{
	COptimizer<CBinaryCoding, CBinaryCoding>::vInitialize();

	c_ltga.initialize();
	c_ltga.updateBestPrevGenSolution();

	b_update_best_individual(0);
}//void CLTGAOriginal::vInitialize(time_t tStartTime)



bool CLTGAOriginal::bRunIterationSeparateLinkage(uint32_t iIterationNumber, CLinkageAnalyzer  *pcSeparateLinkage)
{
	return bRunIterationSeparateLinkage(iIterationNumber, nullptr, pcSeparateLinkage);
}//bool CLTGAOriginal::bRunIterationSeparateLinkage(uint32_t iIterationNumber, time_t tStartTime, CLinkageAnalyzer  *pcSeparateLinkage)


bool CLTGAOriginal::bRunIterationSeparateLinkage(uint32_t iIterationNumber, CIndividual<CBinaryCoding, CBinaryCoding> *pcBestIndividual, CLinkageAnalyzer  *pcSeparateLinkage)
{
	if (pcBestIndividual)
	{
		for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
		{
			v_ltga_individual.at(i) = *(pcBestIndividual->pcGetGenotype()->piGetBits() + i) == 1 ? TRUE : FALSE;
		}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)

		c_ltga.runGenerationSeparateLinkage(v_ltga_individual.data(), pcSeparateLinkage);
	}//if (pcBestIndividual)
	else
	{
		c_ltga.runGenerationSeparateLinkage(nullptr, pcSeparateLinkage);
	}//else if (pcBestIndividual)


	bool b_updated = b_update_best_individual(iIterationNumber);

	CString s_log_message;

	/*
	s_log_message.Format("best fitness: %f; best unitation: %f; ffe: %u; time: %u; population size: %u; avg fitness: %f; all the same: %d",
		pc_best_individual->dGetFitnessValue(), pc_best_individual->pcGetGenotype()->dGetUnitation(), pc_problem->pcGetEvaluation()->iGetFFE(),
		(uint32_t)(time(nullptr) - tStartTime), iGetPopulationSize(), dComputeAverageFitnessValue(), bAreAllIndividualsTheSame());
	*/

	s_log_message.Format("SeparateLinkage: best fitness: %f; best unitation: %f; ffe: %u; time: %.2lf; population size: %u",
		pc_best_individual->dGetFitnessValue(), pc_best_individual->pcGetGenotype()->dGetUnitation(), pc_problem->pcGetEvaluation()->iGetFFE(),
		c_optimizer_timer.dGetTimePassed(), iGetPopulationSize());

	
	double  d_prob_link_discovery_avr, d_prob_link_discovery_min, d_prob_link_discovery_max, d_linkage_fill;

	bool  b_link_stats = false;
	if (pcSeparateLinkage->bIsOutsideModeLinkageGenerating() == true)
		b_link_stats = c_ltga.pcGetLinkagePack()->bGetLinkageDiscoveryProbabilities(&d_prob_link_discovery_avr, &d_prob_link_discovery_min, &d_prob_link_discovery_max, &d_linkage_fill);
	else
		b_link_stats = pcSeparateLinkage->bGetLinkageDiscoveryProbabilities(&d_prob_link_discovery_avr, &d_prob_link_discovery_min, &d_prob_link_discovery_max, &d_linkage_fill, pc_problem->pcGetEvaluation()->iGetNumberOfElements());

	if (b_link_stats == true)
	{
		CString  s_prob_link_discovery_info;
		s_prob_link_discovery_info.Format(" LinkDiscoveryProbl(Av/MinMax/FILL): %.4lf %.4lf %.4lf %.4lf", d_prob_link_discovery_avr, d_prob_link_discovery_min, d_prob_link_discovery_max, d_linkage_fill);

		s_log_message += s_prob_link_discovery_info;
	}//if (b_link_stats == true)

	pc_log->vPrintLine(s_log_message, true);



	/*
	s_log_message.Format("best fitness: %f; best unitation: %f; ffe: %u; time: %u; population size: %u; avg fitness: %f; all the same: %d",
		pc_best_individual->dGetFitnessValue(), pc_best_individual->pcGetGenotype()->dGetUnitation(), pc_problem->pcGetEvaluation()->iGetFFE(),
		(uint32_t)(time(nullptr) - tStartTime), iGetPopulationSize(), dComputeAverageFitnessValue(), bAreAllIndividualsTheSame());
	*/

	CString  s_slide_info;
	if (c_ltga.getSlideCurrentIteration() == 1)  s_slide_info.Format(" SLIDING");
	if (c_ltga.getSlideCurrentIteration() == 0)  s_slide_info.Format(" NO SLIDE");
	if (c_ltga.getSlideCurrentIteration() <= 0)
	{
		double  d_perc;
		d_perc = c_ltga.iGetSlideBlocked();
		d_perc = d_perc / (c_ltga.iGetSlideOK() + c_ltga.iGetSlideBlocked());
		s_slide_info.Format(" autoSLIDE  slides:%d blockedSlides:%d  blockPerc: %.4lf", c_ltga.iGetSlideOK(), c_ltga.iGetSlideBlocked(), d_perc);
	}//if (c_ltga.getSlideCurrentIteration() == -1)


	s_log_message.Format("best fitness: %f; best unitation: %f; ffe: %u; time: %.2lf; population size: %u;  %d",
		pc_best_individual->dGetFitnessValue(), pc_best_individual->pcGetGenotype()->dGetUnitation(), pc_problem->pcGetEvaluation()->iGetFFE(),
		c_optimizer_timer.dGetTimePassed(), iGetPopulationSize(), s_slide_info);

	s_log_message += s_slide_info;

	pc_log->vPrintLine(s_log_message, true);


	return b_updated;
}//bool CLTGAOriginal::bRunIterationSeparateLinkage(uint32_t iIterationNumber, time_t tStartTime, CIndividual<CBinaryCoding, CBinaryCoding> *pcBestIndividual, CLinkageAnalyzer  *pcSeparateLinkage)



bool CLTGAOriginal::bRunIteration(uint32_t iIterationNumber)
{
	return bRunIteration(iIterationNumber, nullptr);
}//bool CLTGAOriginal::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)


bool CLTGAOriginal::bRunIteration(uint32_t iIterationNumber, CIndividual<CBinaryCoding, CBinaryCoding> *pcBestIndividual)
{
	if (pcBestIndividual)
	{
		for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
		{
			v_ltga_individual.at(i) = *(pcBestIndividual->pcGetGenotype()->piGetBits() + i) == 1 ? TRUE : FALSE;
		}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)

		c_ltga.runGeneration(v_ltga_individual.data());
	}//if (pcBestIndividual)
	else
	{
		c_ltga.runGeneration(nullptr);
	}//else if (pcBestIndividual)


	bool b_updated = b_update_best_individual(iIterationNumber);

	CString s_log_message;
	
	/*
	s_log_message.Format("best fitness: %f; best unitation: %f; ffe: %u; time: %u; population size: %u; avg fitness: %f; all the same: %d",
		pc_best_individual->dGetFitnessValue(), pc_best_individual->pcGetGenotype()->dGetUnitation(), pc_problem->pcGetEvaluation()->iGetFFE(), 
		(uint32_t)(time(nullptr) - tStartTime), iGetPopulationSize(), dComputeAverageFitnessValue(), bAreAllIndividualsTheSame());
	*/

	CString  s_slide_info;
	if (c_ltga.getSlideCurrentIteration() == 1)  s_slide_info.Format(" SLIDING");
	if (c_ltga.getSlideCurrentIteration() == 0)  s_slide_info.Format(" NO SLIDE");
	if (c_ltga.getSlideCurrentIteration() <= 0)
	{
		double  d_perc;
		d_perc = c_ltga.iGetSlideBlocked();
		d_perc = d_perc / (c_ltga.iGetSlideOK() + c_ltga.iGetSlideBlocked());
		s_slide_info.Format(" autoSLIDE  slides:%d blockedSlides:%d  blockPerc: %.4lf", c_ltga.iGetSlideOK(), c_ltga.iGetSlideBlocked(), d_perc);
	}//if (c_ltga.getSlideCurrentIteration() == -1)


	s_log_message.Format("best fitness: %f; best unitation: %f; ffe: %u; time: %.2lf; population size: %u;  %d",
		pc_best_individual->dGetFitnessValue(), pc_best_individual->pcGetGenotype()->dGetUnitation(), pc_problem->pcGetEvaluation()->iGetFFE(),
		c_optimizer_timer.dGetTimePassed(), iGetPopulationSize(), s_slide_info);

	s_log_message += s_slide_info;

	pc_log->vPrintLine(s_log_message, true);


	return b_updated;
}//bool CLTGAOriginal::bRunIteration(uint32_t iIterationNumber, time_t tStartTime, CIndividual<CBinaryCoding, CBinaryCoding> *pcBestIndividual)

void CLTGAOriginal::vRun()
{
	COptimizer<CBinaryCoding, CBinaryCoding>::vRun();
	c_ltga.ezilaitiniMemory();
}//void CLTGAOriginal::vRun()

bool CLTGAOriginal::b_update_best_individual(uint32_t iIterationNumber)
{
	bool b_updated = b_update_best_individual(iIterationNumber, c_ltga.getBestEverEvaluatedObjectiveValue(), [&](CBinaryCoding *pcBestGenotype)
	{
		for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
		{
			*(pcBestGenotype->piGetBits() + i) = *(c_ltga.getBestEverEvaluatedSolution() + i) == TRUE ? 1 : 0;
		}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
	});//bool b_updated = b_update_best_individual(iIterationNumber, tStartTime, c_ltga.getBestEverEvaluatedObjectiveValue(), [&](CBinaryCoding *pcBestGenotype)

	return b_updated;
}//bool CLTGAOriginal::b_update_best_individual(uint32_t iIterationNumber, time_t tStartTime)


void  CLTGAOriginal::vExecuteBeforeEnd()
{
	vReportLinkage();
}//void  CLTGAOriginal::vExecuteBeforeEnd()


void CLTGAOriginal::vReportLinkage()
{
	if (pc_linkage_analyzer != NULL)
	{
		double  d_perc;

		pc_linkage_analyzer->vSetLTGA_DSM(0, iGetPopulationSize(), pdGetDSM(), iGetDSMSize());
		pc_linkage_analyzer->vCreatePairsReportAndFlushDependentPairs();


		CString  s_buf, s_report;
		s_buf.Format("pop: %d  ", iGetPopulationSize());
		s_report = pc_linkage_analyzer->sGeneralCurrentReport();


		pc_log->vPrintLine("LINKAGE REPORT:" + s_buf + s_report, true);
	}//if (pc_linkage_analyzer != NULL)
}//void CLTGAOriginalPopulationSizing::vReportLinkage()