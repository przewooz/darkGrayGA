#pragma once

#include <vector>
#include <unordered_map>
using namespace std;

#include "cGomea_Config.h"
#include "cGomea_Population_P3_MI.h"
#include "cGomea_shared.h"
#include "cGomea_gomea.h"

class C_CGomea_gomeaP3_MI: public C_CGomea_GOMEA
{
public:
	int maximumNumberOfGOMEAs;
	int basePopulationSize, numberOfGOMEAs;

	vector<C_CGomea_Population_P3_MI*> GOMEAs;

	C_CGomea_gomeaP3_MI(C_CGomea_Config *config_);
	~C_CGomea_gomeaP3_MI();
	
	void initializeNewGOMEA();
	bool checkTermination();
	void GOMEAGenerationalSteps(int GOMEAIndex);
	void run();

	void  vRunSingleIteration();
	C_CGomea_Individual  *pcGetBestInd();
};