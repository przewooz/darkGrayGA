#include "P3BasedOptimizer.h"

#include "StringCommandParam.h"
#include "UIntCommandParam.h"

#include "../P3/Configuration.h"

#include <tuple>
#include <vector>

CP3BasedOptimizer::CP3BasedOptimizer(string sOptimizerName, CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed)
	: COptimizer<CBinaryCoding, CBinaryCoding>(pcProblem, pcLog, iRandomSeed), s_optimizer_name(sOptimizerName)
{
	pc_recorder = nullptr;

	b_multi_obj_domination_fitness_compare = false;
	b_multi_obj_domination_weight_vec = false;
	b_multi_obj_domination_weight_vec_pareto_front_based = false;
	d_last_hyper_volume = -1;
	d_last_weight_first = 0;
	d_last_weight_second = 0;

	pc_linkage_analyzer = 0;

	d_slide = 1;//by default we always slide

	b_no_bias_linkage_improver = false;

	pc_config = new Configuration();
	pc_rand = new Random(iRandomSeed);
}//CP3BasedOptimizer::CP3BasedOptimizer(string sOptimizerName, CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed)

CP3BasedOptimizer::CP3BasedOptimizer(CP3BasedOptimizer *pcOther)
	: COptimizer<CBinaryCoding, CBinaryCoding>(pcOther), s_optimizer_name(pcOther->s_optimizer_name)
{
	pc_recorder = nullptr;

	pc_config = pcOther->pc_config;
	pc_rand = pcOther->pc_rand;
	pc_linkage_analyzer = pcOther->pc_linkage_analyzer;

	b_no_bias_linkage_improver = pcOther->b_no_bias_linkage_improver;

	b_multi_obj_domination_fitness_compare = pcOther->b_multi_obj_domination_fitness_compare;
	b_multi_obj_domination_weight_vec = pcOther->b_multi_obj_domination_weight_vec;
	b_multi_obj_domination_weight_vec_pareto_front_based = pcOther->b_multi_obj_domination_weight_vec_pareto_front_based;
}//CP3BasedOptimizer::CP3BasedOptimizer(CP3BasedOptimizer *pcOther)

CP3BasedOptimizer::~CP3BasedOptimizer()
{
	delete pc_recorder;

	if (b_own_params)
	{
		delete pc_config;
		delete pc_rand;
	}//if (b_own_params)
}//CP3BasedOptimizer::~CP3BasedOptimizer()

CError CP3BasedOptimizer::eConfigure(istream *psSettings)
{
	CError c_error = COptimizer::eConfigure(psSettings);

	if (!c_error)
	{
		CFilePathCommandParam p_config_file_path(OPTIMIZER_ARGUMENT_CONFIG_FILE_PATH);
		CString s_config_path = p_config_file_path.sGetValue(psSettings, &c_error);

		if (!c_error)
		{
			uint32_t i_config_file_path_length = s_config_path.GetLength() + 1;
			char *pc_config_file_path = new char[i_config_file_path_length];
			strcpy_s(pc_config_file_path, i_config_file_path_length, s_config_path);

			pc_config->parse(pc_config_file_path);
			pc_config->set_injected_evaluation(pc_problem->pcGetEvaluation());
			pc_config->set("optimizer", s_optimizer_name);
			pc_config->set("problem", string("Injected"));
			pc_config->set("verbosity", 0);

			delete pc_config_file_path;
		}//if (!c_error)


		b_multi_obj_domination_fitness_compare = false;
		if (!c_error)
		{
			CBoolCommandParam p_multi_obj_domination_fitness(P3_ARGUMENT_MULTI_OBJ_DOMINATION_FITNESS, false);
			b_multi_obj_domination_fitness_compare = p_multi_obj_domination_fitness.bGetValue(psSettings, &c_error);

			if (p_multi_obj_domination_fitness.bHasValue() == false)  b_multi_obj_domination_fitness_compare = false;
		}//if (!c_error)

		//::Tools::vShow(b_multi_obj_domination_fitness_compare);

		b_multi_obj_domination_weight_vec = false;
		if (!c_error)
		{
			CBoolCommandParam p_multi_obj_weight_vec(P3_ARGUMENT_MULTI_OBJ_WEIGHT_VECTOR, false);
			b_multi_obj_domination_weight_vec = p_multi_obj_weight_vec.bGetValue(psSettings, &c_error);

			if (p_multi_obj_weight_vec.bHasValue() == false)  b_multi_obj_domination_weight_vec = false;
		}//if (!c_error)


		b_multi_obj_domination_weight_vec_pareto_front_based = false;
		if (!c_error)
		{
			CBoolCommandParam p_multi_obj_weight_vec_pareto_based(P3_ARGUMENT_MULTI_OBJ_WEIGHT_VECTOR_PARETO_BASED, false);
			b_multi_obj_domination_weight_vec_pareto_front_based = p_multi_obj_weight_vec_pareto_based.bGetValue(psSettings, &c_error);

			if (p_multi_obj_weight_vec_pareto_based.bHasValue() == false)  b_multi_obj_domination_weight_vec_pareto_front_based = false;
		}//if (!c_error)

				

	}//if (!c_error)

	return c_error;
}//CError CP3BasedOptimizer::eConfigure(istream *psSettings)

void CP3BasedOptimizer::vInitialize()
{
	COptimizer<CBinaryCoding, CBinaryCoding>::vInitialize();

	evaluation::pointer c_evaluation_ptr = pc_config->get<evaluation::pointer>("problem");
	optimize::pointer c_optimizer_ptr = pc_config->get<optimize::pointer>("optimizer");

	delete pc_recorder;
	pc_recorder = new Middle_Layer(*pc_config, c_evaluation_ptr(*pc_config, 0), pc_log);

	pc_optimizer = c_optimizer_ptr(*pc_rand, *pc_recorder, *pc_config);
}//void CP3BasedOptimizer::vInitialize(time_t tStartTime)



void CP3BasedOptimizer::vReportLinkage()
{
	pc_optimizer->vReportLinkage();
}//void CP3BasedOptimizer::vReportLinkage()



void  CP3BasedOptimizer::vExecuteBeforeEnd()
{
	pc_optimizer->vReportLinkage();
}//void  CP3BasedOptimizer::vExecuteBeforeEnd()


bool CP3BasedOptimizer::bRunIterationSeparateLinkage(uint32_t iIterationNumber, CLinkageAnalyzer  *pcSeparateLinkage)
{
	CString  s_buf;

	pc_optimizer->b_multi_obj_domination_fitness_compare = b_multi_obj_domination_fitness_compare;
	pc_optimizer->i_super_cross_with_best = i_super_cross_with_best;
	pc_optimizer->i_super_cross_with_best_only_final_climb = i_super_cross_with_best_only_final_climb;
	pc_optimizer->i_super_cross_with_best_only_final_climb_accumulate_linkage = i_super_cross_with_best_only_final_climb_accumulate_linkage;
	pc_optimizer->i_bb_empower = i_bb_empower;
	pc_optimizer->i_gb_best_breaker = i_gb_best_breaker;
	pc_optimizer->b_no_bias_linkage_improver = b_no_bias_linkage_improver;
	pc_optimizer->d_slide = d_slide;
	//pc_optimizer->b_multi_obj_domination_weight_vec = b_multi_obj_domination_weight_vec;
	//pc_optimizer->b_multi_obj_domination_weight_vec_pareto_front_based = b_multi_obj_domination_weight_vec_pareto_front_based;
	pc_optimizer->pc_linkage_analyzer = pc_linkage_analyzer;


	if (b_multi_obj_domination_weight_vec == true)
	{
		CBinaryMultiObjectiveProblem  *pc_multi_problem;
		pc_multi_problem = (CBinaryMultiObjectiveProblem  *)pc_problem->pcGetEvaluation();


		vector<CMultiObjectiveMeasure*>  *pv_mesaures;
		pv_mesaures = pc_multi_problem->pvGetMeasures();

		if (b_multi_obj_domination_weight_vec_pareto_front_based == true)
		{
			vector<CMultiIndividual  *>  *pv_current_global_pareto_front;
			pv_current_global_pareto_front = pc_multi_problem->pvGetGlobalParetoFront();

			vector<pair<double, double>>  v_directions;

			v_directions.push_back(pair<double, double>(0, 1));

			double  d_first, d_second, d_sum;
			for (int ii = 0; ii < pv_current_global_pareto_front->size(); ii++)
			{
				d_first = pv_current_global_pareto_front->at(ii)->pvGetFitness()->at(0);
				d_second = pv_current_global_pareto_front->at(ii)->pvGetFitness()->at(1);


				if ((d_first != 0) && (d_second != 0))
				{
					d_sum = d_first + d_second;
					d_first = d_first / d_sum;
					d_second = d_second / d_sum;

					v_directions.push_back(pair<double, double>(d_first, d_second));
				}//if ((d_first != 0) && (d_second != 0))


			}//for (int ii = 0; ii < pv_current_global_pareto_front->size(); ii++)

			v_directions.push_back(pair<double, double>(1, 0));


			d_first = 0;
			d_second = 0;

			int  i_interval_first, i_interval_second;
			double  d_interval_size_first, d_interval_size_second;

			i_interval_first = RandUtils::iRandNumber(0, v_directions.size() - 2);
			i_interval_second = RandUtils::iRandNumber(0, v_directions.size() - 2);

			d_interval_size_first =
				(v_directions.at(i_interval_first).first - v_directions.at(i_interval_first + 1).first) *
				(v_directions.at(i_interval_first).first - v_directions.at(i_interval_first + 1).first)
				+
				(v_directions.at(i_interval_first).second - v_directions.at(i_interval_first + 1).second) *
				(v_directions.at(i_interval_first).second - v_directions.at(i_interval_first + 1).second);


			d_interval_size_second =
				(v_directions.at(i_interval_second).first - v_directions.at(i_interval_second + 1).first) *
				(v_directions.at(i_interval_second).first - v_directions.at(i_interval_second + 1).first)
				+
				(v_directions.at(i_interval_second).second - v_directions.at(i_interval_second + 1).second) *
				(v_directions.at(i_interval_second).second - v_directions.at(i_interval_second + 1).second);


			int  i_chosen_interval;

			if (d_interval_size_first > d_interval_size_second)
				i_chosen_interval = i_interval_first;
			else
				i_chosen_interval = i_interval_second;

			d_first = RandUtils::dRandNumber(v_directions.at(i_chosen_interval).first, v_directions.at(i_chosen_interval + 1).first);
			d_second = 1.0 - d_first;

			pv_mesaures->at(0)->dWeight = d_first;
			pv_mesaures->at(1)->dWeight = d_second;

			d_last_weight_first = d_first;
			d_last_weight_second = d_second;

		}//if (b_multi_obj_domination_weight_vec_pareto_front_based == true)
		else
		{
			//get random weights and normalize...
			double  d_weight_summ;
			d_weight_summ = 0;
			for (int ii = 0; ii < pv_mesaures->size(); ii++)
			{
				pv_mesaures->at(ii)->dWeight = RandUtils::dRandNumber(0, 1);
				d_weight_summ += pv_mesaures->at(ii)->dWeight;
			}//for (int ii = 0; ii < pv_mesaures->size(); ii++)

			if (d_weight_summ == 0)
				pv_mesaures->at(0)->dWeight = 1;
			else
			{
				for (int ii = 0; ii < pv_mesaures->size(); ii++)
					pv_mesaures->at(ii)->dWeight = pv_mesaures->at(ii)->dWeight / d_weight_summ;
			}//else  if (d_weight_summ == 0)
		}//else if (b_multi_obj_domination_weight_vec_pareto_front_based == true)
	}//if (b_multi_obj_domination_weight_vec == true)



	pc_optimizer->iterate_with_separate_linkage(pcSeparateLinkage);


	return b_update_best_individual(iIterationNumber);
}//bool CP3BasedOptimizer::bRunIterationSeparateLinkage(uint32_t iIterationNumber, time_t tStartTime, CLinkageAnalyzer  *pcSeparateLinkage)


bool CP3BasedOptimizer::bRunIteration(uint32_t iIterationNumber)
{
	CString  s_buf;

	pc_optimizer->b_multi_obj_domination_fitness_compare = b_multi_obj_domination_fitness_compare;
	pc_optimizer->i_super_cross_with_best = i_super_cross_with_best;
	pc_optimizer->i_super_cross_with_best_only_final_climb = i_super_cross_with_best_only_final_climb;
	pc_optimizer->i_super_cross_with_best_only_final_climb_accumulate_linkage = i_super_cross_with_best_only_final_climb_accumulate_linkage;
	pc_optimizer->i_bb_empower = i_bb_empower;
	pc_optimizer->i_gb_best_breaker = i_gb_best_breaker;
	pc_optimizer->b_no_bias_linkage_improver = b_no_bias_linkage_improver;
	//pc_optimizer->b_multi_obj_domination_weight_vec = b_multi_obj_domination_weight_vec;
	//pc_optimizer->b_multi_obj_domination_weight_vec_pareto_front_based = b_multi_obj_domination_weight_vec_pareto_front_based;
	pc_optimizer->d_slide = d_slide;


	pc_optimizer->pc_linkage_analyzer = pc_linkage_analyzer;


	if (b_multi_obj_domination_weight_vec == true)
	{
		CBinaryMultiObjectiveProblem  *pc_multi_problem;
		pc_multi_problem = (CBinaryMultiObjectiveProblem  *)pc_problem->pcGetEvaluation();

		
		vector<CMultiObjectiveMeasure*>  *pv_mesaures;
		pv_mesaures = pc_multi_problem->pvGetMeasures();

		if (b_multi_obj_domination_weight_vec_pareto_front_based == true)
		{
			vector<CMultiIndividual  *>  *pv_current_global_pareto_front;
			pv_current_global_pareto_front = pc_multi_problem->pvGetGlobalParetoFront();

			vector<pair<double, double>>  v_directions;

			v_directions.push_back(pair<double, double>(0,1));

			double  d_first, d_second, d_sum;
			for (int ii = 0; ii < pv_current_global_pareto_front->size(); ii++)
			{
				d_first = pv_current_global_pareto_front->at(ii)->pvGetFitness()->at(0);
				d_second = pv_current_global_pareto_front->at(ii)->pvGetFitness()->at(1);


				if ((d_first != 0) && (d_second != 0))
				{
					d_sum = d_first + d_second;
					d_first = d_first / d_sum;
					d_second = d_second / d_sum;

					v_directions.push_back(pair<double, double>(d_first, d_second));
				}//if ((d_first != 0) && (d_second != 0))
				

			}//for (int ii = 0; ii < pv_current_global_pareto_front->size(); ii++)

			v_directions.push_back(pair<double, double>(1, 0));

			
			d_first = 0;
			d_second = 0;

			int  i_interval_first, i_interval_second;
			double  d_interval_size_first, d_interval_size_second;

			i_interval_first = RandUtils::iRandNumber(0, v_directions.size() - 2);
			i_interval_second = RandUtils::iRandNumber(0, v_directions.size() - 2);

			d_interval_size_first = 
				(v_directions.at(i_interval_first).first - v_directions.at(i_interval_first + 1).first) *
				(v_directions.at(i_interval_first).first - v_directions.at(i_interval_first + 1).first)
				+
				(v_directions.at(i_interval_first).second - v_directions.at(i_interval_first + 1).second) *
				(v_directions.at(i_interval_first).second - v_directions.at(i_interval_first + 1).second);


			d_interval_size_second =
				(v_directions.at(i_interval_second).first - v_directions.at(i_interval_second + 1).first) *
				(v_directions.at(i_interval_second).first - v_directions.at(i_interval_second + 1).first)
				+
				(v_directions.at(i_interval_second).second - v_directions.at(i_interval_second + 1).second) *
				(v_directions.at(i_interval_second).second - v_directions.at(i_interval_second + 1).second);


			int  i_chosen_interval;

			if (d_interval_size_first > d_interval_size_second)
				i_chosen_interval = i_interval_first;
			else
				i_chosen_interval = i_interval_second;

			d_first = RandUtils::dRandNumber(v_directions.at(i_chosen_interval).first, v_directions.at(i_chosen_interval + 1).first);
			d_second = 1.0 - d_first;


			/*s_buf.Format
				(
				"%d:[%.4lf %.4lf]  vs %d:[%.4lf %.4lf]   CHOSEN:%d", 
					i_interval_first, v_directions.at(i_interval_first).first, v_directions.at(i_interval_first+1).first, 
					i_interval_second, v_directions.at(i_interval_second ).first, v_directions.at(i_interval_second + 1).first,
					i_chosen_interval
				);
			::Tools::vShow(s_buf);*/




			/*if (RandUtils::iRandNumber(0, 1) == 0)
			{

				int  i_wegiht_pair;
				i_wegiht_pair = RandUtils::iRandNumber(0, v_directions.size() - 2);

				//d_first = RandUtils::dRandNumber(v_directions.at(i_wegiht_pair).first, v_directions.at(i_wegiht_pair + 1).first);
				//d_second = 1.0 - d_first;

				d_first = (v_directions.at(i_wegiht_pair).first + v_directions.at(i_wegiht_pair + 1).first) / 2;
				d_second = 1.0 - d_first;
			}//if (RandUtils::iRandNumber(0, 1) == 0)
			else
			{
				int  i_wegiht_pair;
				i_wegiht_pair = RandUtils::iRandNumber(0, v_directions.size() - 1);

				d_first = v_directions.at(i_wegiht_pair).first;
				d_second = 1.0 - d_first;
			}//else  if (RandUtils::iRandNumber(0, 1) == 0)*/

			/*;
			::Tools::vReportInFile("zzz_directions_test.txt", "", true);
			for (int ii = 0; ii < v_directions.size(); ii++)
			{
				s_buf.Format("%.4lf \t %.4lf", v_directions.at(ii).first, v_directions.at(ii).second);
				::Tools::vReportInFile("zzz_directions_test.txt", s_buf);
			}//for (int ii = 0; ii < v_directions.size(); ii++)

			::Tools::vReportInFile("zzz_directions_test.txt", "");
			s_buf.Format("weight_pair: %d", i_wegiht_pair);
			::Tools::vReportInFile("zzz_directions_test.txt", s_buf);
			s_buf.Format("weights: %.4lf  \t  %.4lf", d_first, d_second);
			::Tools::vReportInFile("zzz_directions_test.txt", s_buf);
			::Tools::vShow(0);//*/


			/*double  d_cur_hyper_volume;
			d_cur_hyper_volume = pc_multi_problem->dPFQualityHyperVolume();

			if (d_last_hyper_volume >= 0)
			{
				//if we have imporved THEN we use last weights
				if (d_last_hyper_volume > d_cur_hyper_volume)
				{
					d_first = d_last_weight_first;
					d_second = d_last_weight_second;

					//s_buf.Format("HyperVOl: %.8lf -> %.8lf   Repeating: %.4lf %.4lf", d_last_hyper_volume, d_cur_hyper_volume, d_last_weight_first, d_last_weight_second);
					//::Tools::vShow(s_buf);
					//::Tools::vReportInFile("zzzz_repeating.txt", s_buf);
				}//if (d_last_hyper_volume > d_cur_hyper_volume)
			}//if (d_last_hyper_volume >= 0)

			d_last_hyper_volume = d_cur_hyper_volume;//*/



			pv_mesaures->at(0)->dWeight = d_first;
			pv_mesaures->at(1)->dWeight = d_second;

			d_last_weight_first = d_first;
			d_last_weight_second = d_second;

		}//if (b_multi_obj_domination_weight_vec_pareto_front_based == true)
		else
		{
			//get random weights and normalize...
			double  d_weight_summ;
			d_weight_summ = 0;
			for (int ii = 0; ii < pv_mesaures->size(); ii++)
			{
				pv_mesaures->at(ii)->dWeight = RandUtils::dRandNumber(0, 1);
				d_weight_summ += pv_mesaures->at(ii)->dWeight;
			}//for (int ii = 0; ii < pv_mesaures->size(); ii++)

			if (d_weight_summ == 0)
				pv_mesaures->at(0)->dWeight = 1;
			else
			{
				for (int ii = 0; ii < pv_mesaures->size(); ii++)
					pv_mesaures->at(ii)->dWeight = pv_mesaures->at(ii)->dWeight / d_weight_summ;
			}//else  if (d_weight_summ == 0)
		}//else if (b_multi_obj_domination_weight_vec_pareto_front_based == true)
	}//if (b_multi_obj_domination_weight_vec == true)

	
	
	pc_optimizer->iterate();

	
	return b_update_best_individual(iIterationNumber);
}//bool CP3BasedOptimizer::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)

bool CP3BasedOptimizer::b_update_best_individual(uint32_t iIterationNumber)
{
	tuple<float, float, int, time_t, vector<bool>> t_summary = pc_recorder->results.best();

	double d_best_individual_candidate_fitness = (double)get<0>(t_summary);

	bool b_updated = COptimizer<CBinaryCoding, CBinaryCoding>::b_update_best_individual(iIterationNumber, d_best_individual_candidate_fitness, [&](CBinaryCoding *pcBestGenotype)
	{
		vector<bool> v_best_bits = get<4>(t_summary);

		for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
		{
			*(pcBestGenotype->piGetBits() + i) = (int32_t)v_best_bits.at(i);
		}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
	});

	return b_updated;
}//bool CP3BasedOptimizer::b_update_best_individual(uint32_t iIterationNumber, time_t tStartTime)