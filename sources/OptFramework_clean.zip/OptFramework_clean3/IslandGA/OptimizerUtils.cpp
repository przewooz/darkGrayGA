#include "OptimizerUtils.h"

#include "BinaryCoding.h"
#include "BinaryTestLLOptimizer.h"
#include "DifferentialEvolution.h"
#include "DSMGA2.h"
#include "DSMGA2PopulationSizing.h"
#include "DummyOptimizer.h"
#include "3LO.h"
#include "3LOscrapped.h"
#include "cGomea.h"
#include "darkGrayGa.h"
#include "RandomSearchGreedy.h"
#include "EmPfDec.h"
#include "LinkageImproverOptimizer.h"
#include "EnumCommandParam.h"
#include "LTDE.h"
#include "LTGA.h"
#include "LTGAOriginal.h"
#include "LTGAOriginalPopulationSizing.h"
#include "GeneticAlgorithm.h"
#include "IncrementalP3.h"
#include "IslandCoevolutionDSMGA2.h"
#include "IslandModelGeneticAlgorithm.h"
#include "IslandModelP3.h"
#include "MultiDifferentWithGlobalP3.h"
#include "MultiOptimizer.h"
#include "MultiPopulationGeneticAlgorithm.h"
#include "P3.h"
#include "ParticleSwarmOptimization.h"
#include "PermutationCoding.h"
#include "PermutationGOMEA.h"
#include "PermutationP4.h"
#include "PopulationSizingOptimizer.h"
#include "RealCoding.h"
#include "RealTestLLOptimizer.h"
#include "RealTestOptimizer.h"
#include "BinaryBatOptimizer.h"
#include  "ProblemStructureAnalysis_DLED.h"
#include "BinaryAlgaeOptimizer.h"
#include "BinaryGreyWolf.h"
#include "BinaryPSOOptimizer.h"
#include "BinaryCuckooOptimizer.h"
//#include "RVGOMEA.h"
#include "StringUtils.h"
#include "darkGrayGA.h"
#include "conditionalGA.h"

#include "nsga2.h"
#include "nsga2Orig.h"
#include "MoGomea.h" 
#include "moead.h"

#include <atlstr.h>
#include <unordered_map>
#include <utility>

using namespace ThreeLO;
using namespace ThreeLOScr;
using namespace Nsga2;
using namespace Nsga2Orig;
using namespace MoGomea;
using namespace EmPfDec;
using namespace LinkImproverOpt;
using namespace MoeaD;
using namespace nDarkGrayGA;

using namespace nC_Gomea;
using namespace nDarkGrayGA;
using namespace nConditionalGA;
using namespace nRandomSearchGreedy;


using namespace ProblemStructureAnalysis;


template <class TGenotype, class TFenotype>
COptimizer<TGenotype, TFenotype> * OptimizerUtils::pcGetOptimizer(CProblem<TGenotype, TFenotype> *pcProblem, CLog *pcLog, uint32_t iRandomSeed, istream *psSettings, CError *pcError, bool bIsObligatory)
{
	COptimizer<TGenotype, TFenotype> *pc_optimizer = nullptr;

	size_t i_genotype_type_hash_code = typeid(TGenotype).hash_code();
	size_t i_fenotype_type_hash_code = typeid(TFenotype).hash_code();

	unordered_map<CString, EOptimizerType> m_optimizer_types;
	m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_MULTI, OPTIMIZER_MULTI));
	m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_GA, OPTIMIZER_GA));
	m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_MGA, OPTIMIZER_MGA));
	m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_ISLAND_GA, OPTIMIZER_ISLAND_GA));
	m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_DE, OPTIMIZER_DE));
	m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_POPULATION_SIZING, OPTIMIZER_POPULATION_SIZING));

	if (i_genotype_type_hash_code == typeid(CBinaryCoding).hash_code() && i_fenotype_type_hash_code == typeid(CBinaryCoding).hash_code())
	{
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_P3, OPTIMIZER_P3));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_ISLAND_P3, OPTIMIZER_ISLAND_P3));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_INCREMENTAL_P3, OPTIMIZER_INCREMENTAL_P3));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_MULTI_DIFFERENT_WITH_GLOBAL_P3, OPTIMIZER_MULTI_DIFFERENT_WITH_GLOBAL_P3));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_LTGA, OPTIMIZER_LTGA));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_LTGA_ORIGINAL, OPTIMIZER_LTGA_ORIGINAL));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_LTGA_ORIGINAL_POPULATION_SIZING, OPTIMIZER_LTGA_ORIGINAL_POPULATION_SIZING));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_DSMGA2, OPTIMIZER_DSMGA2));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_DSMGA2_POPULATION_SIZING, OPTIMIZER_DSMGA2_POPULATION_SIZING));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_ISLAND_COEVOLUTION_DSMGA2, OPTIMIZER_ISLAND_COEVOLUTION_DSMGA2));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_DUMMY, OPTIMIZER_DUMMY));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_3LO, OPTIMIZER_3LO));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_3LO_SINGLE, OPTIMIZER_3LO_SINGLE));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_3LO_SCRAPPED, OPTIMIZER_3LO_SCRAPPED));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_3LO_SCRAPPED_MULTI_POP, OPTIMIZER_3LO_SCRAPPED_MULTI_POP));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_BINARY_TEST_LL, OPTIMIZER_BINARY_TEST_LL));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_BINARY_MULTI_NSGA2, OPTIMIZER_BINARY_MULTI_NSGA2));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_BINARY_MULTI_NSGA2_ORIG, OPTIMIZER_BINARY_MULTI_NSGA2_ORIG));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_BINARY_MULTI_MOEAD, OPTIMIZER_BINARY_MULTI_MOEAD));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_BINARY_MULTI_MOGOMEA, OPTIMIZER_BINARY_MULTI_MOGOMEA));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_BINARY_MULTI_MOMPP3, OPTIMIZER_BINARY_MULTI_MOMP3));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_BINARY_EMPIRICAL_PF_DECOMPOSITION, OPTIMIZER_BINARY_EMPIRICAL_PF_DECOMPOSITION));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_BINARY_LINKAGE_IMPROVER, OPTIMIZER_BINARY_LINKAGE_IMPROVER));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_BINARY_BAT, OPTIMIZER_BINARY_BAT));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_BINARY_C_GOMEA, OPTIMIZER_C_GOMEA));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_BINARY_DARK_GRAY_GA, OPTIMIZER_DARK_GRAY_GA));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_BINARY_CONDITIONAL_GA, OPTIMIZER_BINARY_CONDITIONAL_GA));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_BINARY_RANDOM_SEARCH_GREEDY, OPTIMIZER_RANDOM_SEARCH_GREEDY));
		
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_BINARY_PROBLEM_STRUCTURE_ANALYSIS, PROBLEM_STRUCTURE_ANALYSIS_DLED));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_BINARY_PSO, OPTIMIZER_BINARY_PSO));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_BINARY_ALGAE, OPTIMIZER_BINARY_ALGAE));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_BINARY_GREY_WOLF, OPTIMIZER_BINARY_GREY_WOLF));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_BINARY_CUCKOO, OPTIMIZER_BINARY_CUCKOO));
	}//if (i_genotype_type_hash_code == typeid(CBinaryCoding).hash_code() && i_fenotype_type_hash_code == typeid(CBinaryCoding).hash_code())

	if (i_genotype_type_hash_code == typeid(CRealCoding).hash_code() && i_fenotype_type_hash_code == typeid(CRealCoding).hash_code())
	{
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_PSO, OPTIMIZER_PSO));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_REAL_TEST, OPTIMIZER_REAL_TEST));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_REAL_TEST_LL, OPTIMIZER_REAL_TEST_LL));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_RV_GOMEA, OPTIMIZER_RV_GOMEA));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_LTDE, OPTIMIZER_LTDE));
	}//if (i_genotype_type_hash_code == typeid(CRealCoding).hash_code() && i_fenotype_type_hash_code == typeid(CRealCoding).hash_code())

	if (i_genotype_type_hash_code == typeid(CRealCoding).hash_code() && i_fenotype_type_hash_code == typeid(CPermutationCoding).hash_code())
	{
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_PERMUTATION_GOMEA, OPTIMIZER_PERMUTATION_GOMEA));
		m_optimizer_types.insert(pair<const CString, EOptimizerType>(OPTIMIZER_ARGUMENT_TYPE_PERMUTATION_P4, OPTIMIZER_PERMUTATION_P4));
	}//if (i_genotype_type_hash_code == typeid(CRealCoding).hash_code() && i_fenotype_type_hash_code == typeid(CPermutationCoding).hash_code())

	CEnumCommandParam<EOptimizerType> p_type(OPTIMIZER_ARGUMENT_TYPE, &m_optimizer_types, bIsObligatory);
	EOptimizerType e_type = p_type.eGetValue(psSettings, pcError);

	if (!*pcError && p_type.bHasValue())
	{
		switch (e_type)
		{
			case OPTIMIZER_MULTI:
			{
				pc_optimizer = new CMultiOptimizer<TGenotype, TFenotype>(pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_MULTI
			case OPTIMIZER_GA:
			{
				pc_optimizer = new CGeneticAlgorithm<TGenotype, TFenotype>(pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_GA
			case OPTIMIZER_MGA:
			{
				pc_optimizer = new CMultiPopulationGeneticAlgorithm<TGenotype, TFenotype>(pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_MGA
			case OPTIMIZER_ISLAND_GA:
			{
				pc_optimizer = new CIslandModelGeneticAlgorithm<TGenotype, TFenotype>(pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_ISLAND_GA
			case OPTIMIZER_DE:
			{
				pc_optimizer = new CDifferentialEvolution<TGenotype, TFenotype>(pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_DE
			case OPTIMIZER_PSO:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CParticleSwarmOptimization((CProblem<CRealCoding, CRealCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_PSO
			case OPTIMIZER_P3:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CP3((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_P3
			case OPTIMIZER_ISLAND_P3:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CIslandModelP3((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_ISLAND_P3
			case OPTIMIZER_INCREMENTAL_P3:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CIncrementalP3((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_INCREMENTAL_P3
			case OPTIMIZER_MULTI_DIFFERENT_WITH_GLOBAL_P3:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CMultiDifferentWithGlobalP3((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_MULTI_DIFFERENT_WITH_GLOBAL_P3
			case OPTIMIZER_LTGA:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CLTGA((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_LTGA
			case OPTIMIZER_LTGA_ORIGINAL:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CLTGAOriginal((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_LTGA_ORIGINAL
			case OPTIMIZER_LTGA_ORIGINAL_POPULATION_SIZING:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CLTGAOriginalPopulationSizing((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_LTGA_ORIGINAL_POPULATION_SIZING
			case OPTIMIZER_DSMGA2:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CDSMGA2((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_DSMGA2
			case OPTIMIZER_DSMGA2_POPULATION_SIZING:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CDSMGA2PopulationSizing((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_DSMGA2_POPULATION_SIZING
			case OPTIMIZER_ISLAND_COEVOLUTION_DSMGA2:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CIslandCoevolutionDSMGA2((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_ISLAND_COEVOLUTION_DSMGA2
			case OPTIMIZER_DUMMY:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CDummyOptimizer((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_DUMMY
			case OPTIMIZER_3LO:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new C3LO((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_3LO
			case OPTIMIZER_3LO_SINGLE:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new C3LOSingle((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_3LO
			case OPTIMIZER_3LO_SCRAPPED:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new C3LOscrapped((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_3LO_SCRAPPED
			case OPTIMIZER_3LO_SCRAPPED_MULTI_POP:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new C3LOscrappedMultiPop((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_3LO_SCRAPPED_MULTI_POP
			case OPTIMIZER_C_GOMEA:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new C_CGomea((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_C_GOMEA
			case OPTIMIZER_DARK_GRAY_GA:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CDarkGrayGA((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_DARK_GRAY_GA
			case OPTIMIZER_BINARY_CONDITIONAL_GA:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CConditionalGA((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_BINARY_CONDITIONAL_GA
			case OPTIMIZER_RANDOM_SEARCH_GREEDY:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CRandomSearchGreedy((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_RANDOM_SEARCH_GREEDY
			case PROBLEM_STRUCTURE_ANALYSIS_DLED:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CProblemStructAnal_DLED((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case PROBLEM_STRUCTURE_ANALYSIS_DLED
			case OPTIMIZER_REAL_TEST:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CRealTestOptimizer((CProblem<CRealCoding, CRealCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_REAL_TEST
			case OPTIMIZER_REAL_TEST_LL:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CRealTestLLOptimizer((CProblem<CRealCoding, CRealCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_REAL_TEST_LL
			case OPTIMIZER_POPULATION_SIZING:
			{
				pc_optimizer = new CPopulationSizingOptimizer<TGenotype, TFenotype>(pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_POPULATION_SIZING
			case OPTIMIZER_BINARY_TEST_LL:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CBinaryTestLLOptimizer((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_BINARY_TEST_LL
/*			case OPTIMIZER_RV_GOMEA:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CRVGOMEA((CProblem<CRealCoding, CRealCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_RV_GOMEA*/
			case OPTIMIZER_BINARY_MULTI_NSGA2:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CNSGA2((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_BINARY_MULTI_NSGA2
			case OPTIMIZER_BINARY_MULTI_NSGA2_ORIG:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CNSGA2orig((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_BINARY_MULTI_NSGA2_ORIG
			case OPTIMIZER_BINARY_MULTI_MOEAD:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CMoead((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_BINARY_MULTI_MOEAD
			case OPTIMIZER_BINARY_MULTI_MOGOMEA:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CMoGomea((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_BINARY_MULTI_MOGOMEA
			case OPTIMIZER_BINARY_MULTI_MOMP3:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CMO_MPP3((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_BINARY_MULTI_MOGOMEA
			case OPTIMIZER_BINARY_EMPIRICAL_PF_DECOMPOSITION:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CMO_EmPfDec((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_BINARY_EMPIRICAL_PF_DECOMPOSITION
			case OPTIMIZER_BINARY_LINKAGE_IMPROVER:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CLinkageImproverOptimizer((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_BINARY_LINKAGE_IMPROVER
			case OPTIMIZER_LTDE:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CLTDE((CProblem<CRealCoding, CRealCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_LTDE
			case OPTIMIZER_PERMUTATION_GOMEA:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CPermutationGOMEA((CProblem<CRealCoding, CPermutationCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_PERMUTATION_GOMEA
			case OPTIMIZER_PERMUTATION_P4:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CPermutationP4((CProblem<CRealCoding, CPermutationCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_PERMUTATION_P4
			case OPTIMIZER_BINARY_BAT:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CBinaryBatOptimizer((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_BINARY_BAT
			case OPTIMIZER_BINARY_PSO:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CBinaryPSOOptimizer((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_BINARY_PSO
			case OPTIMIZER_BINARY_ALGAE:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CBinaryAlgaeOptimizer((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_BINARY_ALGAE
			case OPTIMIZER_BINARY_GREY_WOLF:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CBinaryGreyWolfOptimizer((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_BINARY_GREY_WOLF			
			case OPTIMIZER_BINARY_CUCKOO:
			{
				pc_optimizer = (COptimizer<TGenotype, TFenotype>*)new CBinaryCuckooOptimizer((CProblem<CBinaryCoding, CBinaryCoding>*)pcProblem, pcLog, iRandomSeed);
				break;
			}//case OPTIMIZER_BINARY_CUCKOO
			default:
			{
				pcError->vSetError(CError::iERROR_CODE_OPERATOR_NOT_FOUND, "optimizer");
				break;
			}//default
		}//switch (e_type)
	}//if (!*pcError && p_type.bHasValue())

	if (!*pcError)
	{
		*pcError = pc_optimizer->eConfigure(psSettings);
	}//if (!*pcError)

	return pc_optimizer;
}//COptimizer<TGenotype, TFenotype> * OptimizerUtils::pcGetOptimizer(CProblem<TGenotype, TFenotype> *pcProblem, CLog *pcLog, uint32_t iRandomSeed, istream *psSettings, COptimizerParams<TGenotype, TFenotype> **ppcParams, CError *pcError, bool bIsObligatory)

template<class TGenotype, class TFenotype>
CPopulationSizingSingleOptimizer<TGenotype, TFenotype>* OptimizerUtils::pcGetPopulationSizingSingleOptimizer(CProblem<TGenotype, TFenotype> *pcProblem, CLog *pcLog, uint32_t iRandomSeed, istream *psSettings, CError *pcError, bool bIsObligatory)
{
	COptimizer<TGenotype, TFenotype> *pc_optimizer = pcGetOptimizer(pcProblem, pcLog, iRandomSeed, psSettings, pcError, bIsObligatory);

	if (!*pcError && pc_optimizer)
	{
		if (!dynamic_cast<CPopulationSizingSingleOptimizer<TGenotype, TFenotype>*>(pc_optimizer))
		{
			pcError->vSetError(CError::iERROR_CODE_OPERATOR_NOT_FOUND, "optimizer instead of population sizing single optimizer");
		}//if (!dynamic_cast<CPopulationSizingSingleOptimizer<TGenotype, TFenotype>*>(pc_optimizer))
	}//if (!*pcError && pc_optimizer)

	return (CPopulationSizingSingleOptimizer<TGenotype, TFenotype>*)pc_optimizer;
}//CPopulationSizingSingleOptimizer<TGenotype, TFenotype>* OptimizerUtils::pcGetPopulationSizingSingleOptimizer(CProblem<TGenotype, TFenotype> *pcProblem, CLog *pcLog, uint32_t iRandomSeed, istream *psSettings, CError *pcError, bool bIsObligatory)

template<class TGenotype, class TFenotype>
CPopulationOptimizer<TGenotype, TFenotype>* OptimizerUtils::pcGetPopulationOptimizer(CProblem<TGenotype, TFenotype> *pcProblem, CLog *pcLog, uint32_t iRandomSeed, istream *psSettings, CError *pcError, bool bIsObligatory)
{
	COptimizer<TGenotype, TFenotype> *pc_optimizer = pcGetOptimizer(pcProblem, pcLog, iRandomSeed, psSettings, pcError, bIsObligatory);

	if (!*pcError && pc_optimizer)
	{
		if (!dynamic_cast<CPopulationOptimizer<TGenotype, TFenotype>*>(pc_optimizer))
		{
			pcError->vSetError(CError::iERROR_CODE_OPERATOR_NOT_FOUND, "optimizer instead of population optimizer");
		}//if (!dynamic_cast<CPopulationOptimizer<TGenotype, TFenotype>*>(pc_optimizer))
	}//if (!*pcError && pc_optimizer)

	return (CPopulationOptimizer<TGenotype, TFenotype>*)pc_optimizer;
}//COptimizer<TGenotype, TFenotype>* OptimizerUtils::pcGetPopulationOptimizer(CProblem<TGenotype, TFenotype> *pcProblem, CLog *pcLog, uint32_t iRandomSeed, istream *psSettings, CError *pcError, bool bIsObligatory)

template COptimizer<CBinaryCoding, CBinaryCoding> * OptimizerUtils::pcGetOptimizer(CProblem<CBinaryCoding, CBinaryCoding>*, CLog*, uint32_t, istream*, CError*, bool);
template COptimizer<CRealCoding, CPermutationCoding> * OptimizerUtils::pcGetOptimizer(CProblem<CRealCoding, CPermutationCoding>*, CLog*, uint32_t, istream*, CError*, bool);
template COptimizer<CRealCoding, CRealCoding> * OptimizerUtils::pcGetOptimizer(CProblem<CRealCoding, CRealCoding>*, CLog*, uint32_t, istream*, CError*, bool);

template CPopulationSizingSingleOptimizer<CBinaryCoding, CBinaryCoding> * OptimizerUtils::pcGetPopulationSizingSingleOptimizer(CProblem<CBinaryCoding, CBinaryCoding>*, CLog*, uint32_t, istream*, CError*, bool);
template CPopulationSizingSingleOptimizer<CRealCoding, CPermutationCoding> * OptimizerUtils::pcGetPopulationSizingSingleOptimizer(CProblem<CRealCoding, CPermutationCoding>*, CLog*, uint32_t, istream*, CError*, bool);
template CPopulationSizingSingleOptimizer<CRealCoding, CRealCoding> * OptimizerUtils::pcGetPopulationSizingSingleOptimizer(CProblem<CRealCoding, CRealCoding>*, CLog*, uint32_t, istream*, CError*, bool);

template CPopulationOptimizer<CBinaryCoding, CBinaryCoding> * OptimizerUtils::pcGetPopulationOptimizer(CProblem<CBinaryCoding, CBinaryCoding>*, CLog*, uint32_t, istream*, CError*, bool);
template CPopulationOptimizer<CRealCoding, CPermutationCoding> * OptimizerUtils::pcGetPopulationOptimizer(CProblem<CRealCoding, CPermutationCoding>*, CLog*, uint32_t, istream*, CError*, bool);
template CPopulationOptimizer<CRealCoding, CRealCoding> * OptimizerUtils::pcGetPopulationOptimizer(CProblem<CRealCoding, CRealCoding>*, CLog*, uint32_t, istream*, CError*, bool);
