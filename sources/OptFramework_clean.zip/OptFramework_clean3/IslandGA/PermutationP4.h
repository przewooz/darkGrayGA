#ifndef PERMUTATION_P4_H
#define PERMUTATION_P4_H

#define PERMUTATION_P4_ARGUMENT_COUNT_EMPIRICAL_DSM "count_empirical_dsm (0-none; 1-hybrid; 2-pureEmpirical)"
#define PERMUTATION_P4_ARGUMENT_COUNT_EMPIRICAL_DSM_NONE 0
#define PERMUTATION_P4_ARGUMENT_COUNT_EMPIRICAL_DSM_HYBRID 1
#define PERMUTATION_P4_ARGUMENT_COUNT_EMPIRICAL_DSM_PURE_EMPIRICAL 2
#define PERMUTATION_P4_ARGUMENT_COUNT_EMPIRICAL_DSM_RANDOM 3

#include "Error.h"
#include "Log.h"
#include "Optimizer.h"
#include "PermutationCoding.h"
#include "Problem.h"
#include "RealCoding.h"


#include "../order-p3/include/order-p3/optimizer/Pyramid.h"

#include <ctime>
#include <cstdint>
#include <istream>

using namespace std;

class CPermutationP4 : public COptimizer<CRealCoding, CPermutationCoding>
{
public:
	CPermutationP4(CProblem<CRealCoding, CPermutationCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed);
	CPermutationP4(CPermutationP4 *pcOther);

	virtual COptimizer<CRealCoding, CPermutationCoding> *pcCopy() { return new CPermutationP4(this); };

	virtual CError eConfigure(istream *psSettings);

	virtual void vInitialize();
	virtual bool bRunIteration(uint32_t iIterationNumber);

	virtual void vRun();

private:
	using COptimizer<CRealCoding, CPermutationCoding>::b_update_best_individual;
	bool b_update_best_individual(uint32_t iIterationNumber);

	uint8_t i_count_empirical_dsm;

	//Problem  *pc_permut_p4_problem;
	NPermutationP4::Pyramid *pc_permutation_p4;
};//class CPermutationGOMEA : public COptimizer<CRealCoding, CPermutationCoding>

#endif//PERMUTATION_GOMEA_H