#pragma once
#include "PopulationSizingOptimizer.h"
#include "StringCommandParam.h"
#include <vector>
#include <math.h>
#include <random>

#define BINARY_PSO_OPTIMIZER_ARGUMENT_V_MAX "v_max"
#define BINARY_PSO_OPTIMIZER_ARGUMENT_MAX_PHI "max_phi"
#define BINARY_PSO_OPTIMIZER_ARGUMENT_OMEGA "omega"
#define BINARY_PSO_OPTIMIZER_ARGUMENT_POPULATION_SIZE "population_size"
#define BINARY_PSO_OPTIMIZER_ARGUMENT_STALE_DETECTION "stale_detection"

class CBinaryPSOIndividual;


class CBinaryPSOOptimizer :
	public CPopulationSizingSingleOptimizer<CBinaryCoding, CBinaryCoding>
{
public:
	static uint32_t iERROR_PARENT_CBinaryPSOOptimizer;
	static const float F_DEFAULT_V_MAX;
	static const float F_DEFAULT_MAX_PHI;
	static const float F_DEFAULT_OMEGA;
	static const uint32_t I_DEFAULT_POPULATION_SIZE;

	CBinaryPSOOptimizer(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog* pcLog, uint32_t iRandomSeed);

	CBinaryPSOOptimizer(CBinaryPSOOptimizer* pcOther);

	virtual ~CBinaryPSOOptimizer();

	COptimizer<CBinaryCoding, CBinaryCoding>* pcCopy() override;
	CError eConfigure(istream* psSettings) override;

	bool bRunIteration(uint32_t iIterationNumber) override;
	void vInitialize() override;
	void vEvaluate();

	bool bIsSteadyState() override;
	double dComputeAverageFitnessValue() override;
	uint32_t iGetPopulationSize() override { return i_population_size; }
	void vSetPopulationSize(uint32_t iPopulationSize) override { i_population_size = iPopulationSize; };


protected:
	void v_delete_population();
	void v_initialize_population();
	double d_evaluate(CBinaryPSOIndividual* pc_individual);
	void v_update_best();

	uniform_real_distribution<double> c_individual_distribution;
	uniform_real_distribution<double> c_uniform_distribution;
	uniform_real_distribution<double> c_phi_distribution;
	default_random_engine c_random_engine;

	vector<CBinaryPSOIndividual*> v_population;
	uint16_t i_genotype_length;
	double d_v_max;
	double d_max_phi;
	double d_omega;
	bool b_use_stale_detection;
	uint32_t i_population_size;
	CBinaryPSOIndividual* pc_best;
	double d_best_fitness;
};

class CBinaryPSOIndividual
{
public:
	friend class CBinaryPSOOptimizer;

	CBinaryPSOIndividual(uint16_t iGenotypeLength, double dMaxPhi, double dOmega);
	CBinaryPSOIndividual(CBinaryPSOIndividual *pcOther);

	static CBinaryPSOIndividual* pcGetRandomIndividual(
		uint16_t iGenotypeLength,
		double dMaxPhi,
		double dOmega,
		uniform_real_distribution<double>& cIndividualDistribution,
		uniform_real_distribution<double>& cUniformDistribution,
		default_random_engine& cRandomEngine);

	void vUpdateVelocity(
		CBinaryPSOIndividual& cGlobalBest, 
		uniform_real_distribution<double>& c_phi_distribution,
		default_random_engine& cRandomEngine);

	void vGenotypeProbing(
		uniform_real_distribution<double>& c_uniform_distribution, 
		default_random_engine& c_random_engine);
	void vUpdateBest(CProblem<CBinaryCoding, CBinaryCoding>* pc_problem);

protected:
	double d_max_phi;
	double d_omega;
	double d_fitness;
	double d_best_fitness;
	vector<double> v_velocity;
	vector<int32_t> v_genotype;
	vector<int32_t> v_individual_best;
};