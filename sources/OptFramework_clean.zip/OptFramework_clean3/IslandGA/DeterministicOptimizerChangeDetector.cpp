#include "DeterministicOptimizerChangeDetector.h"

#include "Cluster.h"
#include "FloatCommandParam.h"
#include "OptimizerUtils.h"
#include "RandUtils.h"
#include "UIntCommandParam.h"

#include <algorithm>
#include <atlstr.h>
#include <cfloat>
#include <cmath>
#include <ctime>
#include <unordered_set>

using namespace ChangeDetector;


CDeterministicOptimizerChangeDetector::CDeterministicOptimizerChangeDetector(CProblem<CRealCoding, CRealCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed)
	: CSensorChangeDetector<CRealCoding, CRealCoding>(pcProblem, pcLog, iRandomSeed), c_kmeans(pcLog), c_local_optimizer(pcProblem, pcLog, iRandomSeed)
{
	pc_population_optimizer = nullptr;
	pv_population_optimizer_sensors = nullptr;
}//CDeterministicOptimizerChangeDetector::CDeterministicOptimizerChangeDetector(CProblem<CRealCoding, CRealCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed)

CDeterministicOptimizerChangeDetector::~CDeterministicOptimizerChangeDetector()
{
	v_clear_params();
}//CDeterministicOptimizerChangeDetector::~CDeterministicOptimizerChangeDetector()

CError CDeterministicOptimizerChangeDetector::eConfigure(istream *psSettings)
{
	v_clear_params();

	CError c_error = CSensorChangeDetector<CRealCoding, CRealCoding>::eConfigure(psSettings);

	if (!c_error)
	{
		CUIntCommandParam p_store_frequency(DETERMINISTIC_OPTIMIZER_CHANGE_DETECTOR_ARGUMENT_STORE_FREQUENCY, 1, UINT32_MAX);
		i_store_frequency = p_store_frequency.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		CFloatCommandParam p_fraction_of_sensors_to_clustering(DETERMINISTIC_OPTIMIZER_CHANGE_DETECTOR_ARGUMENT_FRACTION_OF_SENSORS_TO_CLUSTERING, 0, 1);
		f_fraction_of_sensors_to_clustering = p_fraction_of_sensors_to_clustering.fGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		c_error = c_kmeans.eConfigure(psSettings);
	}//if (!c_error)

	if (!c_error)
	{
		c_error = c_local_optimizer.eConfigure(psSettings);
	}//if (!c_error)

	if (!c_error)
	{
		pc_population_optimizer = OptimizerUtils::pcGetPopulationOptimizer(pc_problem, pc_log, i_random_seed, psSettings, &c_error);
	}//if (!c_error)

	return c_error;
}//CError CDeterministicOptimizerChangeDetector::eConfigure(istream *psSettings)

void CDeterministicOptimizerChangeDetector::vInitialize()
{
	CSensorChangeDetector<CRealCoding, CRealCoding>::vInitialize();

	v_clustering();
	v_set_population_optimizer_sensors();

	i_sensor_detection_counter = 0;
	i_population_optimizer_detection_counter = 0;
}//void CDeterministicOptimizerChangeDetector::vInitialize()

void CDeterministicOptimizerChangeDetector::vRun()
{
	CSensorChangeDetector<CRealCoding, CRealCoding>::vRun();

	CString s_statistics;
	s_statistics.Format("sensor_detection_counter: %d; population_optimizer_detection_counter: %d",
		i_sensor_detection_counter, i_population_optimizer_detection_counter);

	pc_log->vPrintLine(s_statistics, true);
}//void CDeterministicOptimizerChangeDetector::vRun()

bool CDeterministicOptimizerChangeDetector::b_detect_change()
{
	bool b_change_detected = CSensorChangeDetector<CRealCoding, CRealCoding>::b_detect_change();

	if (b_change_detected)
	{
		i_sensor_detection_counter++;
	}//if (b_change_detected)

	vector<CIndividual<CRealCoding, CRealCoding>*> *pv_single_population_optimizer_sensors;

	double d_previous_fitness;

	CIndividual<CRealCoding, CRealCoding> *pc_population_optimizer_sensor;

	for (uint32_t i = 0; i < c_kmeans.iGetNumberOfClusters() && !b_change_detected; i++)
	{
		pv_single_population_optimizer_sensors = pv_population_optimizer_sensors + i;

		for (uint32_t j = 0; j < (uint32_t)pv_single_population_optimizer_sensors->size() && !b_change_detected; j++)
		{
			pc_population_optimizer_sensor = pv_single_population_optimizer_sensors->at(j);

			d_previous_fitness = pc_population_optimizer_sensor->dGetFitnessValue();

			pc_population_optimizer_sensor->vIsEvaluated(false);
			pc_population_optimizer_sensor->vEvaluate();

			b_change_detected = d_previous_fitness != pc_population_optimizer_sensor->dGetFitnessValue();

			if (b_change_detected)
			{
				i_population_optimizer_detection_counter++;
			}//if (b_change_detected)
		}//for (uint32_t j = 0; j < (uint32_t)pv_single_population_optimizer_sensors->size() && !b_change_detected; j++)
	}//for (uint32_t i = 0; i < c_kmeans.iGetNumberOfClusters() && !b_change_detected; i++)

	if (b_change_detected)
	{
		v_set_population_optimizer_sensors();
	}//if (b_change_detected)

	return b_change_detected;
}//bool CDeterministicOptimizerChangeDetector::b_detect_change()

void CDeterministicOptimizerChangeDetector::v_clear_params()
{
	delete pc_population_optimizer;
	pc_population_optimizer = nullptr;

	v_clear_population_optimizer_sensors();
}//void CDeterministicOptimizerChangeDetector::v_clear_params()

void CDeterministicOptimizerChangeDetector::v_clustering()
{
	uint32_t i_number_of_sensors_to_clustering = (uint32_t)ceilf(f_fraction_of_sensors_to_clustering * (float)i_number_of_sensors);

	CRealCoding **ppc_points = new CRealCoding*[i_number_of_sensors_to_clustering];

	//unordered_set<uint32_t> s_selected_sensors_indexes_to_clustering(i_number_of_sensors_to_clustering);

	uint32_t *pi_random_order = new uint32_t[i_number_of_sensors];

	for (uint32_t i = 0; i < i_number_of_sensors; i++)
	{
		*(pi_random_order + i) = i;
	}//for (uint32_t i = 0; i < i_number_of_sensors; i++)

	random_shuffle(pi_random_order, pi_random_order + i_number_of_sensors);

	uint32_t i_random_index;

	for (uint32_t i = 0; i < i_number_of_sensors_to_clustering; i++)
	{
		i_random_index = *(pi_random_order + i);

		//i_random_index = RandUtils::iRandIndex(i_number_of_sensors);
		//i_random_index = RandUtils::iRandUniqueIndex(i_number_of_sensors, &s_selected_sensors_indexes_to_clustering);
		//s_selected_sensors_indexes_to_clustering.insert(i_random_index);

		*(ppc_points + i) = (*(ppc_sensors + i_random_index))->pcGetGenotype();
	}//for (uint32_t i = 0; i < i_number_of_sensors; i++)

	cout << "all" << endl;

	//s_selected_sensors_indexes_to_clustering.clear();

	delete pi_random_order;

	c_kmeans.vRun(i_number_of_sensors_to_clustering, ppc_points);

	delete ppc_points;
}//void CDeterministicOptimizerChangeDetector::v_clustering()

void CDeterministicOptimizerChangeDetector::v_clear_population_optimizer_sensors()
{
	if (pv_population_optimizer_sensors)
	{
		vector<CIndividual<CRealCoding, CRealCoding>*> *pv_single_population_optimizer_sensors;

		for (uint32_t i = 0; i < c_kmeans.iGetNumberOfClusters(); i++)
		{
			pv_single_population_optimizer_sensors = pv_population_optimizer_sensors + i;

			for (uint32_t j = 0; j < (uint32_t)pv_single_population_optimizer_sensors->size(); j++)
			{
				delete pv_single_population_optimizer_sensors->at(j);
			}//for (uint32_t j = 0; j < (uint32_t)pv_single_population_optimizer_sensors->size(); j++)

			pv_single_population_optimizer_sensors->clear();
		}//for (uint32_t i = 0; i < c_kmeans.iGetNumberOfClusters(); i++)

		delete[] pv_population_optimizer_sensors;
		pv_population_optimizer_sensors = nullptr;
	}//if (pv_population_optimizer_sensors)
}//void CDeterministicOptimizerChangeDetector::v_clear_population_optimizer_sensors()

void CDeterministicOptimizerChangeDetector::v_set_population_optimizer_sensors()
{
	v_clear_population_optimizer_sensors();

	pv_population_optimizer_sensors = new vector<CIndividual<CRealCoding, CRealCoding>*>[c_kmeans.iGetNumberOfClusters()];

	vector<CIndividual<CRealCoding, CRealCoding>*> *pv_single_population_optimizer_sensors;

	CCluster<CRealCoding> *pc_cluster;

	uint32_t i_iteration_number;
	uint64_t i_initial_ffe;

	RandUtils::vInit(i_random_seed);

	CRealCoding **ppc_cluster_points;
	CIndividual<CRealCoding, CRealCoding> *pc_local_optimizer_individual;

	for (uint32_t i = 0; i < c_kmeans.iGetNumberOfClusters(); i++)
	{
		pv_single_population_optimizer_sensors = pv_population_optimizer_sensors + i;

		pc_cluster = *(c_kmeans.ppcGetClusters() + i);

		if (pc_cluster->iGetSize() > 3)
		{
			cout << pc_cluster->iGetSize() << endl;

			ppc_cluster_points = new CRealCoding*[pc_cluster->iGetSize()];

			for (uint32_t j = 0; j < pc_cluster->iGetSize(); j++)
			{
				pc_local_optimizer_individual = new CIndividual<CRealCoding, CRealCoding>(new CRealCoding(*(pc_cluster->ppcGetPoints() + j)), pc_problem);

				pc_local_optimizer_individual->vEvaluate();
				pc_problem->pcGetEvaluation()->vDecreaseFFE();

				c_local_optimizer.vSetBestIndividual(pc_local_optimizer_individual);
				c_local_optimizer.vRun();

				*(ppc_cluster_points + j) = new CRealCoding(c_local_optimizer.pcGetBestIndividual()->pcGetGenotype());

				delete pc_local_optimizer_individual;
			}//for (uint32_t j = 0; j < pc_cluster->iGetSize(); j++)

			pc_population_optimizer->vInjectGenotypes(pc_cluster->iGetSize(), ppc_cluster_points, false);

			i_iteration_number = 0;
			i_initial_ffe = pc_problem->pcGetEvaluation()->iGetFFE();

			pc_population_optimizer->vInitialize();

			pc_problem->pcGetEvaluation()->vSetFFE(i_initial_ffe);

			//for (uint32_t j = 0; j < pc_population_optimizer->i_population_size; j++)
			//{
			//	c_local_optimizer.vSetBestIndividual(*(pc_population_optimizer->ppc_population + j));

			//	cout << "before" << endl;

			//	c_local_optimizer.vRun();

			//	cout << "after" << endl;

			//	delete *(pc_population_optimizer->ppc_population + j);
			//	*(pc_population_optimizer->ppc_population + j) = new CIndividual<CRealCoding, CRealCoding>(c_local_optimizer.pcGetBestIndividual());
			//}//for (uint32_t j = 0; j < pc_population_optimizer->i_population_size; j++)

			bool b_found_same;

			while (!pc_population_optimizer->pc_stop_condition->bStop(&(pc_population_optimizer->c_optimizer_timer), i_iteration_number, pc_problem->pcGetEvaluation()->iGetFFE() - i_initial_ffe, pc_population_optimizer->pc_best_individual))
			{
				pc_population_optimizer->bRunIteration(i_iteration_number);

				if (i_iteration_number > 0 && i_iteration_number % i_store_frequency == 0)
				{
					for (uint32_t j = 0; j < pc_population_optimizer->i_population_size; j++)
					{
						b_found_same = false;

						for (uint32_t k = 0; k < (uint32_t)pv_single_population_optimizer_sensors->size() && !b_found_same; k++)
						{
							b_found_same = !pv_single_population_optimizer_sensors->at(k)->pcGetGenotype()->bExceededMaxDistance((*(pc_population_optimizer->ppc_population + j))->pcGetGenotype(), 0, nullptr);
						}//for (uint32_t k = 0; k < (uint32_t)pv_single_population_optimizer_sensors->size() && !b_found_same; k++)

						if (!b_found_same)
						{
							pv_single_population_optimizer_sensors->push_back(new CIndividual<CRealCoding, CRealCoding>(*(pc_population_optimizer->ppc_population + j)));
						}//if (!b_found_same)
					}//for (uint32_t j = 0; j < pc_population_optimizer->i_population_size; j++)
				}//if (i_iteration_number > 0 && i_iteration_number % i_store_frequency == 0)

				i_iteration_number++;
			}//while (!pc_stop_condition->bStop(t_start_time, i_iteration_number, pc_problem->pcGetEvaluation()->iGetFFE() - i_initial_ffe, pc_best_individual))

			for (uint32_t j = 0; j < pc_population_optimizer->i_population_size; j++)
			{
				CString s_msg((*(pc_population_optimizer->ppc_population + j))->pcGetFenotype()->sToString());
				s_msg.AppendFormat("(%f)", (*(pc_population_optimizer->ppc_population + j))->dGetFitnessValue());

				pc_log->vPrintLine(s_msg);
			}//for (uint32_t j = 0; j < pc_population_optimizer->i_population_size; j++)

			CString s_size;
			s_size.Format("optimizer sensors: %d", pv_single_population_optimizer_sensors->size());

			pc_log->vPrintLine(s_size, true);

			pc_log->vPrintLine(pc_population_optimizer->pcGetBestIndividual()->pcGetFenotype()->sToString());

			for (uint32_t j = 0; j < pc_cluster->iGetSize(); j++)
			{
				delete *(ppc_cluster_points + j);
			}//for (uint32_t j = 0; j < pc_cluster->iGetSize(); j++)

			delete ppc_cluster_points;
		}//if (pc_cluster->iGetSize() > 3)
	}//for (uint32_t i = 0; i < c_kmeans.iGetNumberOfClusters(); i++)
}//void CDeterministicOptimizerChangeDetector::v_set_population_optimizer_sensors()