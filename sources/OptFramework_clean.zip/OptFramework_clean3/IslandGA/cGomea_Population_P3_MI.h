#pragma once

#include <cmath>
#include <iostream> 
#include <vector>
#include <csignal>
using namespace std;

#include "cGomea_Individual.h"
#include "cGomea_Config.h"
#include "cGomea_shared.h"
#include "cGomea_problems.h"
#include "cGomea_FOS.h"
#include "cGomea_PopulationGeneral.h"

class C_CGomea_Population_P3_MI: public C_CGomea_PopulationGeneral
{
public:
	
	C_CGomea_Population_P3_MI(C_CGomea_Config *config_, C_CGomea_Problem *problemInstance_, C_CGomea_sharedInformation *sharedInformationPointer_, size_t GOMEAIndex_, size_t populationSize_):
		C_CGomea_PopulationGeneral(config_, problemInstance_, sharedInformationPointer_, GOMEAIndex_, populationSize_){};
	~C_CGomea_Population_P3_MI();

	void makeOffspring();
	void generateOffspring();
	bool GOM(size_t offspringIndex, C_CGomea_Individual *backup);
	bool conditionalGOM(size_t offspringIndex, C_CGomea_Individual *backup, vector<vector<int> > &neighbors);
};