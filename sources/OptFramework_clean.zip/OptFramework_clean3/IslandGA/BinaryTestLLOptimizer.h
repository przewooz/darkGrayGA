#ifndef BINARY_TEST_LL_OPTIMIZER_H
#define BINARY_TEST_LL_OPTIMIZER_H

#include "BinaryCoding.h"
#include "Error.h"
#include "GenePattern.h"
#include "GenePatternTree.h"
#include "Log.h"
#include "Optimizer.h"
#include "PopulationOptimizer.h"
#include "Problem.h"

#include <istream>
#include <cstdint>
#include <ctime>
#include <vector>

using namespace Linkage;

using namespace std;

class CBinaryTestLLOptimizer : public CPopulationOptimizer<CBinaryCoding, CBinaryCoding>
{
public:
	CBinaryTestLLOptimizer(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed);
	CBinaryTestLLOptimizer(CBinaryTestLLOptimizer *pcOther);

	virtual COptimizer<CBinaryCoding, CBinaryCoding> *pcCopy() { return new CBinaryTestLLOptimizer(this); };

	virtual bool bRunIteration(uint32_t iIterationNumber);

private:
	double **ppd_get_distances(CIndividual<CBinaryCoding, CBinaryCoding> **ppcPopulation, uint32_t iPopulationSize, uint16_t iElementIndex);

	vector<CGenePatternTree*> *pv_get_individual_trees(CIndividual<CBinaryCoding, CBinaryCoding> **ppcPopulation, uint32_t iPopulationSize);
	vector<CGenePattern*> *pv_get_patterns(vector<CGenePatternTree*> *pvIndividualTrees, CIndividual<CBinaryCoding, CBinaryCoding> **ppcPopulation, uint32_t iPopulationSize, uint16_t iElementIndex);

	static int32_t i_get_bit(CIndividual<CBinaryCoding, CBinaryCoding> **ppcPopulation, uint32_t iIndividualIndex, uint16_t iElementIndex);
	static int32_t i_get_first_bit(CGenePattern *pcIndividualPattern, CIndividual<CBinaryCoding, CBinaryCoding> **ppcPopulation, uint16_t iElementIndex);
	static bool b_all_the_same_bits(CGenePattern *pcIndividualPattern, CIndividual<CBinaryCoding, CBinaryCoding> **ppcPopulation, uint16_t iElementIndex);

	void v_optimal_mixing(CIndividual<CBinaryCoding, CBinaryCoding> **ppcIndividual, vector<CGenePattern*>* pvPatterns);
	void v_optimal_mixing(CIndividual<CBinaryCoding, CBinaryCoding> **ppcIndividual, CGenePattern *pcPattern);
};//class CBinaryTestLLOptimizer : public CPopulationOptimizer<CBinaryCoding, CBinaryCoding>

#endif//BINARY_TEST_LL_OPTIMIZER_H