#include "RandomSearchGreedy.h"



using  namespace nRandomSearchGreedy;



uint32_t CRandomSearchGreedy::iERROR_PARENT_CRandomSearchGreedy = CError::iADD_ERROR_PARENT("iERROR_PARENT_CRandomSearchGreedy");
uint32_t CRandomSearchGreedy::iERROR_CODE_CRandomSearchGreedy_GENOTYPE_LEN_BELOW_0 = CError::iADD_ERROR("iERROR_CODE_CRandomSearchGreedy_GENOTYPE_LEN_BELOW_0");





//---------------------------------------------CRandomSearchGreedy-------------------------------------------------------
CRandomSearchGreedy::CRandomSearchGreedy(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)
	: CBinaryOptimizer(pcProblem, pcLog, iRandomSeed)
{
	pc_best = NULL;
	pc_ind_current = NULL;
	pc_linkage_pack = NULL;
};//CRandomSearchGreedy::CRandomSearchGreedy(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)



CRandomSearchGreedy::CRandomSearchGreedy(CRandomSearchGreedy *pcOther) : CBinaryOptimizer(pcOther)
{
	::MessageBox(NULL, "Brak implementacji: CRandomSearchGreedy::CRandomSearchGreedy(CDarkGrayGA *pcOther) : CBinaryOptimizer(pcOther)", "BRAK", MB_OK);
}//CRandomSearchGreedy::CRandomSearchGreedy(CRandomSearchGreedy *pcOther) : CBinaryOptimizer(pcOther)



CRandomSearchGreedy::~CRandomSearchGreedy()
{
	delete  pc_best;
	delete  pc_ind_current;
	delete  pc_ind_current_sll;

	if (pc_linkage_pack != NULL)  delete pc_linkage_pack;
}//CRandomSearchGreedy::~CRandomSearchGreedy()


void  CRandomSearchGreedy::vInitialize()
{
	c_optimizer_timer.vSetStartNow();
	i_templ_length = pc_problem->pcGetEvaluation()->iGetNumberOfElements();

	pc_best = new CRandomSearchGreedyIndividual(i_templ_length, pc_problem, this);
	pc_best->vRandomizeGenotype();
	pc_best->dComputeFitness();

	pc_ind_current = new CRandomSearchGreedyIndividual(i_templ_length, pc_problem, this);
	pc_ind_current->vRandomizeGenotype();
	pc_ind_current->dComputeFitness();

	pc_ind_current_sll = new CRandomSearchGreedyIndividual(i_templ_length, pc_problem, this);
	pc_ind_current_sll->vRandomizeGenotype();
	pc_ind_current_sll->dComputeFitness();
}//void  CRandomSearchGreedy::vInitialize(time_t tStartTime)



CError CRandomSearchGreedy::eConfigure(istream *psSettings)
{
	CError c_err(iERROR_PARENT_CRandomSearchGreedy);


	c_err = COptimizer::eConfigure(psSettings);
	if (c_err)  return(c_err);

	CFloatCommandParam p_gene_mut_prob(RANDOM_SEARCH_GREEDY_GENE_MUT_PROB);
	d_gene_mut_prob = p_gene_mut_prob.fGetValue(psSettings, &c_err);
	if (c_err)  return(c_err);

	return c_err;
};//CError CDarkGrayGA::eConfigure(istream *psSettings)




bool CRandomSearchGreedy::bRunIteration(uint32_t iIterationNumber)
{
	CError c_err(iERROR_PARENT_CRandomSearchGreedy);

	CString  s_buf;


	double  d_best_fit_before;
	d_best_fit_before = pc_best->dComputeFitness();

	pc_ind_current->vRandomizeGenotype();
	pc_ind_current->vClearOptOrder();
	pc_ind_current->dComputeFitnessOptimize();

	if (pc_best->dComputeFitness() < pc_ind_current->dComputeFitness())  pc_best->vCopyFrom(pc_ind_current);

	b_update_best_individual(iIterationNumber, pc_best->piGetGenotype(), pc_best->dComputeFitness());
	d_time_last_time = c_optimizer_timer.dGetTimePassed();


	if (d_best_fit_before < pc_best->dComputeFitness())
	{
		s_buf.Format
		(
			"%.8lf [time: %.8lf] [FFE:%.0lf] [iter:%d]",
			pc_best->dComputeFitness(), 
			d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE(), iIterationNumber
		);
		pc_log->vPrintLine(s_buf, true);
	}//if (d_best_fit_before, pc_best->dComputeFitness())
	

	return(true);
}//bool CDarkGrayGA::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)


bool CRandomSearchGreedy::bRunIterationSeparateLinkage(uint32_t iIterationNumber, CLinkageAnalyzer  *pcSeparateLinkage)
{
	CError c_err(iERROR_PARENT_CRandomSearchGreedy);

	CString  s_buf;


	double  d_best_fit_before;
	d_best_fit_before = pc_best->dComputeFitness();

	pc_ind_current->vRandomizeGenotype();
	pc_ind_current->vClearOptOrder();
	pc_ind_current->dComputeFitnessOptimize();

	if (pc_best->dComputeFitness() < pc_ind_current->dComputeFitness())  pc_best->vCopyFrom(pc_ind_current);



	if (pcSeparateLinkage->bIsOutsideModeLinkageGenerating() == true)
	{
		if (pc_linkage_pack == NULL)
		{
			pcSeparateLinkage->bLinkagePackCreate(&pc_linkage_pack);
			pc_linkage_pack->vConfigure(pc_evaluation_individual->pcGetEvaluation(), pc_log, pc_evaluation_individual->pcGetPhenotype());
			pcSeparateLinkage->vResetProbabilities(pc_evaluation_individual->pcGetEvaluation()->iGetNumberOfElements());
		}//if (pc_linkage_pack == NULL)
	}//if (pc_parent->pc_linkage_analyzer->bIsOutsideModeLinkageGenerating() == true)





	if (pcSeparateLinkage->iGetOutsideLinkageMode() == OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_SLL)
	{
		v_optimize_separate_linkage(pcSeparateLinkage);
	}//if (pc_parent->pc_separate_linkage->iGetOutsideLinkageMode() == OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_SLL)




	b_update_best_individual(iIterationNumber, pc_best->piGetGenotype(), pc_best->dComputeFitness());
	d_time_last_time = c_optimizer_timer.dGetTimePassed();


	if (d_best_fit_before < pc_best->dComputeFitness())
	{
		s_buf.Format
		(
			"%.8lf [time: %.8lf] [FFE:%.0lf] [iter:%d]",
			pc_best->dComputeFitness(),
			d_time_last_time, (double)pc_problem->pcGetEvaluation()->iGetFFE(), iIterationNumber
		);
		pc_log->vPrintLine(s_buf, true);
	}//if (d_best_fit_before, pc_best->dComputeFitness())


	return(true);
}//bool CRandomSearchGreedy::bRunIterationSeparateLinkage(uint32_t iIterationNumber, CLinkageAnalyzer  *pcSeparateLinkage)



void  CRandomSearchGreedy::v_optimize_separate_linkage(CLinkageAnalyzer  *pcSeparateLinkage)
{
	int  i_clusters_after_sll, i_clusters_after_dled, i_clusters_after_hll;


	pc_linkage_pack->vAddAnotherIndividualGeneral(pc_ind_current->piGetGenotype());
	pc_linkage_pack->vSetSLL_GenerateDSMfromPop();
	pc_linkage_pack->vComputeDSM_SLL(false);
	i_clusters_after_sll = pc_linkage_pack->pcGetSingleLinkage()->pvGetP3Clusters()->size();


	if (pc_linkage_pack->pvGetPopToAnayze()->size() > 100)
	{
		/*FILE  *pf_dest;
		pf_dest = fopen("zzz_sll_test.txt", "w+");
		pc_linkage_pack->pcGetSingleLinkage()->vReportClusters(pf_dest);
		fclose(pf_dest);

		::Tools::vShow("zzz_sll_test.txt");*/
		CString  s_buf;
		bool  b_opt;

		b_opt = true;
		while (b_opt == true)
		{
			b_opt = false;
			b_opt = pc_ind_current_sll->bOptimizeByCluster(pc_ind_current, pc_linkage_pack);
			if (b_opt == true)
			{
				s_buf.Format("[CLUSTERopt Current] %.8lf -> %.8lf", pc_ind_current->dComputeFitness(), pc_ind_current_sll->dComputeFitness());
				//pc_log->vPrintLine(s_buf, true);
				pc_ind_current->vCopyFrom(pc_ind_current_sll);
			}//if (b_opt == true)

			if (pc_best->dComputeFitness() < pc_ind_current->dComputeFitness())  pc_best->vCopyFrom(pc_ind_current);
		}//while (b_opt == true)


		pc_ind_current->vCopyFrom(pc_best);
		b_opt = true;
		while (b_opt == true)
		{
			b_opt = false;
			b_opt = pc_ind_current_sll->bOptimizeByCluster(pc_ind_current, pc_linkage_pack);
			if (b_opt == true)
			{
				s_buf.Format("[CLUSTERopt BEST] %.8lf -> %.8lf", pc_ind_current->dComputeFitness(), pc_ind_current_sll->dComputeFitness());
				pc_log->vPrintLine(s_buf, true);
				pc_ind_current->vCopyFrom(pc_ind_current_sll);
			}//if (b_opt == true)

			if (pc_best->dComputeFitness() < pc_ind_current->dComputeFitness())  pc_best->vCopyFrom(pc_ind_current);
		}//while (b_opt == true)
		
	}//if (pc_linkage_pack->pvGetPopToAnayze()->size() > 100)
}//void  CRandomSearchGreedy::v_optimize_separate_linkage(CLinkageAnalyzer  *pcSeparateLinkage)



double CRandomSearchGreedy::dComputeFitness(int32_t *piBits)
{
	double d_fitness_value = d_compute_fitness_value(piBits);
	return(d_fitness_value);
}//double CRandomSearchGreedy::dComputeFitness(int32_t *piBits)




CString  CRandomSearchGreedy::sAdditionalSummaryInfo()
{
	CString  s_buf;

	return(s_buf);
};//CString  CRandomSearchGreedy::sAdditionalSummaryInfo() 






//---------------------------------------------CRandomSearchGreedyIndividual-------------------------------------------------------
CRandomSearchGreedyIndividual::CRandomSearchGreedyIndividual(int  iTemplLength, CProblem<CBinaryCoding, CBinaryCoding > *pcProblem, CRandomSearchGreedy  *pcParent)
{
	i_templ_length = iTemplLength;
	pc_parent = pcParent;

	pi_genotype = new int[i_templ_length];

	pc_problem = pcProblem;

	d_fitnes_buf = -1;
	b_fitness_actual = false;
	
	vRandomizeGenotype();
}//CDarkGrayGAIndividual::CDarkGrayGAIndividual(int  iTemplLength, CProblem<CBinaryCoding, CBinaryCoding > *pcProblem, CDarkGrayGA  *pcParent)


CRandomSearchGreedyIndividual::CRandomSearchGreedyIndividual(CRandomSearchGreedyIndividual &pcOther)
{
	::Tools::vShow("No implementation: CRandomSearchGreedyIndividual::CRandomSearchGreedyIndividual(CRandomSearchGreedyIndividual &pcOther)");
}//CRandomSearchGreedyIndividual::CRandomSearchGreedyIndividual(CRandomSearchGreedyIndividual &pcOther)


CRandomSearchGreedyIndividual::~CRandomSearchGreedyIndividual()
{
	delete  pi_genotype;
};//CRandomSearchGreedyIndividual::~CRandomSearchGreedyIndividual()


void  CRandomSearchGreedyIndividual::vCopyFrom(CRandomSearchGreedyIndividual  *pcOther)
{
	this->pc_parent = pcOther->pc_parent;
	this->i_templ_length = pcOther->i_templ_length;//aaa
	this->v_opt_order = pcOther->v_opt_order;
	this->d_fitnes_buf = pcOther->d_fitnes_buf;
	this->b_fitness_actual = pcOther->b_fitness_actual;
	this->pc_problem = pcOther->pc_problem;


	for (int ii = 0; ii < i_templ_length; ii++)
		pi_genotype[ii] = pcOther->pi_genotype[ii];

}//void  CRandomSearchGreedyIndividual::vCopyFrom(CRandomSearchGreedyIndividual  *pcOther)


bool  CRandomSearchGreedyIndividual::bOptimizeByCluster(CRandomSearchGreedyIndividual  *pcBaseIndividual, CLinkageInformationPack *pcSeparateLinkage)
{
	int  i_cluster_offset;
	int  i_gene_offset;
	for (int i_cluster_order = 0; i_cluster_order < pcSeparateLinkage->pcGetSingleLinkage()->pvGetP3ClusterOrdering()->size(); i_cluster_order++)
	{
		vCopyFrom(pcBaseIndividual);
		b_fitness_actual = false;

		i_cluster_offset = pcSeparateLinkage->pcGetSingleLinkage()->pvGetP3ClusterOrdering()->at(i_cluster_order);
		for (int i_cluster_node = 0; i_cluster_node < pcSeparateLinkage->pcGetSingleLinkage()->pvGetP3Clusters()->at(i_cluster_offset).size(); i_cluster_node++)
		{
			i_gene_offset = pcSeparateLinkage->pcGetSingleLinkage()->pvGetP3Clusters()->at(i_cluster_offset).at(i_cluster_node);
			pi_genotype[i_gene_offset] = RandUtils::iRandNumber(0, 1);
		}//for (int i_cluster_node = 0; i_cluster_node < pcSeparateLinkage->pcGetSingleLinkage()->pvGetP3Clusters()->at(i_cluster_offset).size(); i_cluster_node++)

		if (this->dComputeFitness() > pcBaseIndividual->dComputeFitness())  return(true);
	}//for (int i_cluster_order = 0; pcSeparateLinkage->pcGetSingleLinkage()->pvGetP3ClusterOrdering()->size(); i_cluster_order++)

	return(false);
}//void  CRandomSearchGreedyIndividual::vOptimizeByCluster(CRandomSearchGreedyIndividual  *pcBaseIndividual, CLinkageInformationPack *pcSeparateLinkage)


bool  CRandomSearchGreedyIndividual::bIsTheSame(CRandomSearchGreedyIndividual  *pcOther)
{
	if ((pi_genotype == NULL))  return(false);
	if ((pcOther->pi_genotype == NULL))  return(false);

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (pi_genotype[ii] != pcOther->pi_genotype[ii])  return(false);
	}//for  (int  ii = 0; ii < i_templ_length;  ii++)

	return(true);
}//bool  CDarkGrayGAIndividual::bIsTheSame(CDarkGrayGAIndividual  *pcOther)


double  CRandomSearchGreedyIndividual::dGetSimilarity(CRandomSearchGreedyIndividual  *pcOther, int  *piGenesTheSame)
{
	int  i_genes_the_same;
	if (piGenesTheSame == NULL)  piGenesTheSame = &i_genes_the_same;
	*piGenesTheSame = 0;

	if ((pi_genotype == NULL))  return(0);
	if ((pcOther->pi_genotype == NULL))  return(0);


	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (pi_genotype[ii] == pcOther->pi_genotype[ii])  (*piGenesTheSame)++;
	}//for  (int  ii = 0; ii < i_templ_length;  ii++)

	double  d_res;
	d_res = *piGenesTheSame;
	d_res = d_res / i_templ_length;

	return(d_res);
}//double  CRandomSearchGreedyIndividual::dGetSimilarity(CDarkGrayGAIndividual  *pcOther, int  *piGenesTheSame)




void  CRandomSearchGreedyIndividual::vRandomizeGenotype()
{
	d_fitnes_buf = -1;
	b_fitness_actual = false;

	for (int ii = 0; ii < i_templ_length; ii++)
		pi_genotype[ii] = RandUtils::iRandNumber(0, 1);

};//void  CRandomSearchGreedyIndividual::vRandomizeGenotype()


double  CRandomSearchGreedyIndividual::dComputeFitness()
{
	if (b_fitness_actual == true)  return(d_fitnes_buf);

	d_fitnes_buf = pc_parent->dComputeFitness(pi_genotype);
	b_fitness_actual = true;

	return(d_fitnes_buf);
};//double  CRandomSearchGreedyIndividual::dComputeFitness()



void  CRandomSearchGreedyIndividual::v_create_opt_order(vector<int>  *pvOrder)
{
	vector<int>  v_temp;

	pvOrder->clear();

	for (int ii = 0; ii < i_templ_length; ii++)
		v_temp.push_back(ii);

	int  i_pos;
	while (v_temp.size() > 0)
	{
		i_pos = RandUtils::iRandNumber(0, v_temp.size() - 1);
		pvOrder->push_back(v_temp.at(i_pos));
		v_temp.erase(v_temp.begin() + i_pos);
	}//while  (v_temp.size() > 0)
}//void  CRandomSearchGreedyIndividual::v_create_opt_order(vector<int>  *pvOrder)




double  CRandomSearchGreedyIndividual::d_optimize_single_gene(int  iOptGene)
{
	double  d_fitness_current, d_fit_new;
	d_fitness_current = dComputeFitness();

	if (pi_genotype[iOptGene] == 1)
		pi_genotype[iOptGene] = 0;
	else
		pi_genotype[iOptGene] = 1;

	b_fitness_actual = false;
	d_fit_new = dComputeFitness();

	if (d_fit_new > d_fitness_current)  return(d_fit_new);


	//flip back...
	if (pi_genotype[iOptGene] == 1)
		pi_genotype[iOptGene] = 0;
	else
		pi_genotype[iOptGene] = 1;
	b_fitness_actual = true;
	this->d_fitnes_buf = d_fitness_current;

	return(this->d_fitnes_buf);
}//double  CRandomSearchGreedyIndividual::d_optimize_single_gene(int  iOptGene)



double  CRandomSearchGreedyIndividual::dComputeFitnessOptimize(vector<int>  *pvOrder /*= NULL*/)
{
	CString  s_buf;

	if (pvOrder == NULL)  pvOrder = &v_opt_order;
	if (pvOrder->size() != i_templ_length)  v_create_opt_order(pvOrder);


	int  i_opt_gene;
	int  i_orig_gene_val;
	bool  b_changed;

	b_changed = true;

	//::Tools::vShow("IN");


	int  i_opt_counter = 0;
	while (b_changed == true)
	{
		//double  d_start, d_end;
		//d_start = dComputeFitness();

		i_opt_counter++;
		b_changed = false;
		for (int ii = 0; ii < pvOrder->size(); ii++)
		{
			i_opt_gene = pvOrder->at(ii);
			i_orig_gene_val = pi_genotype[i_opt_gene];

			d_optimize_single_gene(i_opt_gene);

			if (i_orig_gene_val != pi_genotype[i_opt_gene])  b_changed = true;
		}//for  (int  i_opt_traj = 0; i_opt_traj < i_number_of_pairs; i_opt_traj++)

		//d_end = dComputeFitness();
		//s_buf.Format("%.8lf -> %.8lf", d_start, d_end);
		//::Tools::vShow(s_buf);
	}//while (b_changed == true)

	//::Tools::vShow(i_opt_counter);


	return(dComputeFitness());
};//double  CRandomSearchGreedyIndividual::dComputeFitnessOptimize()



