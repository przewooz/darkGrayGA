#include "GenePatternList.h"

#include "RandUtils.h"

CGenePatternList::CGenePatternList(uint32_t iMaxSize, CGenePatternReplacement *pcGenePatternReplacement)
{
	i_max_size = iMaxSize;
	pc_gene_pattern_replacement = pcGenePatternReplacement;

	i_number_of_gene_patterns = 0;
	ppc_gene_patterns = new CGenePattern*[iMaxSize];

	*(ppc_gene_patterns + 0) = nullptr;
}//CGenePatternList::CGenePatternList(uint32_t iNumberOfGenePatterns, CGenePatternReplacement *pcGenePatternReplacement)

CGenePatternList::CGenePatternList(ahcreport *pcReport, uint32_t iPopulationSize, uint16_t iSignificantIndex)
{
	i_number_of_gene_patterns = (uint32_t)pcReport->z.rows() + iPopulationSize;

	i_max_size = i_number_of_gene_patterns;
	pc_gene_pattern_replacement = nullptr;

	ppc_gene_patterns = new CGenePattern*[i_number_of_gene_patterns];

	CGenePattern *pc_gene_pattern, *pc_single_gene_pattern;
	uint32_t i_index;

	for (ae_int_t i = 0; i < pcReport->z.rows(); i++)
	{
		pc_gene_pattern = new CGenePattern(iSignificantIndex);

		for (ae_int_t j = 0; j < pcReport->z.cols(); j++)
		{
			i_index = (uint32_t)(*(pcReport->z[i] + j));

			if (i_index < iPopulationSize)
			{
				pc_single_gene_pattern = new CGenePattern(iSignificantIndex);
				pc_single_gene_pattern->vAdd((uint16_t)i_index);

				*(ppc_gene_patterns + i_index) = pc_single_gene_pattern;
			}//if (i_index < iPopulationSize)

			pc_gene_pattern->vAdd(*(ppc_gene_patterns + i_index));
		}//for (ae_int_t j = 0; j < pcReport->z.cols(); j++)

		*(ppc_gene_patterns + iPopulationSize + i) = pc_gene_pattern;
	}//for (uint32_t i = 0; i < (uint32_t)pcReport->z.rows(); i++)
}//CGenePatternList::CGenePatternList(ahcreport *pcReport, uint32_t iPopulationSize, uint16_t iSignificantIndex)

CGenePatternList::~CGenePatternList()
{
	for (uint32_t i = 0; i < i_number_of_gene_patterns; i++)
	{
		delete *(ppc_gene_patterns + i);
	}//for (uint32_t i = 0; i < i_number_of_gene_patterns; i++)

	delete ppc_gene_patterns;
	delete pc_gene_pattern_replacement;
}//CGenePatternList::~CGenePatternList()

#include <iostream>
using namespace std;

void CGenePatternList::vAdd(CGenePattern *pcGenePattern)
{
	if (i_number_of_gene_patterns < i_max_size)
	{
		*(ppc_gene_patterns + i_number_of_gene_patterns) = pcGenePattern;
		i_number_of_gene_patterns++;
	}//if (i_number_of_gene_patterns < i_max_size)
	else
	{
		if (pc_gene_pattern_replacement != nullptr)
		{
			pc_gene_pattern_replacement->vReplace(pcGenePattern, i_number_of_gene_patterns, ppc_gene_patterns);
		}//if (pc_gene_pattern_replacement != nullptr)
	}//else if (i_number_of_gene_patterns < i_max_size)

		/*cout << endl;

	for (int j = 0; j < i_number_of_gene_patterns; j++)
	{
		pcGenePattern = *(ppc_gene_patterns + j);

		cout << endl;

			for (int i = 0; i < pcGenePattern->iGetSize(); i++)
			{
				cout << *(pcGenePattern->piGetPattern() + i) << " ";
			}

			cout << endl;
	}



	cout << endl;
	cout << i_number_of_gene_patterns << endl << endl;*/

}//void CGenePatternList::vAdd(CGenePattern *pcGenePattern)

CGenePattern * CGenePatternList::pcGetRandomGenePattern()
{
	uint32_t i_random_index;

	return pcGetRandomGenePattern(&i_random_index);
}//CGenePattern * CGenePatternList::pcGetRandomGenePattern()

CGenePattern * CGenePatternList::pcGetRandomGenePattern(uint32_t *piRandomIndex)
{
	*piRandomIndex = RandUtils::iRandIndex(i_number_of_gene_patterns);

	//cout << endl;

	//CGenePattern *pc_gene_pattern = *(ppc_gene_patterns + *piRandomIndex);

	//for (int i = 0; i < pc_gene_pattern->iGetSize(); i++)
	//{
	//	cout << *(pc_gene_pattern->piGetPattern() + i) << " ";
	//}

	//cout << endl;

	return *(ppc_gene_patterns + *piRandomIndex);
}//CGenePattern * CGenePatternList::pcGetRandomGenePattern(uint32_t *piRandomIndex)