#include "P3.h"

#include "CommandParam.h"
#include "FloatCommandParam.h"
#include "UIntCommandParam.h"
#include "StringUtils.h"

#include <algorithm>
#include <functional>
#include <vector>

CP3::CP3(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed)
	: CP3BasedOptimizer("Pyramid", pcProblem, pcLog, iRandomSeed)
{
	b_multi_obj_domination_fitness_compare = false;
	i_max_pyramid_level = -1;
	b_no_bias_linkage_improver = false;
}//CP3::CP3(CP3Params *pcParams, CLog *pcLog, uint32_t iRandomSeed)

CP3::CP3(CP3 *pcOther)
	: CP3BasedOptimizer(pcOther)
{
	b_with_feedback = pcOther->b_with_feedback;
	f_feedback_probability = pcOther->f_feedback_probability;

	i_max_pyramid_level = pcOther->i_max_pyramid_level;
	b_multi_obj_domination_fitness_compare = pcOther->b_multi_obj_domination_fitness_compare;

	i_sep_link_clusters_order = pcOther->i_sep_link_clusters_order;
	i_opt_at_init = pcOther->i_opt_at_init;
}//CP3::CP3(CP3 *pcOther)


CError CP3::eConfigure(istream *psSettings)
{
	CError c_error = CP3BasedOptimizer::eConfigure(psSettings);

	if (!c_error)
	{
		CBoolCommandParam p_with_feedback(P3_ARGUMENT_FEEDBACK);
		b_with_feedback = p_with_feedback.bGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error && b_with_feedback)
	{
		CFloatCommandParam p_feedback_probability(P3_ARGUMENT_FEEDBACK_PROBABILITY, 0.0f, 1.0f);
		f_feedback_probability = p_feedback_probability.fGetValue(psSettings, &c_error);
	}//if (!c_error && b_with_feedback)

	
	if (!c_error)
	{
		CUIntCommandParam p_sep_link_clusters_order(P3_ARGUMENT_CLUSTERS_ORDER_SEP_LINKAGE);
		i_sep_link_clusters_order = p_sep_link_clusters_order.iGetValue(psSettings, &c_error);
	}//if (!c_error)


	if (!c_error)
	{
		CUIntCommandParam p_opt_at_init(P3_ARGUMENT_OPT_AT_INIT);
		i_opt_at_init = p_opt_at_init.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	
	
	i_max_pyramid_level = -1;
	if (!c_error)
	{
		CUIntCommandParam p_max_pyramid_level(P3_ARGUMENT_MAX_PYRAMID_LEVEL, false);

		i_max_pyramid_level = p_max_pyramid_level.iGetValue(psSettings, &c_error);
		if (p_max_pyramid_level.bHasValue() == false)  i_max_pyramid_level = -1;
	}//if (!c_error)



	i_super_cross_with_best = -1;
	if (!c_error)
	{
		CUIntCommandParam p_super_cross_with_best(P3_ARGUMENT_SUPERCROSS_WITH_BEST, false);
		i_super_cross_with_best = p_super_cross_with_best.iGetValue(psSettings, &c_error);
		if (p_super_cross_with_best.bHasValue() == false)  i_super_cross_with_best = -1;
	}//if (!c_error)


	i_super_cross_with_best_only_final_climb = 0;
	if (!c_error)
	{
		CUIntCommandParam p_super_cross_with_best_only_final_climb(P3_ARGUMENT_SUPERCROSS_WITH_BEST_ONLY_FINAL_CLIMB, false);
		i_super_cross_with_best_only_final_climb = p_super_cross_with_best_only_final_climb.iGetValue(psSettings, &c_error);
		if (p_super_cross_with_best_only_final_climb.bHasValue() == false)  i_super_cross_with_best_only_final_climb = 0;
	}//if (!c_error)


	i_super_cross_with_best_only_final_climb_accumulate_linkage = 0;
	if (!c_error)
	{
		CUIntCommandParam p_super_cross_with_best_only_final_climb_accumulate_linkage(P3_ARGUMENT_SUPERCROSS_WITH_BEST_ONLY_FINAL_CLIMB_LINKAGE_ACCUMULATION, false);
		i_super_cross_with_best_only_final_climb_accumulate_linkage = p_super_cross_with_best_only_final_climb_accumulate_linkage.iGetValue(psSettings, &c_error);
		if (p_super_cross_with_best_only_final_climb_accumulate_linkage.bHasValue() == false)  i_super_cross_with_best_only_final_climb_accumulate_linkage = 0;
	}//if (!c_error)

	


	i_max_pop_size = -1;
	if (!c_error)
	{
		CUIntCommandParam p_max_pyramid_pop(P3_ARGUMENT_MAX_PYRAMID_POP, false);
		i_max_pop_size = p_max_pyramid_pop.iGetValue(psSettings, &c_error);
		if (p_max_pyramid_pop.bHasValue() == false)  i_max_pop_size = -1;
	}//if (!c_error)

	i_max_pop_unlimited_linkage = 0;
	if (!c_error)
	{
		CUIntCommandParam p_max_pyramid_pop_unlimited_linkage(P3_ARGUMENT_MAX_PYRAMID_POP_UNLIMITED_LINKAGE, false);
		i_max_pop_unlimited_linkage = p_max_pyramid_pop_unlimited_linkage.iGetValue(psSettings, &c_error);
		if (p_max_pyramid_pop_unlimited_linkage.bHasValue() == false)  i_max_pop_unlimited_linkage = 0;
	}//if (!c_error)



	i_bb_empower = 0;
	if (!c_error)
	{
		CUIntCommandParam p_bb_empower(P3_ARGUMENT_BBEMPOWER, false);
		i_bb_empower = p_bb_empower.iGetValue(psSettings, &c_error);
		if (p_bb_empower.bHasValue() == false)  i_bb_empower = 0;
	}//if (!c_error)



	i_gb_best_breaker = 0;
	if (!c_error)
	{
		CUIntCommandParam p_gb_best_breaker(P3_ARGUMENT_GB_BEST_BREAKER, false);
		i_gb_best_breaker = p_gb_best_breaker.iGetValue(psSettings, &c_error);
		if (p_gb_best_breaker.bHasValue() == false)  i_gb_best_breaker = 0;
	}//if (!c_error)


	i_gb_best_breaker = 0;
	if (!c_error)
	{
		CUIntCommandParam p_gb_best_breaker(P3_ARGUMENT_GB_BEST_BREAKER, false);
		i_gb_best_breaker = p_gb_best_breaker.iGetValue(psSettings, &c_error);
		if (p_gb_best_breaker.bHasValue() == false)  i_gb_best_breaker = 0;
	}//if (!c_error)


	if (!c_error)
	{
		CFloatCommandParam p_slide(OPTIMIZER_ARGUMENT_SLIDE, false);

		d_slide = p_slide.fGetValue(psSettings, &c_error);
		if (p_slide.bHasValue() == false)  d_slide = 1;
		if (d_slide != -1)//-1 is the automatic slide
		{
			if ((d_slide < 0) || (d_slide > 1))  d_slide = 1;
		}//if (d_slide != -1)
	}//if (!c_error)



			
	
	
	return c_error;
}//CError CP3::eConfigure(istream *psSettings)



vector<bool> * CP3::pvGetLastAdded()
{
	return(&pc_optimizer->v_last_added);
}//vector<bool> * CP3::pvGetLastAdded()

void CP3::vInitialize()
{
	CP3BasedOptimizer::vInitialize();
	pc_p3 = static_pointer_cast<Pyramid>(pc_optimizer);
	pc_p3->i_clusters_order = i_sep_link_clusters_order;
	pc_p3->i_opt_ind_at_init = i_opt_at_init;

	i_feedback_counter = 0;
	i_effective_feedback_counter = 0;
}//void CP3::vInitialize(time_t tStartTime)

#include "RandUtils.h"


bool CP3::bRunIterationSeparateLinkage(uint32_t iIterationNumber, CLinkageAnalyzer  *pcSeparateLinkage)
{
	bool b_updated;
		
	//::Tools::vShow("bool CP3::bRunIterationSeparateLinkage(uint32_t iIterationNumber, time_t tStartTime, CLinkageAnalyzer  *pcSeparateLinkage)");
	b_updated = CP3BasedOptimizer::bRunIterationSeparateLinkage(iIterationNumber, pcSeparateLinkage);

	return(b_updated);
}//bool CP3::bRunIterationSeparateLinkage(uint32_t iIterationNumber, time_t tStartTime, CLinkageAnalyzer  *pcSeparateLinkage)


void CP3::vReportLinkage()
{
	CP3BasedOptimizer::vReportLinkage();
}//void CP3::vReportLinkage()



bool CP3::bRunIteration(uint32_t iIterationNumber)
{
	bool b_updated = CP3BasedOptimizer::bRunIteration(iIterationNumber);

	//if (iIterationNumber % 1 == 0)
	{
		//v_log_linkage();
	}//if (iIterationNumber % 1 == 0)

	if (b_with_feedback && RandUtils::bSatisfyProbability(f_feedback_probability))
	{
		CBinaryCoding *pc_genotype = pc_best_individual->pcGetGenotype();//new CBinaryCoding(pc_best_individual->pcGetGenotype());

		//for (uint16_t i = 0; i < pc_genotype->iGetNumberOfBits(); i++)
		//{
		//	if (RandUtils::bSatisfyProbability(0.1))
		//	{
		//		*(pc_genotype->piGetBits() + i) ^= 1;
		//	}//if (RandUtils::bSatisfyProbability(0.5))
		//}//for (uint16_t i = 0; i < pc_genotype->iGetNumberOfBits(); i++)

		pc_log->vPrintLine("FEEDBACK");

		b_updated = bClimb(pc_genotype, iIterationNumber) || b_updated;

		pc_log->vPrintLine("END FEEDBACK");

		i_feedback_counter++;
	}//if (b_with_feedback)


	if (i_max_pyramid_level > 0)
	{
		while (iLevelsGetNumber() > i_max_pyramid_level)
		{
			CString  s_buf;
			int  i_before;

			i_before = iLevelsGetNumber();
			
			vLevelsRemoveLowest();

			s_buf.Format("REMOVING LEVEL; Levels: %d (before: %d)", iLevelsGetNumber(), i_before);
			pc_log->vPrintLine(s_buf, true);
		}//while (iLevelsGetNumber() > i_max_pyramid_level)
	}//if (i_max_pyramid_level > 0)


	if (i_max_pop_size > 0)
	{
		pc_p3->vLimitPop(i_max_pop_size, i_max_pop_unlimited_linkage);
	}//if (i_max_pop_size > 0)

	
	//int  iLevelsGetNumber() { return(pops.size()); }
	//void  vLevelsRemoveLowest() { pops.erase(pops.begin()); }

	return b_updated;
}//bool CP3::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)

void CP3::vRun()
{
	CP3BasedOptimizer::vRun();

	CString s_feedback_report;
	s_feedback_report.Format("all feedback: %d; effective feedback: %d (%f)", i_feedback_counter, 
		i_effective_feedback_counter, (float)i_effective_feedback_counter / (float)i_feedback_counter);

	pc_log->vPrintLine(s_feedback_report, true);


	CString  s_linkage, s_buf;
	for (int i_pop = 0; i_pop < pc_p3->pops.size(); i_pop++)
	{
		s_buf.Format("LEVEL: %d", i_pop);
		pc_log->vPrintLine(s_buf, true);

		for (int i_cluster = 0; i_cluster < pc_p3->pops.at(i_pop).used_clusters.size(); i_cluster++)
		{
			s_linkage.Format("%d: ", i_cluster);

			for (int ii = 0; ii < pc_p3->pops.at(i_pop).used_clusters.at(i_cluster).size(); ii++)
			{
				s_buf.Format(" %d,", pc_p3->pops.at(i_pop).used_clusters.at(i_cluster).at(ii));
				s_linkage += s_buf;
			}//for (int ii = 0; ii < pc_p3->pops.at(i_pop).used_clusters.at(i_cluster).size(); ii++)

			pc_log->vPrintLine(s_linkage, true);
		}//for (int i_cluster = 0; i_cluster < pc_p3->pops.at(i_pop).used_clusters.size(); i_cluster++)
	}//for (int i_pop = 0; i_pop < pc_p3->pops.size(); i_pop++)
	
}//void CP3::vRun()



void CP3::vExecuteBeforeEnd()
{
	pc_p3->vExecuteBeforeEnd();
}//void CP3::vExecuteBeforeEnd()


void CP3::vReportPopStats(CString  sFileName)
{
	pc_p3->vReportPopStats(sFileName);
}//void CP3::vReportPopStats(CString  sFileName)


int  CP3::iLevelsGetNumber()
{
	return(pc_p3->iLevelsGetNumber());
}//int  CP3::iLevelsGetNumber()


void  CP3::vLevelsRemoveLowest()
{
	pc_p3->vLevelsRemoveLowest();
}//void  CP3::vLevelsRemoveLowest()



bool CP3::bAdd(CBinaryCoding *pcGenotype, uint32_t iIterationNumber)
{
	bool b_added = false;

	vector<bool> v_p3_individual;

	v_p3_individual.reserve(pcGenotype->iGetNumberOfBits());

	for (uint16_t i = 0; i < pcGenotype->iGetNumberOfBits(); i++)
	{
		v_p3_individual.push_back(*(pcGenotype->piGetBits() + i) == 1);
	}//for (uint16_t i = 0; i < pcGenotype->iGetNumberOfBits(); i++)

	float f_p3_individual_fitness_value = pc_recorder->evaluate(v_p3_individual);

	b_added = pc_p3->add_unique(v_p3_individual, 0, *(pc_p3->pcGetEvaluator()));

	if (b_added == true)
	{
		b_update_best_individual(iIterationNumber);
	}//if (b_updated == true)

	
	return b_added;
}//bool CP3::bAdd(CBinaryCoding *pcGenotype, time_t tStartTime, uint32_t iIterationNumber)

bool CP3::bClimb(CBinaryCoding *pcGenotype, uint32_t iIterationNumber)
{
	bool b_updated = false;
	
	vector<bool> v_p3_individual;

	v_p3_individual.reserve(pcGenotype->iGetNumberOfBits());

	for (uint16_t i = 0; i < pcGenotype->iGetNumberOfBits(); i++)
	{
		v_p3_individual.push_back(*(pcGenotype->piGetBits() + i) == 1);
	}//for (uint16_t i = 0; i < pcGenotype->iGetNumberOfBits(); i++)

	float f_p3_individual_fitness_value = pc_recorder->evaluate(v_p3_individual);

	vector<size_t> v_added_to_levels;

	if (pc_p3->climb(v_p3_individual, f_p3_individual_fitness_value, v_added_to_levels))
	{
		i_effective_feedback_counter++;

		CIndividual<CBinaryCoding, CBinaryCoding> *pc_previous_best_individual = new CIndividual<CBinaryCoding, CBinaryCoding>(pc_best_individual);

		b_updated = b_update_best_individual(iIterationNumber);

		//if (b_updated)
		{
			pc_log->vPrintEmptyLine();
			pc_log->vPrintEmptyLine();
			pc_log->vPrintLine("EFFECTIVE FEEDBACK");
			pc_log->vPrintLine("PREVIOUS BEST");
			pc_log->vPrintLine(pc_previous_best_individual->pcGetGenotype()->sToString(10));
			pc_log->vPrintLine("NEW BEST");
			pc_log->vPrintLine(pc_best_individual->pcGetGenotype()->sToString(10));
			
			CString s_number_of_levels;
			s_number_of_levels.Format("NUMBER OF LEVELS: %d", pc_p3->pops.size());
			pc_log->vPrintLine(s_number_of_levels);

			CString s_added_to_levels;
			s_added_to_levels.Append("ADDED TO LEVELS:");

			for (size_t i = 0; i < v_added_to_levels.size(); i++)
			{
				s_added_to_levels.AppendFormat(" %d", v_added_to_levels.at(i));
			}//for (size_t i = 0; i < v_added_to_levels.size(); i++)

			pc_log->vPrintLine(s_added_to_levels);

			pc_log->vPrintEmptyLine();
			pc_log->vPrintEmptyLine();
		}//if (b_updated)
	}//if (pc_p3->climb(v_p3_individual, f_p3_individual_fitness_value, v_added_to_levels))

	//CString s_linkage_before_climg = s_create_linkage_report();

	//if (pc_p3->climb(v_p3_individual, f_p3_individual_fitness_value))
	//{
	//	pc_log->vPrintEmptyLine();
	//	pc_log->vPrintEmptyLine();
	//	pc_log->vPrintLine("EFFECTIVE FEEDBACK");
	//	pc_log->vPrintLine("CURRENT BEST");
	//	pc_log->vPrintLine(pc_best_individual->pcGetGenotype()->sToString(10));
	//	pc_log->vPrintLine("LINKAGE BEFORE");
	//	pc_log->vPrintLine(s_linkage_before_climg);
	//	pc_log->vPrintLine("LINKAGE AFTER");
	//	pc_log->vPrintLine(s_create_linkage_report());
	//	pc_log->vPrintEmptyLine();
	//	pc_log->vPrintEmptyLine();

	//	CIndividual<CBinaryCoding, CBinaryCoding> *pc_previous_best_individual = new CIndividual<CBinaryCoding, CBinaryCoding>(pc_best_individual);

	//	b_updated = b_update_best_individual(iIterationNumber, tStartTime);

	//	if (b_updated)
	//	{
	//		pc_log->vPrintEmptyLine();
	//		pc_log->vPrintEmptyLine();
	//		pc_log->vPrintLine("PREVIOUS BEST");
	//		pc_log->vPrintLine(pc_previous_best_individual->pcGetGenotype()->sToString(10));
	//		pc_log->vPrintLine("NEW BEST");
	//		pc_log->vPrintLine(pc_best_individual->pcGetGenotype()->sToString(10));
	//		pc_log->vPrintEmptyLine();
	//		pc_log->vPrintEmptyLine();
	//	}//if (b_updated)

	//	i_effective_feedback_counter++;
	//}//if (pc_p3->climb(v_p3_individual, f_p3_individual_fitness_value))

	return b_updated;
}//bool CP3::bClimb(CBinaryCoding *pcGenotype, time_t tStartTime, uint32_t iIterationNumber)

CString CP3::s_create_linkage_report()
{
	CString s_linkage_report;

	Population *pc_population;
	vector<int> *pv_linkage;

	uint16_t i_linkage_block_size = 10;
	uint16_t i_number_of_linkage_blocks = pc_problem->pcGetEvaluation()->iGetNumberOfElements() / i_linkage_block_size;
	uint16_t i_good_linkage_counter;

	size_t i_linkage_length_sum = 0;

	uint16_t i_linkage_value;
	uint16_t i_linkage_block_start, i_linkage_block_end;

	function<uint16_t(uint16_t)> fi_get_block_start = [=](uint16_t iBlockIndex) { return iBlockIndex * i_linkage_block_size; };
	function<uint16_t(uint16_t)> fi_get_block_end = [=](uint16_t iBlockIndex) { return (iBlockIndex + 1) * i_linkage_block_size - 1; };

	size_t i_number_of_linkages = 0;
	size_t i_number_of_linkages_with_at_least_one_whole_block = 0;

	size_t *pi_only_block_counters = new size_t[i_number_of_linkage_blocks];
	size_t *pi_block_with_other_blocks_counters = new size_t[i_number_of_linkage_blocks];
	size_t *pi_block_with_other_genes_counters = new size_t[i_number_of_linkage_blocks];

	vector<uint16_t> v_whole_blocks_indexes;
	bool b_at_least_one_not_whole_block;

	vector<CString> v_pure_linkages;
	vector<CString> v_dirty_linkages;

	function<void(size_t*)> fv_increase_counter = [&](size_t *piCounter)
	{
		for (size_t i = 0; i < v_whole_blocks_indexes.size(); i++)
		{
			(*(piCounter + v_whole_blocks_indexes.at(i)))++;
		}//for (size_t i = 0; i < v_whole_blocks_indexes.size(); i++)
	};//function<void(size_t*)> fv_increase_counter = [&](size_t *piCounter)

	for (uint16_t i = 0; i < i_number_of_linkage_blocks; i++)
	{
		*(pi_only_block_counters + i) = 0;
		*(pi_block_with_other_blocks_counters + i) = 0;
		*(pi_block_with_other_genes_counters + i) = 0;
	}//for (uint16_t i = 0; i < i_number_of_linkage_blocks; i++)

	for (size_t i = 0; i < pc_p3->pops.size(); i++)
	{
		pc_population = &pc_p3->pops.at(i);

		for (size_t j = 0; j < pc_population->cluster_ordering.size(); j++)
		{
			pv_linkage = &pc_population->clusters.at(pc_population->cluster_ordering.at(j));

			sort(pv_linkage->begin(), pv_linkage->end());

			v_whole_blocks_indexes.clear();
			b_at_least_one_not_whole_block = false;

			for (uint16_t k = 0; k < i_number_of_linkage_blocks; k++)
			{
				i_good_linkage_counter = 0;

				i_linkage_block_start = fi_get_block_start(k);
				i_linkage_block_end = fi_get_block_end(k);

				for (size_t m = 0; m < pv_linkage->size(); m++)
				{
					i_linkage_value = (uint16_t)pv_linkage->at(m);

					if (i_linkage_value >= i_linkage_block_start && i_linkage_value <= i_linkage_block_end)
					{
						i_good_linkage_counter++;
					}//if (i_linkage_value >= i_linkage_block_start && i_linkage_value <= i_linkage_block_end)
				}//for (size_t m = 0; k < pv_linkage->size(); m++)

				if (i_good_linkage_counter == i_linkage_block_size)
				{
					v_whole_blocks_indexes.push_back(k);
				}//if (i_good_linkage_counter == i_linkage_block_size)
				else
				{
					if (i_good_linkage_counter > 0)
					{
						b_at_least_one_not_whole_block = true;
					}//if (i_good_linkage_counter > 0)
				}//else if (i_good_linkage_counter == i_linkage_block_size)
			}//for (uint16_t k = 0; k < i_number_of_linkage_blocks; k++)

			if (b_at_least_one_not_whole_block)
			{
				if (!v_whole_blocks_indexes.empty())		
				{
					fv_increase_counter(pi_block_with_other_genes_counters);

					CString s_linkage;

					for (size_t k = 0; k < v_whole_blocks_indexes.size(); k++)
					{
						s_linkage.AppendFormat("[%d-%d] ", fi_get_block_start(v_whole_blocks_indexes.at(k)), fi_get_block_end(v_whole_blocks_indexes.at(k)));
					}//for (size_t k = 0; k < v_whole_blocks_indexes.size(); k++)

					for (size_t k = 0; k < pv_linkage->size(); k++)
					{
						i_linkage_value = pv_linkage->at(k);

						bool b_within_any_block = false;

						for (size_t m = 0; m < v_whole_blocks_indexes.size() && !b_within_any_block; m++)
						{
							i_linkage_block_start = fi_get_block_start(v_whole_blocks_indexes.at(m));
							i_linkage_block_end = fi_get_block_end(v_whole_blocks_indexes.at(m));
							b_within_any_block = i_linkage_value >= i_linkage_block_start && i_linkage_value <= i_linkage_block_end;
						}//for (size_t m = 0; m < v_whole_blocks_indexes.size() && !b_within_any_block; m++)

						if (!b_within_any_block)
						{
							s_linkage.AppendFormat("%d ", i_linkage_value);
						}//if (!b_within_any_block)
					}//for (size_t k = 0; k < pv_linkage->size(); k++)

					s_linkage.AppendFormat("(population: %d; order: %d; all: %d)", i, j, pc_population->cluster_ordering.size());
					v_dirty_linkages.push_back(s_linkage);
				}//if (!v_whole_blocks_indexes.empty())
			}//if (b_at_least_one_not_whole_block)
			else
			{
				if (v_whole_blocks_indexes.size() == 1)
				{
					fv_increase_counter(pi_only_block_counters);
				}//if (v_whole_blocks_indexes.size() == 1)
				else
				{
					fv_increase_counter(pi_block_with_other_blocks_counters);
				}//else if (v_whole_blocks_indexes.size() == 1)

				CString s_linkage_blocks;

				for (size_t k = 0; k < v_whole_blocks_indexes.size(); k++)
				{
					s_linkage_blocks.AppendFormat("[%d-%d] ", fi_get_block_start(v_whole_blocks_indexes.at(k)), fi_get_block_end(v_whole_blocks_indexes.at(k)));
				}//for (size_t k = 0; k < v_whole_blocks_indexes.size(); k++)

				s_linkage_blocks.AppendFormat("(population: %d; order: %d; all: %d)", i, j, pc_population->cluster_ordering.size());
				v_pure_linkages.push_back(s_linkage_blocks);
			}//else if (b_at_least_one_not_whole_block)

			if (!v_whole_blocks_indexes.empty())
			{
				i_number_of_linkages_with_at_least_one_whole_block++;
			}//if (!v_whole_blocks_indexes.empty())

			i_linkage_length_sum += pv_linkage->size();

			i_number_of_linkages++;
		}//for (size_t j = 0; j < pc_population->cluster_ordering.size(); j++)
	}//for (size_t i = 0; i < pc_p3->pops.size(); i++)

	s_linkage_report.AppendFormat("number of linkages: %d", i_number_of_linkages);
	StringUtils::vAppendEndLine(&s_linkage_report);

	s_linkage_report.AppendFormat("average linkage length: %f", (float)i_linkage_length_sum / (float)i_number_of_linkages);
	StringUtils::vAppendEndLine(&s_linkage_report);

	s_linkage_report.AppendFormat("number of linkages with at least one whole block: %d (%f)", i_number_of_linkages_with_at_least_one_whole_block,
		(float)i_number_of_linkages_with_at_least_one_whole_block / (float)i_number_of_linkages);
	StringUtils::vAppendEndLine(&s_linkage_report);

	s_linkage_report.AppendFormat("number of linkages without blocks: %d (%f)", i_number_of_linkages - i_number_of_linkages_with_at_least_one_whole_block,
		(float)(i_number_of_linkages - i_number_of_linkages_with_at_least_one_whole_block) / (float)i_number_of_linkages);
	StringUtils::vAppendEndLine(&s_linkage_report);

	s_linkage_report.AppendFormat("number of populations: %d", pc_p3->pops.size());
	StringUtils::vAppendEndLine(&s_linkage_report);

	s_linkage_report.AppendFormat("linkage per population: %f", (float)i_number_of_linkages / (float)pc_p3->pops.size());
	StringUtils::vAppendEndLine(&s_linkage_report);

	for (uint16_t i = 0; i < i_number_of_linkage_blocks; i++)
	{
		i_linkage_block_start = fi_get_block_start(i);
		i_linkage_block_end = fi_get_block_end(i);

		s_linkage_report.AppendFormat("[%d-%d] - only: %d (%f); with other whole blocks: %d (%f); with other genes: %d (%f)", i_linkage_block_start,
			i_linkage_block_end, *(pi_only_block_counters + i), (float)*(pi_only_block_counters + i) / (float)i_number_of_linkages, 
			*(pi_block_with_other_blocks_counters + i), (float)*(pi_block_with_other_blocks_counters + i) / (float)i_number_of_linkages,
			*(pi_block_with_other_genes_counters + i), (float)*(pi_block_with_other_genes_counters + i) / (float)i_number_of_linkages);
		StringUtils::vAppendEndLine(&s_linkage_report);
	}//for (uint16_t i = 0; i < i_number_of_linkage_blocks; i++)

	s_linkage_report.Append("pure linkage:");
	StringUtils::vAppendEndLine(&s_linkage_report);

	for (size_t i = 0; i < v_pure_linkages.size(); i++)
	{
		s_linkage_report.Append(v_pure_linkages.at(i));
		StringUtils::vAppendEndLine(&s_linkage_report);
	}//for (size_t i = 0; i < v_pure_linkages.size(); i++)

	s_linkage_report.Append("dirty linkage:");
	StringUtils::vAppendEndLine(&s_linkage_report);

	for (size_t i = 0; i < v_dirty_linkages.size(); i++)
	{
		s_linkage_report.Append(v_dirty_linkages.at(i));
		StringUtils::vAppendEndLine(&s_linkage_report);
	}//for (size_t i = 0; i < v_dirty_linkages.size(); i++)

	delete pi_only_block_counters;
	delete pi_block_with_other_blocks_counters;
	delete pi_block_with_other_genes_counters;

	return s_linkage_report;
}//CString CP3::s_create_linkage_report()

void CP3::v_log_linkage(bool bEcho)
{
	pc_log->vPrintLine(s_create_linkage_report(), bEcho);

	/*Population *pc_population;
	vector<int> *pv_linkage;

	uint16_t i_linkage_block_size = 10;
	uint16_t i_number_of_linkage_blocks = pc_problem->pcGetEvaluation()->iGetNumberOfElements() / i_linkage_block_size;
	uint16_t i_good_linkage_counter;

	uint16_t i_linkage_value;
	uint16_t i_linkage_block_start, i_linkage_block_end;*/

	//vector<CString> v_not_whole_blocks;
	//v_not_whole_blocks.resize(i_number_of_linkage_blocks);

	//for (size_t i = 0; i < pc_p3->pops.size(); i++)
	//{
	//	pc_population = &pc_p3->pops.at(i);

	//	CString s_population_level;
	//	s_population_level.Format("population level: %d", i);

	//	pc_log->vPrintLine(s_population_level, bEcho);

	//	for (size_t j = 0; j < pc_population->cluster_ordering.size(); j++)
	//	{
	//		pv_linkage = &pc_population->clusters.at(pc_population->cluster_ordering.at(j));

	//		v_not_whole_blocks.clear();

	//		CString s_linkage;

	//		for (uint16_t k = 0; k < i_number_of_linkage_blocks; k++)
	//		{
	//			i_good_linkage_counter = 0;

	//			i_linkage_block_start = k * i_linkage_block_size;
	//			i_linkage_block_end = (k + 1) * i_linkage_block_size - 1;

	//			CString s_block_linkage;

	//			for (size_t m = 0; m < pv_linkage->size(); m++)
	//			{
	//				i_linkage_value = (uint16_t)pv_linkage->at(m);

	//				if (i_linkage_value >= i_linkage_block_start && i_linkage_value <= i_linkage_block_end)
	//				{
	//					s_block_linkage.AppendFormat("%d ", i_linkage_value);
	//					i_good_linkage_counter++;
	//				}//if (i_linkage_value >= i_linkage_block_start && i_linkage_value <= i_linkage_block_end)
	//			}//for (size_t m = 0; k < pv_linkage->size(); m++)

	//			if (i_good_linkage_counter == i_linkage_block_size)
	//			{
	//				s_linkage.AppendFormat("%d-%d ", i_linkage_block_start, i_linkage_block_end);
	//			}//if (i_good_linkage_counter == i_linkage_block_size)
	//			else
	//			{
	//				v_not_whole_blocks.push_back(s_block_linkage);
	//			}//else if (i_good_linkage_counter == i_linkage_block_size)
	//		}//for (uint16_t k = 0; k < i_number_of_linkage_blocks; k++)

	//		if (!s_linkage.IsEmpty())
	//		{
	//			for (uint16_t k = 0; k < (uint16_t)v_not_whole_blocks.size(); k++)
	//			{
	//				s_linkage.Append(v_not_whole_blocks.at(k));
	//			}//for (uint16_t k = 0; k < (uint16_t)v_not_whole_blocks.size(); k++)

	//			pc_log->vPrintLine(s_linkage, bEcho);
	//		}//if (!s_linkage.IsEmpty())
	//	}//for (size_t j = 0; j < pc_population->cluster_ordering.size(); j++)
	//}//for (size_t i = 0; i < pc_p3->pops.size(); i++)
};//void CP3::v_log_linkage(bool bEcho)






//---------------------------------------------CMO_MPP3-------------------------------------------------------
uint32_t CMO_MPP3::iERROR_PARENT_CMO_MPP3_Optimizer = CError::iADD_ERROR_PARENT("iERROR_PARENT_CMO_MPP3_Optimizer");
uint32_t CMO_MPP3::iERROR_CODE_CMO_MPP3_GENOTYPE_LEN_BELOW_0 = CError::iADD_ERROR("iERROR_CODE_CMO_MPP3_GENOTYPE_LEN_BELOW_0");


CMO_MPP3::CMO_MPP3(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)
	: CBinaryMultiObjectiveOptimizer(pcProblem, pcLog, iRandomSeed)
	//: CBinaryOptimizer(pcProblem, pcLog, iRandomSeed)
{
	//pc_problem = (CBinaryMultiObjectiveProblem *) pcProblem;

};//CMO_MPP3::CMO_MPP3(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)


CMO_MPP3::CMO_MPP3(CMO_MPP3 *pcOther) : CBinaryMultiObjectiveOptimizer(pcOther)//CBinaryOptimizer(pcOther)
{
	::MessageBox(NULL, "No implementation: CMO_MPP3::CMO_MPP3(CMO_MPP3 *pcOther) : CBinaryMultiObjectiveOptimizer(pcOther)//CBinaryOptimizer(pcOther)", "Implementation missing", MB_OK);
};//CMO_MPP3::CMO_MPP3(CMO_MPP3 *pcOther) : CBinaryMultiObjectiveOptimizer(pcOther)//CBinaryOptimizer(pcOther)


CMO_MPP3::~CMO_MPP3()
{
	delete  pc_clear_p3;
	for (int ii = 0; ii < v_p3.size(); ii++)
		delete  v_p3.at(ii);
}//CMO_MPP3::~CMO_MPP3()

CError CMO_MPP3::eConfigure(istream *psSettings)
{
	CError  c_err(iERROR_PARENT_CMO_MPP3_Optimizer);

	c_err = CBinaryOptimizer::eConfigureNSGA2(psSettings);

	pc_clear_p3 = new CP3(pc_problem, pc_log, i_random_seed);
	c_err = pc_clear_p3->eConfigure(psSettings);
	
	return(c_err);
}//virtual CError CMO_MPP3::eConfigure(istream *psSettings)


void CMO_MPP3::vInitialize()
{
	c_optimizer_timer.vSetStartNow();
	CBinaryOptimizer::vInitialize();

	CError  c_err(iERROR_PARENT_CMO_MPP3_Optimizer);
	i_templ_length = pc_problem->pcGetEvaluation()->iGetNumberOfElements();

	if (i_templ_length <= 0)
	{
		c_err.vSetError(CMO_MPP3::iERROR_CODE_CMO_MPP3_GENOTYPE_LEN_BELOW_0);
		return;
	}//if  (i_templ_length  <=  0)


	pc_log->vPrintLine("Initializing...", true);

	pc_clear_p3->vInitialize();

	i_pop_p3_number = 2;

	for (int ii = 0; ii < i_pop_p3_number; ii++)
	{
		v_p3.push_back((CP3 *)pc_clear_p3->pcCopy());
		v_p3.at(ii)->vInitialize();

		v_improved_pf_tool.push_back(0);
	}//for (int ii = 0; ii < i_pop_p3_number; ii++)
	

	pc_log->vPrintLine("DONE...", true);
	
	c_time_counter.vSetStartNow();
};//void CMO_MPP3::vInitialize(time_t tStartTime);




bool CMO_MPP3::bRunIteration(uint32_t iIterationNumber)
{
	CString  s_buf;

	double  d_hyper_before, d_hyper_after;

	CBinaryMultiObjectiveProblem  *pc_multi_problem;
	pc_multi_problem = (CBinaryMultiObjectiveProblem *)pc_problem->pcGetEvaluation();
	bool b_hyper_improved;

	b_hyper_improved = false;
	for (int i_p3 = 0; i_p3 < v_p3.size(); i_p3++)
	{
		d_hyper_before = pc_multi_problem->dPFQualityHyperVolume();
		v_p3.at(i_p3)->bRunIteration(iIterationNumber);
		d_hyper_after = pc_multi_problem->dPFQualityHyperVolume();

		if (d_hyper_before > d_hyper_after)
		{
			v_improved_pf_tool.at(i_p3) = 1;
			b_hyper_improved = true;
		}//if (d_hyper_before > d_hyper_after)
		else
			v_improved_pf_tool.at(i_p3) = 0;
	}//for (int ii = 0; ii < v_p3.size(); ii++)


	bool b_updated = b_update_best_individual(iIterationNumber);


	if (b_hyper_improved == true)
	{
		int  i_pop_offset = -1;
		for (int i_p3 = 0; i_p3 < v_p3.size(); i_p3++)
		{
			i_pop_offset++;
			if (v_improved_pf_tool.at(i_p3) == 0)
			{
				CString s_log;
				s_log.Format("remove pop: %d  iteration: %d; time: [%.2lf];", i_pop_offset, iIterationNumber, c_time_counter.dGetTimePassed());
				pc_log->vPrintLine(s_log, true);

				delete  v_p3.at(i_p3);
				v_p3.at(i_p3) = (CP3 *)pc_clear_p3->pcCopy();
				v_p3.at(i_p3)->vInitialize();

				//v_improved_pf_tool.erase(v_improved_pf_tool.begin() + i_p3);
				//i_p3--;
			}//if (v_improved_pf_tool.at(i_pop_offset) == 0)
		}//for (int i_p3 = 0; i_p3 < v_p3.size(); i_p3++)


		/*CP3  *pc_new_p3;
		while (v_p3.size() < i_pop_p3_number)
		{
			pc_new_p3 = (CP3 *) pc_clear_p3->pcCopy();
			pc_new_p3->vInitialize(tStartTime);
			v_p3.push_back(pc_new_p3);
		}//while (v_p3.size() < i_pop_p3_number)*/
	}//if (b_hyper_improved == true)
	/*else
	{
		CP3  *pc_new_p3;
		pc_new_p3 = (CP3 *) pc_clear_p3->pcCopy();
		pc_new_p3->vInitialize(tStartTime);
		v_p3.push_back(pc_new_p3);
		v_improved_pf_tool.push_back(0);
	}//else  if (b_hyper_improved == true)*/

	CString  s_improved;
	if (b_hyper_improved == true)
		s_improved = "IMPROVED";
	else
		s_improved = "NOT improved";

	CString s_log;
	s_log.Format("iteration: %d; %s; pop number:%d(%d);  time: [%.2lf];", iIterationNumber, s_improved, v_p3.size(), v_improved_pf_tool.size(), c_time_counter.dGetTimePassed());

	pc_log->vPrintLine(s_log, true);
	pc_log->vPrintEmptyLine(true);

	return b_updated;

	//return(bRunIteration_dummy(iIterationNumber, tStartTime));
};//bool CMO_MPP3::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)




bool CMO_MPP3::b_update_best_individual(uint32_t iIterationNumber)
{
	CIndividual<CBinaryCoding, CBinaryCoding> *pc_optimizer_best_individual;

	bool b_updated = false;


	for (uint8_t i = 0; i < (uint8_t)v_p3.size(); i++)
	{
		pc_optimizer_best_individual = v_p3.at(i)->pcGetBestIndividual();

		if (pc_optimizer_best_individual)
		{
			//if (CBinaryOptimizer::b_update_best_individual(iIterationNumber, tStartTime, pc_optimizer_best_individual->pcGetGenotype()->piGetBits(), 0))
			if (CBinaryOptimizer::b_update_best_individual(iIterationNumber, pc_optimizer_best_individual))
			{
				b_updated = true;
			}//if (b_update_best_individual(iIterationNumber, tStartTime, pc_optimizer_best_individual))
		}//if (pc_optimizer_best_individual)
	}//for (uint8_t i = 0; i < (uint8_t)v_populations.size(); i++)

	if (b_updated)
	{
		d_best_time = c_optimizer_timer.dGetTimePassed();
		i_best_ffe = pc_problem->pcGetEvaluation()->iGetFFE();

		CString s_log;
		s_log.Format("new best found: %f", pc_optimizer_best_individual->dGetFitnessValue());

		pc_log->vPrintEmptyLine(true);
		pc_log->vPrintLine(s_log, true);
		pc_log->vPrintEmptyLine(true);
		pc_log->vPrintLine(pc_optimizer_best_individual->pcGetFenotype()->sToString(), false);
		pc_log->vPrintEmptyLine(false);
	}//if (b_updated)*/

	return b_updated;
}//bool CMultiOptimizer<TGenotype, TFenotype>::b_update_best_individual(uint32_t iIterationNumber, time_t tStartTime)


bool CMO_MPP3::bRunIteration_dummy(uint32_t iIterationNumber)
{
	CString  s_buf;
	double  d_time_passed;

	c_time_counter.bGetTimePassed(&d_time_passed);


	CBinaryCoding c_genotype(i_templ_length);

	for (int ii = 0; ii < i_templ_length; ii++)
		c_genotype.piGetBits()[ii] = RandUtils::iRandNumber(0, 1);


	CBinaryMultiObjectiveProblem  *pc_multi_problem;
	pc_multi_problem = (CBinaryMultiObjectiveProblem *)pc_problem->pcGetEvaluation();


	double  d_fit;
	d_fit = pc_multi_problem->dEvaluate(&c_genotype);


	//s_buf.Format("iteration: %d  pop: %d; GenSize:%d PFsize:%d HyperVolume: %.8lf InvGenDist: %.8lf [time:%.2lf]", iIterationNumber, v_population.size(), v_non_dominated_pfs.at(0).at(0)->pc_genotype->iGetNumberOfBits(), (int)dPFQualityPointNum(), dPFQualityHyperVolume(), dPFQualityInverseGenerationalDistance(), d_time_passed);
	s_buf.Format("iteration: %d  PFsize:%d HyperVolume: %.8lf InvGenDist: %.8lf [time:%.2lf]", iIterationNumber, (int)dPFQualityPointNum(), dPFQualityHyperVolume(), dPFQualityInverseGenerationalDistance(), d_time_passed);
	pc_log->vPrintLine(s_buf, true);

	CBinaryOptimizer::b_update_best_individual(iIterationNumber, c_genotype.piGetBits(), d_fit);

	return(true);
};//bool CMO_MPP3::bRunIteration_dummy(uint32_t iIterationNumber, time_t tStartTime)

