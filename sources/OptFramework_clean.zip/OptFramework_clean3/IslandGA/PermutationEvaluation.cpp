#include "PermutationEvaluation.h"

#include "PointerUtils.h"
#include "StringCommandParam.h"
#include "UIntCommandParam.h"

#include <algorithm>
#include <atlstr.h>
#include <fstream>
#include <string>


CPermutationCoding * CPermutationEvaluation::pcCreateSampleFenotype()
{
	return new CPermutationCoding(i_number_of_elements);
}//CPermutationCoding * CPermutationEvaluation::pcCreateSampleFenotype()


CError CPermutationSampleEvaluation::eConfigure(istream *psSettings)
{
	CError c_error = CPermutationEvaluation::eConfigure(psSettings);

	if (!c_error)
	{
		CUIntCommandParam p_number_of_elements(EVALUATION_ARGUMENT_NUMBER_OF_ELEMENTS, 1, UINT16_MAX);
		i_number_of_elements = p_number_of_elements.iGetValue(psSettings, &c_error);

		if (!c_error)
		{
			d_max_value = i_number_of_elements - 1;
		}//if (!c_error)
	}//if (!c_error)

	return c_error;
}//CError CPermutationSampleEvaluation::eConfigure(istream *psSettings)

double CPermutationSampleEvaluation::d_evaluate(CPermutationCoding *pcFenotype, uint16_t iShift)
{
	double d_function_value = 0;

	int32_t *pi_previous_element = nullptr;
	uint16_t i_number_of_found_elements = 0;

	int32_t i_element;

	for (uint16_t i = 0; i < pcFenotype->iGetSize() && i_number_of_found_elements < i_number_of_elements; i++)
	{
		i_element = *(pcFenotype->piGetPermutation() + i);

		if (i_element >= iShift && i_element < i_number_of_elements + iShift)
		{
			if (pi_previous_element)
			{
				if (i_element > *pi_previous_element)
				{
					d_function_value++;
				}//if (i_element > *pi_previous_element)
			}//if (pi_previous_element)

			pi_previous_element = pcFenotype->piGetPermutation() + i;
			i_number_of_found_elements++;
		}//if (i_element > iShift && i_element <= i_number_of_elements + iShift)
	}//for (uint16_t i = 0; i < pcFenotype->iGetSize() && i_number_of_found_elements < i_number_of_elements; i++)

	return d_function_value;
}//double CPermutationSampleEvaluation::d_evaluate(CPermutationCoding *pcFenotype, uint16_t iShift)


CPermutationTaillardFlowshopBasedEvaluation::CPermutationTaillardFlowshopBasedEvaluation()
{
	ppd_processing_times = nullptr;
	ppd_calculations = nullptr;
}//CPermutationTaillardFlowshopBasedEvaluation::CPermutationTaillardFlowshopBasedEvaluation()

CPermutationTaillardFlowshopBasedEvaluation::~CPermutationTaillardFlowshopBasedEvaluation()
{
	v_clear();
}//CPermutationTaillardFlowshopBasedEvaluation::~CPermutationTaillardFlowshopBasedEvaluation()

CError CPermutationTaillardFlowshopBasedEvaluation::eConfigure(istream *psSettings)
{
	v_clear();

	CError c_error = CPermutationEvaluation::eConfigure(psSettings);

	uint16_t i_number_of_jobs = 0;
	uint8_t i_instance_index = 0;

	if (!c_error)
	{
		CUIntCommandParam p_number_of_jobs(EVALUATION_PERMUTATION_TAILLARD_FLOWSHOP_ARGUMENT_NUMBER_OF_JOBS, 1, UINT16_MAX);
		i_number_of_jobs = (uint16_t)p_number_of_jobs.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		CUIntCommandParam p_number_of_machines(EVALUATION_PERMUTATION_TAILLARD_FLOWSHOP_ARGUMENT_NUMBER_OF_MACHINES, 1, UINT32_MAX);
		i_number_of_machines = p_number_of_machines.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		CUIntCommandParam p_instance_index(EVALUATION_PERMUTATION_TAILLARD_FLOWSHOP_ARGUMENT_INSTANCE_INDEX, 0, 9);
		i_instance_index = p_instance_index.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		CString s_definition_path;
		s_definition_path.Format("tai%d_%d.txt", i_number_of_jobs, i_number_of_machines);

		ifstream f_definition(s_definition_path);

		if (f_definition.good())
		{
			c_error = e_load(&f_definition, i_number_of_jobs, i_number_of_machines, i_instance_index);

			if (!c_error)
			{
				i_number_of_elements = i_number_of_jobs;
				d_max_value = 0.0;
			}//if (!c_error)
		}//if (f_definition.good())
		else
		{
			c_error.vSetError(CError::iERROR_CODE_SYSTEM_WRONG_FILE_PATH, s_definition_path);
		}//if (f_definition.good())

		f_definition.close();
	}//if (!c_error)

	return c_error;
}//CError CPermutationTaillardFlowshopBasedEvaluation::eConfigure(istream *psSettings)

void CPermutationTaillardFlowshopBasedEvaluation::v_clear()
{
	v_clear_processing_times();
	v_clear_calculations();
}//void CPermutationTaillardFlowshopBasedEvaluation::v_clear()

void CPermutationTaillardFlowshopBasedEvaluation::v_clear_processing_times()
{
	PointerUtils::vDelete(ppd_processing_times, i_number_of_elements);
	ppd_processing_times = nullptr;
}//void CPermutationTaillardFlowshopBasedEvaluation::v_clear_processing_times()

void CPermutationTaillardFlowshopBasedEvaluation::v_create_processing_times(uint16_t iNumberOfJobs, uint32_t iNumberOfMachines)
{
	ppd_processing_times = new double*[iNumberOfJobs];

	for (uint16_t i = 0; i < iNumberOfJobs; i++)
	{
		*(ppd_processing_times + i) = new double[iNumberOfMachines];
	}//for (uint16_t i = 0; i < iNumberOfJobs; i++)
}//void CPermutationTaillardFlowshopBasedEvaluation::v_create_processing_times(uint16_t iNumberOfJobs, uint32_t iNumberOfMachines)

void CPermutationTaillardFlowshopBasedEvaluation::v_clear_calculations()
{
	PointerUtils::vDelete(ppd_calculations, i_number_of_elements);
}//void CPermutationTaillardFlowshopBasedEvaluation::v_clear_calculations()

void CPermutationTaillardFlowshopBasedEvaluation::v_create_calculations(uint16_t iNumberOfJobs, uint32_t iNumberOfMachines)
{
	ppd_calculations = new double*[iNumberOfJobs];

	for (uint16_t i = 0; i < iNumberOfJobs; i++)
	{
		*(ppd_calculations + i) = new double[iNumberOfMachines];
	}//for (uint16_t i = 0; i < iNumberOfJobs; i++)
}//void CPermutationTaillardFlowshopBasedEvaluation::v_create_calculations(uint16_t iNumberOfJobs, uint32_t iNumberOfMachines)

CError CPermutationTaillardFlowshopBasedEvaluation::e_load(istream *psDefinition, uint16_t iNumberOfJobs, uint32_t iNumberOfMachines, uint8_t iInstanceIndex)
{
	CError c_error;

	v_clear();

	v_create_processing_times(iNumberOfJobs, iNumberOfMachines);
	v_create_calculations(iNumberOfJobs, iNumberOfMachines);

	string s_definition_line;

	for (uint8_t i = 0; i < iInstanceIndex && !c_error; i++)
	{
		for (int32_t j = 0; j < iNumberOfMachines + 3 && !c_error; j++)
		{
			getline(*psDefinition, s_definition_line);

			if (!(*psDefinition))
			{
				c_error.vSetError(CError::iERROR_CODE_SYSTEM_WRONG_FILE_FORMAT, "CPermutationTaillardFlowshopEvaluation::e_load");
			}//if (!(*psDefinition))
		}//for (int32_t j = 0; j < iNumberOfMachines + 3&& !c_error; j++)
	}//for (uint8_t i = 0; i < iInstanceIndex && !c_error; i++)

	for (uint8_t i = 0; i < 3 && !c_error; i++)
	{
		getline(*psDefinition, s_definition_line);

		if (!(*psDefinition))
		{
			c_error.vSetError(CError::iERROR_CODE_SYSTEM_WRONG_FILE_FORMAT, "CPermutationTaillardFlowshopEvaluation::e_load");
		}//if (!(*psDefinition))
	}//for (uint8_t i = 0; i < 3 && !c_error; i++)

	for (uint32_t i = 0; i < iNumberOfMachines && !c_error; i++)
	{
		for (int16_t j = 0; j < iNumberOfJobs && !c_error; j++)
		{
			(*psDefinition) >> *(*(ppd_processing_times + j) + i);

			if (!(*psDefinition))
			{
				c_error.vSetError(CError::iERROR_CODE_SYSTEM_WRONG_FILE_FORMAT, "CPermutationTaillardFlowshopEvaluation::e_load");
			}//if (!(*psDefinition))
		}//for (int16_t j = 0; j < iNumberOfJobs && !c_error; j++)
	}//for (uint32_t i = 0; i < iNumberOfMachines && !c_error; i++)

	return c_error;
}//CError CPermutationTaillardFlowshopBasedEvaluation::e_load(istream *psDefinition, uint16_t iNumberOfJobs, uint32_t iNumberOfMachines, uint8_t iInstanceIndex)


double CPermutationTaillardFlowshopEvaluation::d_evaluate(CPermutationCoding *pcFenotype, uint16_t iShift)
{
	uint16_t i_number_of_found_elements = 0;

	int32_t i_element, i_job;

	for (uint16_t i = 0; i < pcFenotype->iGetSize() && i_number_of_found_elements < i_number_of_elements; i++)
	{
		i_element = *(pcFenotype->piGetPermutation() + i);

		if (i_element >= iShift && i_element < i_number_of_elements + iShift)
		{
			i_job = i_element - iShift;

			if (i_number_of_found_elements == 0)
			{
				*(*(ppd_calculations + 0) + 0) = *(*(ppd_processing_times + i_job) + 0);

				for (uint32_t j = 1; j < i_number_of_machines; j++)
				{
					*(*(ppd_calculations + 0) + j) = *(*(ppd_calculations + 0) + j - 1) + *(*(ppd_processing_times + i_job) + j);
				}//for (uint32_t j = 1; j < i_number_of_machines; j++)
			}//if (i_number_of_found_elements == 0)
			else
			{
				*(*(ppd_calculations + i_number_of_found_elements) + 0) = 
					*(*(ppd_calculations + i_number_of_found_elements - 1) + 0) + *(*(ppd_processing_times + i_job) + 0);

				for (uint32_t j = 1; j < i_number_of_machines; j++)
				{
					*(*(ppd_calculations + i_number_of_found_elements) + j) = 
						max(*(*(ppd_calculations + i_number_of_found_elements - 1) + j), *(*(ppd_calculations + i_number_of_found_elements) + j - 1))
						+
						*(*(ppd_processing_times + i_job) + j);
				}//for (uint32_t j = 1; j < i_number_of_machines; j++)
			}//else if (i_number_of_found_elements == 0)

			i_number_of_found_elements++;
		}//if (i_element > iShift && i_element <= i_number_of_elements + iShift)
	}//for (uint16_t i = 0; i < pcFenotype->iGetSize() && i_number_of_found_elements < i_number_of_elements; i++)

	double d_value = 0;

	for (uint16_t i = 0; i < i_number_of_elements; i++)
	{
		d_value -= *(*(ppd_calculations + i) + i_number_of_machines - 1);
	}//for (uint16_t i = 0; i < i_number_of_elements; i++)

	return d_value;
}//double CPermutationTaillardFlowshopEvaluation::d_evaluate(CPermutationCoding *pcFenotype, uint16_t iShift)


CPermutationChainTaillardFlowshopEvaluation::CPermutationChainTaillardFlowshopEvaluation()
{
	pi_last_permutation = nullptr;
}//CPermutationChainTaillardFlowshopEvaluation::CPermutationChainTaillardFlowshopEvaluation()

CPermutationChainTaillardFlowshopEvaluation::~CPermutationChainTaillardFlowshopEvaluation()
{
	delete pi_last_permutation;
}//CPermutationChainTaillardFlowshopEvaluation::~CPermutationChainTaillardFlowshopEvaluation()

CError CPermutationChainTaillardFlowshopEvaluation::eConfigure(istream *psSettings)
{
	delete pi_last_permutation;

	CError c_error = CPermutationTaillardFlowshopBasedEvaluation::eConfigure(psSettings);

	if (!c_error)
	{
		if (i_number_of_elements % 2 != 0)
		{
			c_error.vSetError(CError::iERROR_CODE_SYSTEM_ARGUMENT_WRONG_VALUE, "number of elements must be divisble by 2");
		}//if (i_number_of_elements % 2 != 0)
	}//if (!c_error)

	if (!c_error)
	{
		v_create_last_permutation();
	}//if (!c_error)

	return c_error;
}//CError CPermutationChainTaillardFlowshopEvaluation::eConfigure(istream *psSettings)

double CPermutationChainTaillardFlowshopEvaluation::d_evaluate(CPermutationCoding *pcFenotype, uint16_t iShift)
{
	uint16_t i_number_of_found_elements_0 = 0;
	uint16_t i_number_of_found_elements_1 = 0;

	uint16_t i_mid = i_number_of_elements / 2;

	int32_t i_element, i_job;

	for (uint16_t i = 0; i < pcFenotype->iGetSize() && i_number_of_found_elements_0 + i_number_of_found_elements_1 < i_number_of_elements; i++)
	{
		i_element = *(pcFenotype->piGetPermutation() + i);

		if (i_element >= iShift && i_element < i_number_of_elements + iShift)
		{
			i_job = i_element - iShift;

			if (i_job < i_mid)
			{
				if (i_number_of_found_elements_0 == 0)
				{
					*(*(ppd_calculations + 0) + 0) = *(*(ppd_processing_times + i_job) + 0);

					for (uint32_t j = 1; j < i_number_of_machines; j++)
					{
						*(*(ppd_calculations + 0) + j) = *(*(ppd_calculations + 0) + j - 1) + *(*(ppd_processing_times + i_job) + j);
					}//for (uint32_t j = 1; j < i_number_of_machines; j++)
				}//if (i_number_of_found_elements_0 == 0)
				else
				{
					*(*(ppd_calculations + i_number_of_found_elements_0) + 0) =
						*(*(ppd_calculations + i_number_of_found_elements_0 - 1) + 0) + *(*(ppd_processing_times + i_job) + 0);

					for (uint32_t j = 1; j < i_number_of_machines; j++)
					{
						*(*(ppd_calculations + i_number_of_found_elements_0) + j) =
							max(*(*(ppd_calculations + i_number_of_found_elements_0 - 1) + j), *(*(ppd_calculations + i_number_of_found_elements_0) + j - 1))
							+
							*(*(ppd_processing_times + i_job) + j);
					}//for (uint32_t j = 1; j < i_number_of_machines; j++)
				}//else if (i_number_of_found_elements_0 == 0)

				i_number_of_found_elements_0++;
			}//if (i_job < i_mid)
			else
			{
				if (i_number_of_found_elements_1 == 0)
				{
					*(*(ppd_calculations + 0 + i_mid) + 0) = *(*(ppd_processing_times + i_job) + 0);

					for (uint32_t j = 1; j < i_number_of_machines; j++)
					{
						*(*(ppd_calculations + 0 + i_mid) + j) = *(*(ppd_calculations + 0 + i_mid) + j - 1) + *(*(ppd_processing_times + i_job) + j);
					}//for (uint32_t j = 1; j < i_number_of_machines; j++)
				}//if (i_number_of_found_elements_0 == 0)
				else
				{
					*(*(ppd_calculations + i_number_of_found_elements_1 + i_mid) + 0) =
						*(*(ppd_calculations + i_number_of_found_elements_1 + i_mid - 1) + 0) + *(*(ppd_processing_times + i_job) + 0);

					for (uint32_t j = 1; j < i_number_of_machines; j++)
					{
						*(*(ppd_calculations + i_number_of_found_elements_1 + i_mid) + j) =
							max(*(*(ppd_calculations + i_number_of_found_elements_1 + i_mid - 1) + j), *(*(ppd_calculations + i_number_of_found_elements_1 + i_mid) + j - 1))
							+
							*(*(ppd_processing_times + i_job) + j);
					}//for (uint32_t j = 1; j < i_number_of_machines; j++)
				}//else if (i_number_of_found_elements_0 == 0)

				i_number_of_found_elements_1++;
			}//else if (i_job < i_mid)
		}//if (i_element > iShift && i_element <= i_number_of_elements + iShift)
	}//for (uint16_t i = 0; i < pcFenotype->iGetSize() && i_number_of_found_elements_0 + i_number_of_found_elements_1 < i_number_of_elements; i++)

	sort(pi_last_permutation + 0, pi_last_permutation + i_number_of_elements, [&](int32_t iIndex0, int32_t iIndex1)
	{
		return *(*(ppd_calculations + iIndex0) + i_number_of_machines - 1) < *(*(ppd_calculations + iIndex1) + i_number_of_machines - 1);
	});//sort(pi_last_permutation + 0, pi_last_permutation + i_number_of_elements, [&](int32_t iIndex0, int32_t iIndex1)

	for (uint16_t i = 0; i < i_number_of_elements; i++)
	{
		*(*(ppd_calculations + i) + 0) = *(*(ppd_calculations + *(pi_last_permutation + i)) + i_number_of_machines - 1);
	}//for (uint16_t i = 0; i < i_number_of_elements; i++)

	*(*(ppd_calculations + 0) + 0) += *(*(ppd_processing_times + *(pi_last_permutation + 0)) + 0);

	for (uint32_t j = 1; j < i_number_of_machines; j++)
	{
		*(*(ppd_calculations + 0) + j) = *(*(ppd_calculations + 0) + j - 1) + *(*(ppd_processing_times + *(pi_last_permutation + 0)) + j);
	}//for (uint32_t j = 1; j < i_number_of_machines; j++)

	for (uint16_t i = 1; i < i_number_of_elements; i++)
	{
		i_job = *(pi_last_permutation + i);

		*(*(ppd_calculations + i) + 0) = *(*(ppd_calculations + i - 1) + 0) + *(*(ppd_processing_times + i_job) + 0);

		for (uint32_t j = 1; j < i_number_of_machines; j++)
		{
			*(*(ppd_calculations + i) + j) = max(*(*(ppd_calculations + i - 1) + j), *(*(ppd_calculations + i) + j - 1)) 
				+ *(*(ppd_processing_times + i_job) + j);
		}//for (uint32_t j = 1; j < i_number_of_machines; j++)
	}//for (uint16_t i = 1; i < i_number_of_elements; i++)

	double d_value = 0;

	for (uint16_t i = 0; i < i_number_of_elements; i++)
	{
		d_value -= *(*(ppd_calculations + i) + i_number_of_machines - 1);
	}//for (uint16_t i = 0; i < i_number_of_elements; i++)

	return d_value;
}//double CPermutationChainTaillardFlowshopEvaluation::d_evaluate(CPermutationCoding *pcFenotype, uint16_t iShift)

void CPermutationChainTaillardFlowshopEvaluation::v_create_last_permutation()
{
	pi_last_permutation = new int32_t[i_number_of_elements];

	for (int16_t i = 0; i < i_number_of_elements; i++)
	{
		*(pi_last_permutation + i) = i;
	}//for (int16_t i = 0; i < i_number_of_elements; i++)
}//void CPermutationChainTaillardFlowshopEvaluation::v_create_last_permutation()


CPermutationLinearOrderingProblemEvaluation::CPermutationLinearOrderingProblemEvaluation()
{
	ppd_coefficients = nullptr;
}//CPermutationLinearOrderingProblemEvaluation::CPermutationLinearOrderingProblemEvaluation()

CPermutationLinearOrderingProblemEvaluation::~CPermutationLinearOrderingProblemEvaluation()
{
	v_clear();
}//CPermutationLinearOrderingProblemEvaluation::~CPermutationLinearOrderingProblemEvaluation()

CError CPermutationLinearOrderingProblemEvaluation::eConfigure(istream *psSettings)
{
	v_clear();

	CError c_error = CPermutationEvaluation::eConfigure(psSettings);

	if (!c_error)
	{
		CFilePathCommandParam p_config_file_path(EVALUATION_ARGUMENT_CONFIG_FILE_PATH);
		CString s_config_file_path = p_config_file_path.sGetValue(psSettings, &c_error);

		if (!c_error)
		{
			ifstream f_config(s_config_file_path);

			f_config >> i_number_of_elements;

			ppd_coefficients = new double*[i_number_of_elements];

			for (uint16_t i = 0; i < i_number_of_elements; i++)
			{
				*(ppd_coefficients + i) = new double[i_number_of_elements];

				for (uint16_t j = 0; j < i_number_of_elements; j++)
				{
					f_config >> *(*(ppd_coefficients + i) + j);
				}//for (uint16_t j = 0; j < i_number_of_elements; j++)
			}//for (uint16_t i = 0; i < i_number_of_elements; i++)
		}//if (!c_error)
	}//if (!c_error)

	return c_error;
}//CError CPermutationLinearOrderingProblemEvaluation::eConfigure(istream *psSettings)

double CPermutationLinearOrderingProblemEvaluation::d_evaluate(CPermutationCoding *pcFenotype, uint16_t iShift)
{
	uint16_t i_number_of_found_elements = 0;

	int32_t i_element;

	uint16_t *pi_indexes = new uint16_t[i_number_of_elements];

	for (uint16_t i = 0; i < pcFenotype->iGetSize() && i_number_of_found_elements < i_number_of_elements; i++)
	{
		i_element = *(pcFenotype->piGetPermutation() + i);

		if (i_element >= iShift && i_element < i_number_of_elements + iShift)
		{
			*(pi_indexes + i_number_of_found_elements) = i_element - iShift;
			i_number_of_found_elements++;
		}//if (i_element >= iShift && i_element < i_number_of_elements + iShift)
	}//for (uint16_t i = 0; i < pcFenotype->iGetSize() && i_number_of_found_elements < i_number_of_elements; i++)

	double d_value = 0;

	for (uint16_t i = 0; i + 1 < i_number_of_elements; i++)
	{
		for (uint16_t j = i + 1; j < i_number_of_elements; j++)
		{
			d_value += *(*(ppd_coefficients + *(pi_indexes + i)) + *(pi_indexes + j));
		}//for (uint16_t j = i + 1; j < i_number_of_elements; j++)
	}//for (uint16_t i = 0; i + 1 < i_number_of_elements; i++)

	delete pi_indexes;

	return d_value;
}//double CPermutationLinearOrderingProblemEvaluation::d_evaluate(CPermutationCoding *pcFenotype, uint16_t iShift)

void CPermutationLinearOrderingProblemEvaluation::v_clear()
{
	PointerUtils::vDelete(ppd_coefficients, i_number_of_elements);
	ppd_coefficients = nullptr;
}//void CPermutationLinearOrderingProblemEvaluation::v_clear()


CPermutationRelativeOrderingEvaluation::CPermutationRelativeOrderingEvaluation()
{
	i_number_of_elements = 4;
	d_max_value = 4.0;
}//CPermutationRelativeOrderingEvaluation::CPermutationRelativeOrderingEvaluation()

double CPermutationRelativeOrderingEvaluation::d_evaluate(CPermutationCoding *pcFenotype, uint16_t iShift)
{
	uint16_t i_number_of_found_elements = 0;

	int32_t i_element;

	CString s_actual_fenotype;

	for (uint16_t i = 0; i < pcFenotype->iGetSize() && i_number_of_found_elements < i_number_of_elements; i++)
	{
		i_element = *(pcFenotype->piGetPermutation() + i);

		if (i_element >= iShift && i_element < i_number_of_elements + iShift)
		{
			s_actual_fenotype.AppendFormat("%d", i_element - iShift);
			i_number_of_found_elements++;
		}//if (i_element >= iShift && i_element < i_number_of_elements + iShift)
	}//for (uint16_t i = 0; i < pcFenotype->iGetSize() && i_number_of_found_elements < i_number_of_elements; i++)

	return m_possible_values.at(s_actual_fenotype);
}//double CPermutationRelativeOrderingEvaluation::d_evaluate(CPermutationCoding *pcFenotype, uint16_t iShift)

unordered_map<CString, double> CPermutationRelativeOrderingEvaluation::m_possible_values
{
	{ "0123", 4.0 },
	{ "0132", 1.1 },
	{ "0321", 1.1 },
	{ "0213", 1.1 },
	{ "2103", 1.1 },
	{ "3120", 1.1 },
	{ "1023", 1.1 },
	{ "0231", 1.2 },
	{ "0312", 1.2 },
	{ "3102", 1.2 },
	{ "2130", 1.2 },
	{ "3021", 1.2 },
	{ "1320", 1.2 },
	{ "2013", 1.2 },
	{ "1203", 1.2 },
	{ "1032", 2.4 },
	{ "3012", 2.1 },
	{ "2031", 2.2 },
	{ "2301", 2.2 },
	{ "3201", 2.4 },
	{ "1230", 1.5 },
	{ "2310", 3.2 },
	{ "1302", 2.4 },
	{ "3210", 2.4 }
};//unordered_map<CString, double> CPermutationRelativeOrderingEvaluation::m_possible_values


CPermutationAbsoluteOrderingEvaluation::CPermutationAbsoluteOrderingEvaluation()
{
	i_number_of_elements = 4;
	d_max_value = 4.0;
}//CPermutationAbsoluteOrderingEvaluation::CPermutationAbsoluteOrderingEvaluation()

double CPermutationAbsoluteOrderingEvaluation::d_evaluate(CPermutationCoding *pcFenotype, uint16_t iShift)
{
	uint16_t i_number_of_found_elements = 0;

	int32_t i_element;
	int32_t i_previous_element;

	CString s_actual_fenotype;

	bool b_order_correct = true;
	uint16_t i_correctly_placed_values = 0;

	for (uint16_t i = 0; i < pcFenotype->iGetSize() && i_number_of_found_elements < i_number_of_elements; i++)
	{
		i_element = *(pcFenotype->piGetPermutation() + i);

		if (i_element >= iShift && i_element < i_number_of_elements + iShift)
		{
			s_actual_fenotype.AppendFormat("%d", i_element - iShift + i_element - i);
			i_number_of_found_elements++;

			b_order_correct &= i_element > i_previous_element;

			if (i_element == (int32_t)i)
			{
				i_correctly_placed_values++;
			}//if (i_element == (int32_t)i)

			i_previous_element = i_element;
		}//if (i_element >= iShift && i_element < i_number_of_elements + iShift)
	}//for (uint16_t i = 0; i < pcFenotype->iGetSize() && i_number_of_found_elements < i_number_of_elements; i++)

	unordered_map<CString, double>::iterator it_value = m_possible_values.find(s_actual_fenotype);

	double d_value = 0.0;

	if (it_value != m_possible_values.end())
	{
		d_value = it_value->second;
	}//if (it_value != m_possible_values.end())
	else
	{
		if (b_order_correct)
		{
			d_value = i_correctly_placed_values / 2.0;
		}//if (b_order_correct)
	}//else if (it_value != m_possible_values.end())

	return d_value;
}//double CPermutationAbsoluteOrderingEvaluation::d_evaluate(CPermutationCoding *pcFenotype, uint16_t iShift)

unordered_map<CString, double> CPermutationAbsoluteOrderingEvaluation::m_possible_values
{
	{ "0123", 4.0 },
	{ "0132", 1.8 },
	{ "0321", 1.8 },
	{ "0213", 1.8 },
	{ "2103", 1.8 },
	{ "3120", 1.8 },
	{ "1023", 1.8 },
	{ "0231", 2.0 },
	{ "0312", 2.0 },
	{ "3102", 2.0 },
	{ "2130", 2.0 },
	{ "3021", 2.0 },
	{ "1320", 2.0 },
	{ "2013", 2.0 },
	{ "1203", 2.0 },
	{ "1032", 2.6 },
	{ "3012", 2.6 },
	{ "2031", 2.6 },
	{ "2301", 2.6 },
	{ "3201", 2.6 },
	{ "1230", 2.6 },
	{ "2310", 2.6 },
	{ "1302", 2.6 },
	{ "3210", 2.6 }
};//unordered_map<CString, double> CPermutationAbsoluteOrderingEvaluation::m_possible_values