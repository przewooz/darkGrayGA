#ifndef INTEGRAL_SENSOR_CHANGE_DETECTOR_H
#define INTEGRAL_SENSOR_CHANGE_DETECTOR_H

#define INTEGRAL_SENSOR_CHANGE_DETECTOR_ARGUMENT_NUMBER_OF_INTEGRAL_SAMPLES "number_of_integral_samples"
#define INTEGRAL_SENSOR_CHANGE_DETECTOR_ARGUMENT_INTEGRAL_WIDTH "integral_width"
#define INTEGRAL_SENSOR_CHANGE_DETECTOR_ARGUMENT_INTEGRAL_HEIGHT "integral_height"
#define INTEGRAL_SENSOR_CHANGE_DETECTOR_ARGUMENT_INTEGRAL_EPSILON "integral_epsilon"

#include "Error.h"
#include "Log.h"
#include "Problem.h"
#include "RealCoding.h"
#include "SensorChangeDetector.h"

#include <cstdint>
#include <istream>

using namespace std;


namespace ChangeDetector
{
	class CIntegralSensorChangeDetector : public CSensorChangeDetector<CRealCoding, CRealCoding>
	{
	public:
		CIntegralSensorChangeDetector(CProblem<CRealCoding, CRealCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed);

		virtual ~CIntegralSensorChangeDetector();

		virtual CError eConfigure(istream *psSettings);

		virtual void vInitialize();

	protected:
		virtual bool b_detect_change();

		void v_clear_integral_values();

	private:
		double d_calculate_integral(CIndividual<CRealCoding, CRealCoding> *pcSensor);

		uint32_t i_number_of_integral_samples;
		double d_integral_width;
		double d_integral_height;
		double d_integral_epsilon;

		double *pd_integral_values;
	};//class CIntegralSensorChangeDetector : public CSensorChangeDetector<CRealCoding, CRealCoding>
}//namespace ChangeDetector

#endif//INTEGRAL_SENSOR_CHANGE_DETECTOR_H