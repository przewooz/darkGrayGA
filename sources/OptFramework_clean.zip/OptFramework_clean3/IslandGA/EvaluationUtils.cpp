#include "EvaluationUtils.h"

#include "BinaryCoding.h"
#include "BinaryEvaluation.h"
#include "BinaryEvaluationMultiObjective.h"
#include "EnumCommandParam.h"
#include "PermutationCoding.h"
#include "PermutationEvaluation.h"
#include "RealCoding.h"
#include "RealEvaluation.h"
#include "StringUtils.h"

#include <atlstr.h>
#include <unordered_map>
#include <utility>

template <class TFenotype>
CEvaluation<TFenotype> * EvaluationUtils::pcGetEvaluation(istream *psSettings, CError *pcError, string sRunId)
{
	CEvaluation<TFenotype> *pc_evaluation = nullptr;

	size_t i_fenotype_type_hash_code = typeid(TFenotype).hash_code();

	unordered_map<CString, EEvaluationType> m_evaluation_types;

	m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_CONCATENATION, EVALUATION_CONCATENATION));

	if (i_fenotype_type_hash_code == typeid(CBinaryCoding).hash_code())
	{
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_BINARY_CYCLIC_FENOTYPE, EVALUATION_BINARY_CYCLIC_FENOTYPE));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_BINARY_DECEPTIVE, EVALUATION_BINARY_DECEPTIVE));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_BINARY_DECEPTIVE_CONCATENATION, EVALUATION_BINARY_DECEPTIVE_CONCATENATION));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_BINARY_KNAPSACK, EVALUATION_BINARY_KNAPSACK));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_BINARY_MAX_SAT, EVALUATION_BINARY_MAX_SAT));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_BINARY_DECEPTIVE_STEP_TRAP, EVALUATION_BINARY_DECEPTIVE_STEP_TRAP));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_BINARY_NEAREST_NEIGHBOR_NK, EVALUATION_BINARY_NEAREST_NEIGHBOR_NK));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_BINARY_ISING_SPIN_GLASS, EVALUATION_BINARY_ISING_SPIN_GLASS));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_BINARY_MAX_3_SAT, EVALUATION_BINARY_MAX_3_SAT));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_BINARY_DISCRETIZED_RASTRIGIN, EVALUATION_BINARY_DISCRETIZED_RASTRIGIN));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_BINARY_DISCRETIZED_ROSENBROCK, EVALUATION_BINARY_DISCRETIZED_ROSENBROCK));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_BINARY_HIFF, EVALUATION_BINARY_HIFF));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_BINARY_CYCLIC_TRAP, EVALUATION_BINARY_CYCLIC_TRAP));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_BINARY_LEADING_1, EVALUATION_BINARY_LEADING_1));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_BINARY_JUMP_FUNC, EVALUATION_BINARY_JUMP_FUNC));

		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_BINARY_MULTI_REVERSING, EVALUATION_BINARY_MULTI_REVERSING));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_BINARY_MULTI_MAX_CUT_MOGOMEA, EVALUATION_BINARY_MULTI_MAX_CUT_MOGOMEA));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_BINARY_MULTI_KNAPSACK_MOGOMEA, EVALUATION_BINARY_MULTI_KNAPSACK_MOGOMEA));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_BINARY_MULTI_PAINTS, EVALUATION_BINARY_MULTI_PAINTS));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_BINARY_UNCAPACITATED_WAREHOUSE, EVALUATION_BINARY_UNCAPACITATED_WAREHOUSE));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_BINARY_TD_MK_LANDSCAPES, EVALUATION_BINARY_TD_MK_LANDSCAPES));
	}//if (i_fenotype_type_hash_code == typeid(CBinaryCoding).hash_code())
	else if (i_fenotype_type_hash_code == typeid(CRealCoding).hash_code())
	{
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_REAL_CYCLIC_FENOTYPE, EVALUATION_REAL_CYCLIC_FENOTYPE));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_REAL_IMAGE_REGISTRATION, EVALUATION_REAL_IMAGE_REGISTRATION));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_REAL_PEAKS, EVALUATION_REAL_PEAKS));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_REAL_CEC2013, EVALUATION_REAL_CEC2013));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_REAL_CEC2013_LSGO, EVALUATION_REAL_CEC2013_LSGO));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_REAL_CEC2014, EVALUATION_REAL_CEC2014));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_REAL_MAX, EVALUATION_REAL_MAX));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_REAL_F5, EVALUATION_REAL_F5));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_REAL_DECEPTIVE_TRAP, EVALUATION_REAL_DECEPTIVE_TRAP));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_REAL_DECEPTIVE_STEP_TRAP, EVALUATION_REAL_DECEPTIVE_STEP_TRAP));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_REAL_DOUBLE_DECEPTIVE, EVALUATION_REAL_DOUBLE_DECEPTIVE));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_REAL_SIN, EVALUATION_REAL_SIN));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_REAL_COS, EVALUATION_REAL_COS));
	}//else if (i_fenotype_type_hash_code == typeid(CRealCoding).hash_code())
	else if (i_fenotype_type_hash_code == typeid(CPermutationCoding).hash_code())
	{
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_PERMUTATION_SAMPLE, EVALUATION_PERMUTATION_SAMPLE));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_PERMUTATION_TAILARD_FLOWSHOP, EVALUATION_PERMUTATION_TAILARD_FLOWSHOP));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_PERMUTATION_CHAIN_TAILARD_FLOWSHOP, EVALUATION_PERMUTATION_CHAIN_TAILARD_FLOWSHOP));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_PERMUTATION_LINEAR_ORDERING_PROBLEM, EVALUATION_PERMUTATION_LINEAR_ORDERING_PROBLEM));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_PERMUTATION_RELATIVE_ORDERING, EVALUATION_PERMUTATION_RELATIVE_ORDERING));
		m_evaluation_types.insert(pair<const CString, EEvaluationType>(EVALUATION_ARGUMENT_TYPE_PERMUTATION_ABSOLUTE_ORDERING, EVALUATION_PERMUTATION_ABSOLUTE_ORDERING));
	}//else if (i_fenotype_type_hash_code == typeid(CPermutationCoding).hash_code())

	CEnumCommandParam<EEvaluationType> p_type(EVALUATION_ARGUMENT_TYPE, &m_evaluation_types);
	EEvaluationType e_type = p_type.eGetValue(psSettings, pcError);

	if (!*pcError)
	{
		switch (e_type)
		{
			case EVALUATION_CONCATENATION:
			{
				pc_evaluation = new CConcatenationEvaluation<TFenotype>();
				break;
			}//case EVALUATION_CONCATENATION
			case EVALUATION_BINARY_CYCLIC_FENOTYPE:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CBinaryCyclicFenotypeEvaluation();
				break;
			}//case EVALUATION_BINARY_CYCLIC_FENOTYPE
			case EVALUATION_BINARY_DECEPTIVE:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CBinaryDeceptiveEvaluation();
				break;
			}//case EVALUATION_BINARY_DECEPTIVE
			case EVALUATION_BINARY_DECEPTIVE_CONCATENATION:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CBinaryDeceptiveConcatenationEvaluation();
				break;
			}//case EVALUATION_BINARY_DECEPTIVE_CONCATENATION
			case EVALUATION_BINARY_KNAPSACK:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CBinaryKnapsackEvaluation();
				break;
			}//case EVALUATION_BINARY_KNAPSACK
			case EVALUATION_BINARY_MAX_SAT:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CBinaryMaxSatEvaluation();
				break;
			}//case EVALUATION_BINARY_MAX_SAT
			case EVALUATION_BINARY_DECEPTIVE_STEP_TRAP:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CBinaryDeceptiveStepTrapEvaluation();
				break;
			}//case EVALUATION_BINARY_DECEPTIVE_STEP_TRAP
			case EVALUATION_BINARY_NEAREST_NEIGHBOR_NK:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CBinaryNearestNeighborNKEvaluation();
				break;
			}//case EVALUATION_BINARY_NEAREST_NEIGHBOR_NK
			case EVALUATION_BINARY_ISING_SPIN_GLASS:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CBinaryIsingSpinGlassEvaluation();
				break;
			}//case EVALUATION_BINARY_ISING_SPIN_GLASS
			case EVALUATION_BINARY_MAX_3_SAT:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CBinaryMax3SatEvaluation();
				break;
			}//case EVALUATION_BINARY_MAX_3_SAT
			case EVALUATION_BINARY_DISCRETIZED_RASTRIGIN:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CBinaryDiscretizedRastriginEvaluation();
				break;
			}//case EVALUATION_BINARY_DISCRETIZED_RASTRIGIN
			case EVALUATION_BINARY_DISCRETIZED_ROSENBROCK:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CBinaryDiscretizedRosenbrockEvaluation();
				break;
			}//case EVALUATION_BINARY_DISCRETIZED_ROSENBROCK
			case EVALUATION_BINARY_HIFF:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CBinaryHIFFEvaluation();
				break;
			}//case EVALUATION_BINARY_HIFF
			case EVALUATION_BINARY_CYCLIC_TRAP:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CBinaryCyclicTrapEvaluation();
				break;
			}//case EVALUATION_BINARY_CYCLIC_TRAP
			case EVALUATION_BINARY_LEADING_1:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CBinaryLeading1();
				break;
			}//case EVALUATION_BINARY_MULTI_PAINTS
			case EVALUATION_BINARY_JUMP_FUNC:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CBinaryJumpFunc();
				break;
			}//case EVALUATION_BINARY_JUMP_FUNC

			case EVALUATION_BINARY_MULTI_REVERSING:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CBinaryMultiReversing();
				break;
			}//case EVALUATION_BINARY_MULTI_REVERSING
			case EVALUATION_BINARY_MULTI_MAX_CUT_MOGOMEA:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CBinaryMultiMaxcutMoGomea();
				break;
			}//case EVALUATION_BINARY_MULTI_MAX_CUT_MOGOMEA:

			case EVALUATION_BINARY_MULTI_KNAPSACK_MOGOMEA:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CBinaryMultiKnapsackMoGomea();
				break;
			}//case EVALUATION_BINARY_MULTI_KNAPSACK_MOGOMEA:

			case EVALUATION_BINARY_MULTI_PAINTS:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CBinaryMultiPaints();
				break;
			}//case EVALUATION_BINARY_MULTI_PAINTS

			case EVALUATION_BINARY_UNCAPACITATED_WAREHOUSE:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CBinaryUncapacitatedWarehouseLocationEvaluation();
				break;
			}//case EVALUATION_BINARY_UNCAPACITATED_WAREHOUSE

			case EVALUATION_BINARY_TD_MK_LANDSCAPES:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CBinaryTDMkLandscapesEvaluation(sRunId);
				break;
			}//case EVALUATION_BINARY_TD_MK_LANDSCAPES


			case EVALUATION_REAL_CYCLIC_FENOTYPE:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CRealCyclicFenotypeEvaluation();
				break;
			}//case EVALUATION_REAL_CYCLIC_FENOTYPE
			case EVALUATION_REAL_IMAGE_REGISTRATION:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CRealImageRegistrationEvaluation();
				break;
			}//case EVALUATION_REAL_IMAGE_REGISTRATION
			case EVALUATION_REAL_PEAKS:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CRealPeaksEvaluation();
				break;
			}//case EVALUATION_REAL_PEAKS
			case EVALUATION_REAL_CEC2013:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CRealCEC2013Evaluation();
				break;
			}//case EVALUATION_REAL_CEC2013
			case EVALUATION_REAL_CEC2014:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CRealCEC2014Evaluation();
				break;
			}//case EVALUATION_REAL_CEC2014
			case EVALUATION_REAL_MAX:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CRealMaxEvaluation();
				break;
			}//case EVALUATION_REAL_MAX
			case EVALUATION_REAL_F5:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CRealF5Evaluation();
				break;
			}//case EVALUATION_REAL_F5
			case EVALUATION_REAL_DECEPTIVE_TRAP:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CRealDeceptiveTrapEvaluation();
				break;
			}//case EVALUATION_REAL_DECEPTIVE_TRAP
			case EVALUATION_REAL_DECEPTIVE_STEP_TRAP:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CRealDeceptiveStepTrapEvaluation();
				break;
			}//case EVALUATION_REAL_DECEPTIVE_STEP_TRAP
			case EVALUATION_REAL_DOUBLE_DECEPTIVE:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CRealDoubleDeceptiveEvaluation();
				break;
			}//case EVALUATION_REAL_DOUBLE_DECEPTIVE
			case EVALUATION_REAL_SIN:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CRealSinEvaluation();
				break;
			}//case EVALUATION_REAL_SIN
			case EVALUATION_REAL_COS:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CRealCosEvaluation();
				break;
			}//case EVALUATION_REAL_COS
			case EVALUATION_PERMUTATION_SAMPLE:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CPermutationSampleEvaluation();
				break;
			}//case EVALUATION_PERMUTATION_SAMPLE
			case EVALUATION_PERMUTATION_TAILARD_FLOWSHOP:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CPermutationTaillardFlowshopEvaluation();
				break;
			}//case EVALUATION_PERMUTATION_TAILARD_FLOWSHOP
			case EVALUATION_PERMUTATION_CHAIN_TAILARD_FLOWSHOP:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CPermutationChainTaillardFlowshopEvaluation();
				break;
			}//case EVALUATION_PERMUTATION_CHAIN_TAILARD_FLOWSHOP
			case EVALUATION_PERMUTATION_LINEAR_ORDERING_PROBLEM:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CPermutationLinearOrderingProblemEvaluation();
				break;
			}//case EVALUATION_PERMUTATION_LINEAR_ORDERING_PROBLEM
			case EVALUATION_PERMUTATION_RELATIVE_ORDERING:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CPermutationRelativeOrderingEvaluation();
				break;
			}//case EVALUATION_PERMUTATION_RELATIVE_ORDERING
			case EVALUATION_PERMUTATION_ABSOLUTE_ORDERING:
			{
				pc_evaluation = (CEvaluation<TFenotype>*)new CPermutationAbsoluteOrderingEvaluation();
				break;
			}//case EVALUATION_PERMUTATION_ABSOLUTE_ORDERING
			default:
			{
				pcError->vSetError(CError::iERROR_CODE_OPERATOR_NOT_FOUND, "evaluation");
				break;
			}//default
		}//switch (pcParams->eGetType())

		if (!*pcError)
		{
			*pcError = pc_evaluation->eConfigure(psSettings);
		}//if (!*pcError)
	}//if (!*pcError)

	return pc_evaluation;
}//CEvaluation<TFenotype> * EvaluationUtils::pcGetEvaluation(istream *psSettings, CError *pcError, string sRunId)

template <class TFenotype>
CDynamicEvaluation<TFenotype> * EvaluationUtils::pcGetDynamicEvaluation(istream *psSettings, CError *pcError)
{
	//CDynamicEvaluation<TFenotype> *pc_dynamic_evaluation = (CDynamicEvaluation<TFenotype>*)new CRealCompositionDBGDynamicEvaluation();
	CDynamicEvaluation<TFenotype> *pc_dynamic_evaluation = (CDynamicEvaluation<TFenotype>*)new CRealMovingPeakDynamicEvaluation();
		
		//TODO: HARDFIX!!!!! new CDynamicEvaluation<TFenotype>();
	*pcError = pc_dynamic_evaluation->eConfigure(psSettings);

	return pc_dynamic_evaluation;
}//CDynamicEvaluation<TFenotype> * EvaluationUtils::pcGetDynamicEvaluation(istream *psSettings, CError *pcError)


template CEvaluation<CBinaryCoding> * EvaluationUtils::pcGetEvaluation(istream*, CError*, string);
template CEvaluation<CPermutationCoding> * EvaluationUtils::pcGetEvaluation(istream*, CError*, string);
template CEvaluation<CRealCoding> * EvaluationUtils::pcGetEvaluation(istream*, CError*, string);

template CDynamicEvaluation<CBinaryCoding> * EvaluationUtils::pcGetDynamicEvaluation(istream*, CError*);
template CDynamicEvaluation<CPermutationCoding> * EvaluationUtils::pcGetDynamicEvaluation(istream*, CError*);
template CDynamicEvaluation<CRealCoding> * EvaluationUtils::pcGetDynamicEvaluation(istream*, CError*);