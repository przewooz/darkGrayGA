#ifndef DSMGA2_POPULATION_SIZING_H
#define DSMGA2_POPULATION_SIZING_H

#include "BinaryCoding.h"
#include "Error.h"
#include "Optimizer.h"
#include "PopulationSizingOptimizer.h"
#include "Problem.h"

#include <ctime>
#include <cstdint>
#include <istream>

using namespace std;

class CDSMGA2PopulationSizing : public CPopulationSizingOptimizer<CBinaryCoding, CBinaryCoding>
{
public:
	CDSMGA2PopulationSizing(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed);
	CDSMGA2PopulationSizing(CDSMGA2PopulationSizing *pcOther);

	virtual COptimizer<CBinaryCoding, CBinaryCoding> *pcCopy() { return new CDSMGA2PopulationSizing(this); };

	virtual bool bRunIterationSeparateLinkage(uint32_t iIterationNumber, CLinkageAnalyzer  *pcSeparateLinkage);

	void  vExecuteBeforeEnd() override;
	void  vReportLinkage() override;
	bool bReportLinkage_single_dsmga2_additive(int  iLTGA_Offset);

protected:
	virtual CPopulationSizingSingleOptimizer<CBinaryCoding, CBinaryCoding>* pc_get_params_optimizer(istream *psSettings, CError *pcError);

	bool b_run_proper_optimizer_iteration_sep_link(uint32_t iIterationNumber, CLinkageAnalyzer  *pcSeparateLinkage);
	virtual bool b_run_proper_optimizer_iteration(CPopulationSizingSingleOptimizer<CBinaryCoding, CBinaryCoding>* pcProperOptimizer, uint32_t iIterationNumber);
	virtual bool b_run_proper_optimizer_iteration_sep_link(CPopulationSizingSingleOptimizer<CBinaryCoding, CBinaryCoding>* pcProperOptimizer, uint32_t iIterationNumber, CLinkageAnalyzer *pcSeparateLinkage);

	virtual void v_delete_optimizers() override;
};//class CDSMGA2PopulationSizing : public CPopulationSizingOptimizer<CBinaryCoding, CBinaryCoding>

#endif//DSMGA2_POPULATION_SIZING_H