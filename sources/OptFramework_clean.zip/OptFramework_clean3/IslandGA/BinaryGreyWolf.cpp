#include "BinaryGreyWolf.h"


uint32_t CBinaryGreyWolfOptimizer::iERROR_PARENT_CBinaryGreyWolfOptimizer = CError::iADD_ERROR_PARENT("iERROR_PARENT_CBinaryGreyWolfOptimizer");

const float CBinaryGreyWolfOptimizer::F_DEFAULT_DECAY_COEFFICIENT = 0.001;


CBinaryGreyWolfOptimizer::CBinaryGreyWolfOptimizer(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog* pcLog, uint32_t iRandomSeed) :
	CPopulationSizingSingleOptimizer<CBinaryCoding, CBinaryCoding>(pcProblem, pcLog, iRandomSeed),
	c_uniform_zero_one_distribution(0, 1),
	v_a(3, 0), v_c(3, 0), v_d(3, 0), v_x(3, 0)
{
	c_random_engine.seed(iRandomSeed);
	pc_best = nullptr;
	pc_alpha = nullptr;
	pc_beta = nullptr;
	pc_delta = nullptr;
	i_genotype_length = pcProblem->pcGetEvaluation()->iGetNumberOfElements();
	d_a = 0;
	d_r1 = 0;
	d_r2 = 0;
	d_decay_coefficient = 0;
	i_decay_step = 0;
	i_decay_remove_step = 0;
}//CBinaryGreyWolfOptimizer::CBinaryGreyWolfOptimizer(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog* pcLog, uint32_t iRandomSeed)

CBinaryGreyWolfOptimizer::CBinaryGreyWolfOptimizer(CBinaryGreyWolfOptimizer* pcOther):
	CPopulationSizingSingleOptimizer<CBinaryCoding, CBinaryCoding>(pcOther),
	c_uniform_zero_one_distribution(pcOther->c_uniform_zero_one_distribution),
	c_random_engine(pcOther->c_random_engine),
	v_a(pcOther->v_a), v_c(pcOther->v_c), v_d(pcOther->v_d), v_x(pcOther->v_x)
{
	b_is_initialized = pcOther->b_is_initialized;
	b_use_stale_detection = pcOther->b_use_stale_detection;
	d_decay_coefficient = pcOther->d_decay_coefficient;
	d_a = pcOther->d_a;
	d_r1 = pcOther->d_r1;
	d_r2 = pcOther->d_r2;
	i_genotype_length = pcOther->i_genotype_length;
	i_population_size = pcOther->i_population_size;
	
	for (size_t i = 0; i < pcOther->v_population.size(); i++)
	{
		v_population.push_back(new CBinaryGreyWolfIndividual(*pcOther->v_population[i]));
	}//for(size_t i = 0; i < pcOther->v_population.size(); i++)

	if (pcOther->pc_best != nullptr)
	{
		pc_best = new CBinaryGreyWolfIndividual(*pcOther->pc_best);
	}//if(pcOther->pc_best != nullptr)
	else
	{
		pc_best = nullptr;
	}//else if(pcOther->pc_best != nullptr)

	if (pcOther->pc_alpha != nullptr)
	{
		pc_alpha = new CBinaryGreyWolfIndividual(*pcOther->pc_alpha);
	}//if (pcOther->pc_alpha != nullptr)
	else
	{
		pc_alpha = nullptr;
	}//else if (pcOther->pc_alpha != nullptr)

	if (pcOther->pc_beta != nullptr)
	{
		pc_beta = new CBinaryGreyWolfIndividual(*pcOther->pc_beta);
	}//if (pcOther->pc_beta != nullptr)
	else
	{
		pc_beta = nullptr;
	}//else if (pcOther->pc_beta != nullptr)

	if (pcOther->pc_delta != nullptr)
	{
		pc_delta = new CBinaryGreyWolfIndividual(*pcOther->pc_delta);
	}//if (pcOther->pc_delta != nullptr)
	else
	{
		pc_delta = nullptr;
	}//else if (pcOther->pc_delta != nullptr)

	i_decay_step = 0;
	i_decay_remove_step = 0;
}//CBinaryGreyWolfOptimizer::CBinaryGreyWolfOptimizer(CBinaryGreyWolfOptimizer* pcOther)

void CBinaryGreyWolfOptimizer::vInitialize()
{
	c_optimizer_timer.vSetStartNow();
	vResetBestIndividual();
	vDeleteIndividuals();
	vInitializeIndividuals();
	b_is_initialized = true;
}//void CBinaryBatOptimizer::vInitialize(time_t tStartTime)


CBinaryGreyWolfOptimizer::~CBinaryGreyWolfOptimizer()
{
	vDeleteIndividuals();
}//CBinaryGreyWolfOptimizer::~CBinaryGreyWolfOptimizer()


COptimizer<CBinaryCoding, CBinaryCoding>* CBinaryGreyWolfOptimizer::pcCopy()
{
	CBinaryGreyWolfOptimizer* pc_copy = new CBinaryGreyWolfOptimizer(this);
	return pc_copy;
}//COptimizer<CBinaryCoding, CBinaryCoding>* CBinaryGreyWolfOptimizer::pcCopy()

bool CBinaryGreyWolfOptimizer::bRunIteration(uint32_t iIterationNumber)
{
	d_a = max(0, 2.0 - 2.0 * i_decay_step * d_decay_coefficient);
	if (d_a > 0)
	{
		i_decay_remove_step = 0;
		i_decay_step++;
	}//if (d_a > 0)
	else
	{
		i_decay_remove_step++;
		if (i_decay_remove_step >= i_decay_step)  i_decay_step = 0;
	}//else  if (d_a > 0)
	
	bool b_any_better_than_best = false;
	for (size_t i = 0; i < v_population.size(); i++)
	{
		CBinaryGreyWolfIndividual* pc_individual = v_population[i];
		for (size_t j = 0; j < pc_individual->v_position.size(); j++)
		{
			d_r1 = c_uniform_zero_one_distribution(c_random_engine);
			d_r2 = c_uniform_zero_one_distribution(c_random_engine);

			v_a[0] = 2.0 * d_a * d_r1 - d_a; // Equation (3.3)
			v_c[0] = 2.0 * d_r2; // Equation (3.4)

			v_d[0] = abs(v_c[0] * pc_alpha->v_position[j] - pc_individual->v_position[j]); // Equation (3.5)-part 1
			v_x[0] = pc_alpha->v_position[j] - v_a[0] * v_d[0]; // Equation (3.6)-part 1

			d_r1 = c_uniform_zero_one_distribution(c_random_engine);
			d_r2 = c_uniform_zero_one_distribution(c_random_engine);

			v_a[1] = 2.0 * d_a * d_r1 - d_a;
			v_c[1] = 2.0 * d_r2;

			v_d[1] = abs(v_c[1] * pc_beta->v_position[j] - pc_individual->v_position[j]); // Equation (3.5)-part 2
			v_x[1] = pc_beta->v_position[j] - v_a[1] * v_d[1]; // Equation (3.6)-part 2

			d_r1 = c_uniform_zero_one_distribution(c_random_engine);
			d_r2 = c_uniform_zero_one_distribution(c_random_engine);

			v_a[2] = 2.0 * d_a * d_r1 - d_a;
			v_c[2] = 2.0 * d_r2;

			v_d[2] = abs(v_c[2] * pc_delta->v_position[j] - pc_individual->v_position[j]); // Equation (3.5)-part 3
			v_x[2] = pc_delta->v_position[j] - v_a[2] * v_d[2]; // Equation (3.6)-part 3

			pc_individual->v_position[j] = (v_x[0] + v_x[1] + v_x[2]) / 3.0; // Equation (3.7)
		}//for(size_t j = 0; j < pc_individual->v_position.size(); j++)
		pc_individual->v_transform_sigmoid(c_uniform_zero_one_distribution, c_random_engine);

		dEvaluate(*pc_individual);

		v_maybe_replace_leaders(pc_individual);

		bool b_best_updated = bMaybeUpdateBest(*pc_individual, iIterationNumber);
		
		b_any_better_than_best = b_any_better_than_best || b_best_updated;
	}//for (size_t i = 0; i < this->v_population.size(); i++)
	CString s_log_message;
	s_log_message.Format("Best fitness: %f; ffe: %llu; time: %.2lf; pop_size: %u dA:%.8lf", pc_best_individual->dGetFitnessValue(), pc_problem->pcGetEvaluation()->iGetFFE(), c_optimizer_timer.dGetTimePassed(), i_population_size, d_a);
	pc_log->vPrintLine(s_log_message, true);
	return b_any_better_than_best;
}//bool CBinaryGreyWolfOptimizer::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)

CError CBinaryGreyWolfOptimizer::eConfigure(istream* psSettings)
{
	CError c_error(iERROR_PARENT_CBinaryGreyWolfOptimizer);
	c_error = COptimizer::eConfigure(psSettings);

	if (!c_error)
	{
		CUIntCommandParam p_population_size(BINARY_GREY_WOLF_OPTIMIZER_ARGUMENT_POPULATION_SIZE, 2, UINT32_MAX);
		i_population_size = p_population_size.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		CBoolCommandParam p_stale_detection(BINARY_GREY_WOLF_OPTIMIZER_ARGUMENT_STALE_DETECTION, true, false);
		b_use_stale_detection = p_stale_detection.bGetValue(psSettings, &c_error);
	}//if (!c_error)

	if (!c_error)
	{
		CFloatCommandParam p_decay_coefficient(BINARY_GREY_WOLF_OPTIMIZER_ARGUMENT_DECAY_COEFFICIENT, F_DEFAULT_DECAY_COEFFICIENT);
		d_decay_coefficient = static_cast<double>(p_decay_coefficient.fGetValue(psSettings, &c_error));
	}//if (!c_error)

	return c_error;
}//CError CBinaryGreyWolfOptimizer::eConfigure(istream* psSettings)

CBinaryGreyWolfIndividual* CBinaryGreyWolfOptimizer::pcGetRandomIndividual()
{
	return CBinaryGreyWolfIndividual::pcGetRandomIndividual(i_genotype_length, c_uniform_zero_one_distribution, c_random_engine);
}//CBinaryGreyWolfIndividual* CBinaryGreyWolfOptimizer::pcGetRandomIndividual()
double CBinaryGreyWolfOptimizer::dComputeAverageFitnessValue()
{
	double d_sum = 0;

	CBinaryGreyWolfIndividual *pc_individual;

	for (uint32_t i = 0; i < i_population_size; i++)
	{
		pc_individual = v_population[i];

		d_sum += pc_individual->d_fitness;
	}//for (uint32_t i = 0; i < i_population_size; i++)

	return d_sum / (double)i_population_size;
}//double CBinaryGreyWolfOptimizer::dComputeAverageFitnessValue()

bool CBinaryGreyWolfOptimizer::bIsSteadyState()
{
	if (!b_use_stale_detection)
	{
		return false;
	}//if (!b_stale_detection)

	bool b_different_found = false;

	for (size_t ii = 1; !b_different_found && ii < v_population.size(); ii++)
	{
		bool b_all_same = true;

		for (size_t j = 0; b_all_same && j < i_genotype_length; j++)
		{
			if (v_population[0]->v_genotype[j] != v_population[ii]->v_genotype[j])
			{
				b_all_same = false;
			}//if (v_population[0]->v_genotype[j] != v_population[ii]->v_genotype[j])
		}//for (size_t j = 0; b_all_same && j < i_genotype_length; j++)

		if (!b_all_same)
		{
			b_different_found = true;
		}//if (!b_all_same)
	}//for (size_t ii = 1; !b_different_found && ii < v_population.size(); ii++)

	return !b_different_found;
}//bool CBinaryGreyWolfOptimizer::bIsSteadyState()

void CBinaryGreyWolfOptimizer::vDeleteIndividuals()
{
	if (b_is_initialized)
	{
		delete pc_alpha;
		delete pc_beta;
		delete pc_delta;
		delete pc_best;
		pc_alpha = nullptr;
		pc_beta = nullptr;
		pc_delta = nullptr;
		pc_best = nullptr;
		for (size_t i = 0; i < v_population.size(); i++)
		{
			delete v_population[i];
			v_population[i] = nullptr;
		}//for (size_t i = 0; i < i_population_size; i++)
	}//if(b_is_initialized)
	b_is_initialized = false;
}//void CBinaryGreyWolfOptimizer::vDeleteIndividuals()

void CBinaryGreyWolfOptimizer::vEvaluate(uint32_t iIterationNumber)
{
	for (size_t i = 0; i < i_population_size; i++)
	{
		dEvaluate(*v_population[i]);
		v_maybe_replace_leaders(v_population[i]);
		bMaybeUpdateBest(*v_population[i], iIterationNumber);
	}//for(size_t i = 0; i < i_population_size; i++)
}//void CBinaryGreyWolfOptimizer::vEvaluate(uint32_t iIterationNumber, time_t tStartTime)

bool CBinaryGreyWolfOptimizer::bMaybeUpdateBest(CBinaryGreyWolfIndividual& cPossiblyNewBest, uint32_t iIterationNumber)
{
	if(pc_best == nullptr || pc_problem->bIsBetterFitnessValue(cPossiblyNewBest.d_fitness, pc_best->d_fitness))
	{
		delete pc_best;
		pc_best = new CBinaryGreyWolfIndividual(cPossiblyNewBest);
		b_update_best_individual(iIterationNumber, pc_best->d_fitness, [&](CBinaryCoding *pcBestGenotype)
		{
			for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
			{
				*(pcBestGenotype->piGetBits() + i) = pc_best->v_genotype[i];
			}//for (uint16_t i = 0; i < pc_problem->pcGetEvaluation()->iGetNumberOfElements(); i++)
		});
		return true;
	}//if(pc_best == nullptr || pc_problem->bIsBetterFitnessValue(cPossiblyNewBest.d_fitness, pc_best->d_fitness))
	return false;
}//bool CBinaryGreyWolfOptimizer::bMaybeUpdateBest(CBinaryGreyWolfIndividual& cPossiblyNewBest, uint32_t iIterationNumber, time_t tStartTime)

double CBinaryGreyWolfOptimizer::dEvaluate(CBinaryGreyWolfIndividual& cIndividual)
{
	CBinaryCoding c_coding(i_genotype_length, cIndividual.v_genotype.data());
	double d_fitness_value = pcGetProblem()->pcGetEvaluation()->dEvaluate(&c_coding);
	cIndividual.d_fitness = d_fitness_value;
	return d_fitness_value;
}//double CBinaryGreyWolfOptimizer::dEvaluate(CBinaryGreyWolfIndividual& cIndividual)

void CBinaryGreyWolfOptimizer::vInitializeIndividuals()
{
	v_population.resize(i_population_size, nullptr);

	for (size_t i = 0; i < i_population_size; i++)
	{
		v_population[i] = pcGetRandomIndividual();
	}//for(size_t i = 0; i < i_population_size; i++)
	pc_alpha = new CBinaryGreyWolfIndividual(*v_population[0]);
	pc_beta = new CBinaryGreyWolfIndividual(*v_population[0]);
	pc_delta = new CBinaryGreyWolfIndividual(*v_population[0]);
	vEvaluate(0);
}//void CBinaryGreyWolfOptimizer::vInitializeIndividuals()

void CBinaryGreyWolfOptimizer::v_maybe_replace_leaders(CBinaryGreyWolfIndividual* pcIndividual)
{
	double d_individual_fitness = pcIndividual->d_fitness;
	if(pc_problem->bIsBetterFitnessValue(d_individual_fitness, pc_alpha->d_fitness))
	{
		pc_alpha = new CBinaryGreyWolfIndividual(*pcIndividual);
	}//if(pc_alpha == nullptr || pc_problem->bIsBetterFitnessValue(d_individual_fitness, pc_alpha->d_fitness))
	else if(pc_problem->bIsBetterFitnessValue(d_individual_fitness, pc_beta->d_fitness))
	{
		pc_beta = new CBinaryGreyWolfIndividual(*pcIndividual);
	}//else if(pc_beta == nullptr || pc_problem->bIsBetterFitnessValue(d_individual_fitness, pc_beta->d_fitness))
	else if (pc_problem->bIsBetterFitnessValue(d_individual_fitness, pc_delta->d_fitness))
	{
		pc_delta = new CBinaryGreyWolfIndividual(*pcIndividual);
	}//else if (pc_delta == nullptr || pc_problem->bIsBetterFitnessValue(d_individual_fitness, pc_delta->d_fitness))
}//bool CBinaryGreyWolfOptimizer::b_maybe_replace_leaders(CBinaryGreyWolfIndividual* pcIndividual)

CBinaryGreyWolfIndividual::CBinaryGreyWolfIndividual(uint16_t iGenotypeLength):
	d_fitness(0),
	v_position(iGenotypeLength, static_cast<double>(0)),
	v_genotype(iGenotypeLength, static_cast<int32_t>(0))

{
}//CBinaryGreyWolfIndividual::CBinaryGreyWolfIndividual(uint16_t iGenotypeLength):


CBinaryGreyWolfIndividual* CBinaryGreyWolfIndividual::pcGetRandomIndividual(uint16_t iGenotypeLength,
	uniform_real_distribution<>& cZeroOneDistribution,
	default_random_engine& cRandomEngine)
{
	CBinaryGreyWolfIndividual* pc_individual = new CBinaryGreyWolfIndividual(iGenotypeLength);
	for(size_t i = 0; i < iGenotypeLength; i++)
	{
		pc_individual->v_position[i] = cZeroOneDistribution(cRandomEngine);
	}
	pc_individual->v_transform_sigmoid(cZeroOneDistribution, cRandomEngine);
	return pc_individual;
}//CBinaryGreyWolfIndividual* CBinaryGreyWolfIndividual::pcGetRandomIndividual(uint16_t iGenotypeLength, uniform_real_distribution<>& cZeroOneDistribution, default_random_engine& cRandomEngine)

void CBinaryGreyWolfIndividual::v_transform_sigmoid(uniform_real_distribution<>& cThresholdDistribution,
	default_random_engine& cRandomEngine)
{
	size_t i_position_length = v_position.size();
	for (size_t i = 0; i < i_position_length; i++)
	{
		double d_threshold = cThresholdDistribution(cRandomEngine);
		double d_transformed_position = 1.0 / (1.0 + exp(-10 * (v_position[i] - 0.5)));
		if (d_transformed_position >= d_threshold)
		{
			v_genotype[i] = 1;
		}//if (dTransformedPosition > dThreshold)
		else
		{
			v_genotype[i] = 0;
		}//else if (dTransformedPosition > dThreshold)
	}//for (size_t i = 0; i < i_position_length; i++)
}//void CBinaryGreyWolfIndividual::v_transform_sigmoid(uniform_real_distribution<>& cThresholdDistribution, default_random_engine& cRandomEngine)
