#ifndef IO_UTILS_H
#define IO_UTILS_H

#include <atlstr.h>

namespace IOUtils
{
	bool bFileExists(CString sFilePath);
}//namespace IOUtils

#endif//IO_UTILS_H