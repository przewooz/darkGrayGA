#include "LTGAOriginalPopulationSizing.h"

#include "UIntCommandParam.h"

CLTGAOriginalPopulationSizing::CLTGAOriginalPopulationSizing(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed)
	: COptimizer<CBinaryCoding, CBinaryCoding>(pcProblem, pcLog, iRandomSeed), c_params_ltga(pcProblem, pcLog, iRandomSeed)
{

}//CLTGAOriginalPopulationSizing::CLTGAOriginalPopulationSizing(CProblem<CBinaryCoding, CBinaryCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed)

CLTGAOriginalPopulationSizing::CLTGAOriginalPopulationSizing(CLTGAOriginalPopulationSizing *pcOther)
	: COptimizer<CBinaryCoding, CBinaryCoding>(pcOther), c_params_ltga(pcOther->c_params_ltga), c_population_sizing_counter(pcOther->c_population_sizing_counter)
{

}//CLTGAOriginalPopulationSizing::CLTGAOriginalPopulationSizing(CLTGAOriginalPopulationSizing *pcOther)

CLTGAOriginalPopulationSizing::~CLTGAOriginalPopulationSizing()
{
	v_clear_ltgas();
}//CLTGAOriginalPopulationSizing::~CLTGAOriginalPopulationSizing()

CError CLTGAOriginalPopulationSizing::eConfigure(istream *psSettings)
{
	CError c_error = COptimizer<CBinaryCoding, CBinaryCoding>::eConfigure(psSettings);

	if (!c_error)
	{
		c_error = c_params_ltga.eConfigure(psSettings);
	}//if (!c_error)

	if (!c_error)
	{
		CUIntCommandParam p_population_creation_frequency(LTGA_ORIGINAL_POPULATION_SIZING_ARGUMENT_POPULATION_CREATION_FREQUENCY);
		i_population_creation_frequency = p_population_creation_frequency.iGetValue(psSettings, &c_error);

		if (!c_error)
		{
			c_population_sizing_counter.vReset();
			
			if (!c_population_sizing_counter.bSetBase(i_population_creation_frequency))
			{
				c_error.vSetError("cannot set the base of population sizing counter");
			}//if (!c_population_sizing_counter.bSetBase(i_population_creation_frequency))
		}//if (!c_error)
	}//if (!c_error)

	if (!c_error)
	{
		CUIntCommandParam p_population_size_multiplier(LTGA_ORIGINAL_POPULATION_SIZING_ARGUMENT_POPULATION_SIZE_MULTIPLIER);
		i_population_size_multiplier = p_population_size_multiplier.iGetValue(psSettings, &c_error);
	}//if (!c_error)

	return c_error;
}//CError CLTGAOriginalPopulationSizing::eConfigure(istream *psSettings)

void CLTGAOriginalPopulationSizing::vInitialize()
{
	COptimizer<CBinaryCoding, CBinaryCoding>::vInitialize();

	v_clear_ltgas();

	i_next_population_size = c_params_ltga.iGetPopulationSize();
	v_add_new_ltga(0);

	c_population_sizing_counter.vReset();

	b_update_best_individual(0);

	d_slides_ok = 0;
	d_slides_blocked = 0;
}//void CLTGAOriginalPopulationSizing::vInitialize(time_t tStartTime)


bool CLTGAOriginalPopulationSizing::bRunIterationSeparateLinkage(uint32_t iIterationNumber, CLinkageAnalyzer  *pcSeparateLinkage) 
{
	bool  b_scale_populations = false;
	if ( 
		(pcSeparateLinkage->dGetOutsideLinkageQuality() > 0)||
		(pcSeparateLinkage->bIsOutsideModeLinkageGenerating() == true)
		)
		b_scale_populations = true;

	if (b_scale_populations == true)
	{
		if (c_population_sizing_counter.iIncrement(i_next_population_size) == (uint32_t)v_ltgas.size())
		{
			v_add_new_ltga(iIterationNumber);
		}//if (c_population_sizing_counter.iIncrement() == (uint32_t)v_ltgas.size())
	}//if (pcSeparateLinkage->dGetOutsideLinkageQuality() >= 0)

	//we DO NOT increment c_population_sizing_counter we wish to run the same ltga pop as in the regular case and as iterationWithSeparateLinkage is invisible
	bool b_updated = false;

	if (b_run_proper_ltga_iteration(iIterationNumber, pcSeparateLinkage))
	{
		b_updated = b_update_best_individual(iIterationNumber);
	}//if (b_run_proper_ltga_iteration(iIterationNumber, tStartTime))


	CString s_averages_fitnesses;

	s_averages_fitnesses.Append("separateLinkage [");

	for (size_t i = 0; i < v_ltgas_average_fitnesses.size(); i++)
	{
		s_averages_fitnesses.AppendFormat("%f", v_ltgas_average_fitnesses.at(i));

		if (i + 1 < v_ltgas_average_fitnesses.size())
		{
			s_averages_fitnesses.Append(", ");
		}//if (i + 1 < v_ltgas_average_fitnesses.size())
	}//for (size_t i = 0; i < v_ltgas_average_fitnesses.size(); i++)

	s_averages_fitnesses.Append("]");

	CString s_log;

	s_log.Format("iteration: %d; time: %.2lf; number of ltgas: %d %s; best: %f", iIterationNumber, c_optimizer_timer.dGetTimePassed(),
		v_ltgas.size(), s_averages_fitnesses, pc_best_individual->dGetFitnessValue());

	pc_log->vPrintLine(s_log, true);
	pc_log->vPrintEmptyLine(true);

	//we DO NOT delete any pop. This is only additional run. The population sizing should be blind for it

	if (b_scale_populations == true)  v_delete_ltgas();


	return b_updated;


	return(true); 
};//bool CLTGAOriginalPopulationSizing::bRunIterationSeparateLinkage(uint32_t iIterationNumber, time_t tStartTime, CLinkageAnalyzer  *pcSeparateLinkage) 



void  CLTGAOriginalPopulationSizing::vExecuteBeforeEnd()
{
	vReportLinkage();
}//void  CLTGAOriginalPopulationSizing::vExecuteBeforeEnd()


bool CLTGAOriginalPopulationSizing::bReportLinkage_single_Ltga_additive(int  iLTGA_Offset)
{
	if (pc_linkage_analyzer != NULL)
	{
		CLTGAOriginal  *pc_ltga_to_report;

		if ((iLTGA_Offset < 0) || (v_ltgas.size() <= iLTGA_Offset))  return(false);
		pc_ltga_to_report = v_ltgas.at(iLTGA_Offset);
		
		vector<CLinkageAnalyzerSingleDSM  *>  *pv_dsm_set;
		pv_dsm_set = pc_linkage_analyzer->pvGetDSM_Sets();

		int  i_dsm_set_for_this_ltga_offset;
		i_dsm_set_for_this_ltga_offset = pv_dsm_set->size();//we initially set it to add a next new dsm set

		CLinkageInformationPack  *pc_link_pack;
		pc_link_pack = pc_ltga_to_report->pcGetLinkagePack();

		if (
			(pc_link_pack != NULL) &&(pc_linkage_analyzer->bIsOutsideModeLinkageGenerating() == true)
		   )
		{

			if (
				(pc_linkage_analyzer->iGetOutsideLinkageMode() == OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_FAST_3LO) ||
				(pc_linkage_analyzer->iGetOutsideLinkageMode() == OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_RANDOM) ||
				(pc_linkage_analyzer->iGetOutsideLinkageMode() == OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_HLL)||
				(pc_linkage_analyzer->iGetOutsideLinkageMode() == OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_PERFECT_TIGHT_LINKAGE_BLOCKS)
				)
			{
				pc_linkage_analyzer->vSetLinkDataPackDSM(i_dsm_set_for_this_ltga_offset, pc_ltga_to_report->iGetPopulationSize(), pc_link_pack->pcGetSingleLinkage()->pdGetDSM(), pc_link_pack->pcGetSingleLinkage()->iGetDSMsize());
			}//if (


			if (
				(pc_linkage_analyzer->iGetOutsideLinkageMode() == OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_MIX_DLED_SLL) ||
				(pc_linkage_analyzer->iGetOutsideLinkageMode() == OPTIMIZER_ARGUMENT_LINKAGE_ANALYZER_OUTSIDE_QUALITY_MIX_DLED_SLL_HLL)
				)
			{
				pc_link_pack->vSetDSM_SLL(false);
				pc_linkage_analyzer->vSetLinkDataPackDSM(i_dsm_set_for_this_ltga_offset, pc_ltga_to_report->iGetPopulationSize(), pc_link_pack->pcGetSingleLinkage()->pdGetDSM(), pc_link_pack->pcGetSingleLinkage()->iGetDSMsize(), "SLL");

				pc_link_pack->vSetDSM_DLED(false);
				pc_linkage_analyzer->vSetLinkDataPackDSM(i_dsm_set_for_this_ltga_offset + 1, pc_ltga_to_report->iGetPopulationSize(), pc_link_pack->pcGetSingleLinkage()->pdGetDSM(), pc_link_pack->pcGetSingleLinkage()->iGetDSMsize(), "DLED");

				pc_link_pack->vSetDSM_HLL_DLED_SLL(false);
				pc_linkage_analyzer->vSetLinkDataPackDSM(i_dsm_set_for_this_ltga_offset + 2, pc_ltga_to_report->iGetPopulationSize(), pc_link_pack->pcGetSingleLinkage()->pdGetDSM(), pc_link_pack->pcGetSingleLinkage()->iGetDSMsize(), "HLL");

			}//if (
			
			/*pc_linkage_analyzer->vCreatePairsReportAndFlushDependentPairs();
			CString  s_buf, s_report;
			s_buf.Format("pops: %d  ", v_ltgas.size());
			s_report = pc_linkage_analyzer->sGeneralCurrentReport();
			pc_log->vPrintLine("LINKAGE REPORT:" + s_buf + s_report, true);//*/

			return(true);
		}//if (pc_link_pack != NULL) &&(pc_linkage_analyzer->bIsOutsideModeLinkageGenerating() == true)




		//fit by population
		for (int ii = 0; (ii < pv_dsm_set->size()) && (i_dsm_set_for_this_ltga_offset == pv_dsm_set->size()); ii++)
		{
			if (pv_dsm_set->at(ii)->iGetPopSize() == pc_ltga_to_report->iGetPopulationSize())  i_dsm_set_for_this_ltga_offset = ii;
		}//for (int ii = 0; (ii < pv_dsm_set->size())&&(i_dsm_set_for_this_ltga_offset == pv_dsm_set->size()); ii++)

		pc_linkage_analyzer->vSetLTGA_DSM(i_dsm_set_for_this_ltga_offset, pc_ltga_to_report->iGetPopulationSize(), pc_ltga_to_report->pdGetDSM(), pc_ltga_to_report->iGetDSMSize());

		/*pc_linkage_analyzer->vCreatePairsReportAndFlushDependentPairs();


		CString  s_buf, s_report;
		s_buf.Format("pops: %d  ", v_ltgas.size());
		s_report = pc_linkage_analyzer->sGeneralCurrentReport();


		pc_log->vPrintLine("LINKAGE REPORT:" + s_buf + s_report, true);*/

		return(true);
	}//if (pc_linkage_analyzer != NULL)
	

	return(false);
}//void CLTGAOriginalPopulationSizing::vReportLinkage_single_Ltga_additive(int  iLTGA_Offset)


void CLTGAOriginalPopulationSizing::vReportLinkage()
{
	if (pc_linkage_analyzer != NULL)
	{
		double  d_perc;

		
		for (int ii = 0; ii < v_ltgas.size(); ii++)
		{
			bReportLinkage_single_Ltga_additive(ii);
		}//for (int ii = 0; ii < pops.size(); ii++)

		pc_linkage_analyzer->vCreatePairsReportAndFlushDependentPairs();


		CString  s_buf, s_report;
		s_buf.Format("pops: %d  ", v_ltgas.size());
		s_report = pc_linkage_analyzer->sGeneralCurrentReport();


		pc_log->vPrintLine("LINKAGE REPORT:" + s_buf + s_report, true);
	}//if (pc_linkage_analyzer != NULL)
}//void CLTGAOriginalPopulationSizing::vReportLinkage()


bool CLTGAOriginalPopulationSizing::bRunIteration(uint32_t iIterationNumber)
{
	if (c_population_sizing_counter.iIncrement(i_next_population_size) == (uint32_t)v_ltgas.size())
	{
		v_add_new_ltga(iIterationNumber);
	}//if (c_population_sizing_counter.iIncrement() == (uint32_t)v_ltgas.size())


	bool b_updated = false;

	if (b_run_proper_ltga_iteration(iIterationNumber))
	{
		b_updated = b_update_best_individual(iIterationNumber);
	}//if (b_run_proper_ltga_iteration(iIterationNumber, tStartTime))


	CString s_averages_fitnesses;

	s_averages_fitnesses.Append("[");

	for (size_t i = 0; i < v_ltgas_average_fitnesses.size(); i++)
	{
		s_averages_fitnesses.AppendFormat("%f", v_ltgas_average_fitnesses.at(i));

		if (i + 1 < v_ltgas_average_fitnesses.size())
		{
			s_averages_fitnesses.Append(", ");
		}//if (i + 1 < v_ltgas_average_fitnesses.size())
	}//for (size_t i = 0; i < v_ltgas_average_fitnesses.size(); i++)

	s_averages_fitnesses.Append("]");

	CString s_log;

	s_log.Format("iteration: %d; time: %.2lf; number of ltgas: %d %s; best: %f", iIterationNumber, c_optimizer_timer.dGetTimePassed(),
		v_ltgas.size(), s_averages_fitnesses, pc_best_individual->dGetFitnessValue());

	pc_log->vPrintLine(s_log, true);
	pc_log->vPrintEmptyLine(true);


	v_delete_ltgas();


	return b_updated;
}//bool CLTGAOriginalPopulationSizing::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)



bool CLTGAOriginalPopulationSizing::b_update_best_individual(uint32_t iIterationNumber)
{
	CLTGAOriginal *pc_ltga = v_ltgas.at((size_t)c_population_sizing_counter.iGetLastMostSignificantChangeIndex());
	CIndividual<CBinaryCoding, CBinaryCoding> *pc_ltga_best_individual = pc_ltga->pcGetBestIndividual();

	bool b_updated = false;

	if (pc_ltga_best_individual)
	{
		//if (pc_ltga_best_individual->dGetFitnessValue() == 10)  ::MessageBox(NULL, "10here", "10here", MB_OK);

		if (b_update_best_individual(iIterationNumber, pc_ltga_best_individual))
		{
			b_updated = true;
		}//if (b_update_best_individual(iIterationNumber, tStartTime, pc_ltga_best_individual))
	}//if (pc_ltga_best_individual)

	return b_updated;
}//bool CLTGAOriginalPopulationSizing::b_update_best_individual(uint32_t iIterationNumber, time_t tStartTime)

void CLTGAOriginalPopulationSizing::v_clear_ltgas()
{
	for (size_t i = 0; i < v_ltgas.size(); i++)
	{
		delete v_ltgas.at(i);
	}//for (size_t i = 0; i < v_ltgas.size(); i++)

	v_ltgas.clear();
	v_ltgas_average_fitnesses.clear();
}//void CLTGAOriginalPopulationSizing::v_clear_ltgas()



bool CLTGAOriginalPopulationSizing::b_run_proper_ltga_iteration(uint32_t iIterationNumber, CLinkageAnalyzer  *pcSeparateLinkage /*= NULL*/)
{
	uint32_t i_proper_ltga_index = c_population_sizing_counter.iGetLastMostSignificantChangeIndex();
	if (v_ltgas.size() == 0)  return(false);
	CLTGAOriginal *pc_proper_ltga = v_ltgas.at((size_t)i_proper_ltga_index);
	
	bool b_updated;

	if  (pcSeparateLinkage == NULL)
		b_updated = pc_proper_ltga->bRunIteration(iIterationNumber);
	else
		b_updated = pc_proper_ltga->bRunIterationSeparateLinkage(iIterationNumber, pcSeparateLinkage);

	v_ltgas_average_fitnesses.at((size_t)i_proper_ltga_index) = pc_proper_ltga->dComputeAverageFitnessValue();

	return b_updated;
}//bool CLTGAOriginalPopulationSizing::b_run_proper_ltga_iteration(uint32_t iIterationNumber, time_t tStartTime)



void  CLTGAOriginalPopulationSizing::vGetSlideInformation(double  *pdSlides, double  *pdBlockedSlides)
{
	double  d_slides_ok_buf, d_slides_blocked_buf;

	*pdSlides = d_slides_ok;
	*pdBlockedSlides = d_slides_blocked;

	for (int ii = 0; ii < v_ltgas.size(); ii++)
	{
		v_ltgas.at(ii)->vGetSlideInformation(&d_slides_ok_buf, &d_slides_blocked_buf);

		*pdSlides += d_slides_ok;
		*pdBlockedSlides += d_slides_blocked;
	}//for (int ii = 0; ii < v_ltgas.size(); ii++)
	
}//void  CLTGAOriginalPopulationSizing::vGetSlideInformation(double  *pdSlides, double  *pdBlockedSlides)


void CLTGAOriginalPopulationSizing::v_delete_ltgas()
{
	unordered_set<size_t> s_ltgas_to_delete_indexes;
	s_ltgas_to_delete_indexes.reserve(v_ltgas.size());

	v_get_ltgas_to_delete(&s_ltgas_to_delete_indexes);

	if (!s_ltgas_to_delete_indexes.empty())
	{
		//vReportLinkage();

		for (size_t i = v_ltgas.size(); i > 0; i--)
		{
			if (s_ltgas_to_delete_indexes.count(i - 1) > 0)
			{
				bReportLinkage_single_Ltga_additive(i-1);

				
				double  d_slides_ok_buf, d_slides_blocked_buf;
				v_ltgas.at(i - 1)->vGetSlideInformation(&d_slides_ok_buf, &d_slides_blocked_buf);
				d_slides_ok += d_slides_ok_buf;
				d_slides_blocked += d_slides_blocked_buf;

				delete v_ltgas.at(i - 1);
				v_ltgas.erase(v_ltgas.begin() + i - 1);
				v_ltgas_average_fitnesses.erase(v_ltgas_average_fitnesses.begin() + i - 1);
			}//if (s_ltgas_to_delete_indexes.count(i - 1) > 0)
		}//for (size_t i = v_ltgas.size(); i > 0; i--)

		c_population_sizing_counter.vReset();
	}//if (!s_ltgas_to_delete_indexes.empty())
}//void CLTGAOriginalPopulationSizing::v_delete_ltgas()

void CLTGAOriginalPopulationSizing::v_get_ltgas_to_delete(unordered_set<size_t> *psIndexes)
{
	size_t i_last_iteration_ltga_index = (size_t)c_population_sizing_counter.iGetLastMostSignificantChangeIndex();

	if (v_ltgas.at(i_last_iteration_ltga_index)->bAreAllIndividualsTheSame())
	{
		psIndexes->insert(i_last_iteration_ltga_index);
	}//if (v_ltgas.at(i_last_iteration_ltga_index)->bAreAllIndividualsTheSame())
	else
	{
		bool b_to_delete = false;

		double d_last_iteration_ltga_average_fitness = v_ltgas_average_fitnesses.at(i_last_iteration_ltga_index);

		for (size_t i = i_last_iteration_ltga_index + 1; i < v_ltgas.size() && !b_to_delete; i++)
		{
			b_to_delete = d_last_iteration_ltga_average_fitness < v_ltgas_average_fitnesses.at(i);
		}//for (size_t i = i_last_iteration_ltga_index + 1; i < v_ltgas.size() && !b_to_delete; i++)

		if (b_to_delete)
		{
			for (size_t i = 0; i <= i_last_iteration_ltga_index; i++)
			{
				psIndexes->insert(i);
			}//for (size_t i = 0; i <= i_last_iteration_ltga_index; i++)
		}//if (b_to_delete)

		for (size_t i = i_last_iteration_ltga_index && !b_to_delete; i > 0; i--)
		{
			b_to_delete = v_ltgas_average_fitnesses.at(i - 1) < d_last_iteration_ltga_average_fitness;

			if (b_to_delete)
			{
				for (size_t j = 0; j <= i - 1; j++)
				{
					psIndexes->insert(j);
				}//for (size_t j = 0; j <= i - 1; j++)
			}//if (b_to_delete)
		}//for (size_t i = i_last_iteration_ltga_index; i > 0; i--)
	}//else if (v_ltgas.at(i_last_iteration_ltga_index)->bAreAllIndividualsTheSame())
}//void CLTGAOriginalPopulationSizing::v_get_ltgas_to_delete(unordered_set<size_t> *psIndexes)

void CLTGAOriginalPopulationSizing::v_add_new_ltga(uint32_t iIterationNumber)
{
	CLTGAOriginal *pc_ltga = new CLTGAOriginal(&c_params_ltga);

	pc_ltga->vSetPopulationSize(i_next_population_size);
	pc_ltga->vInitialize();
	
	v_ltgas.push_back(pc_ltga);
	v_ltgas_average_fitnesses.push_back(pc_ltga->dComputeAverageFitnessValue());

	i_next_population_size *= i_population_size_multiplier;
}//void CLTGAOriginalPopulationSizing::v_add_new_ltga(uint32_t iIterationNumber, time_t tStartTime)