#pragma once

#include <vector>
#include <string>
#include <algorithm>
#include <fstream>
#include <cmath>
#include <deque>
#include <random>
#include <unordered_map>
#include <numeric>
//#include <bits/stdc++.h> 
#include <cassert>
using namespace std;

#include "cGomea_Individual.h"
#include "cGomea_utils.h"


class C_CGomea_FOS
{	
public:
	vector<vector<int> > FOSStructure;	
	size_t numberOfVariables;
	size_t alphabetSize;
	
	vector<int> improvementCounters;
	vector<int> usageCounters;

	vector<int> single_counters;
	vector<vector<int> > pair_counters;
	
	C_CGomea_FOS(size_t numberOfVariables_, size_t alphabetSize_): numberOfVariables(numberOfVariables_), alphabetSize(alphabetSize_)
	{}

	virtual ~C_CGomea_FOS(){};

	size_t FOSSize()
	{
		return FOSStructure.size();
	}

	size_t FOSElementSize(int i)
	{
		return FOSStructure[i].size();
	}
	
	virtual void learnFOS(vector<C_CGomea_Individual*> &population, vector<vector<int> > *VIG = NULL, mt19937 *rng = NULL) = 0;
	void writeToFileFOS(string folder, int populationIndex, int generation);
	void writeFOSStatistics(string folder, int populationIndex, int generation);
	void setCountersToZero();
	void shuffleFOS(vector<int> &indices, mt19937 *rng);
	void sortFOSAscendingOrder(vector<int> &indices);
	void sortFOSDescendingOrder(vector<int> &indices);
	void orderFOS(int orderingType, vector<int> &indices, mt19937 *rng);

	virtual void get_MI_Matrix(vector<vector<double> > &matrix){};
	virtual void addSolution(C_CGomea_Individual *solution){};
	virtual void addSolutionTournamentSelection(C_CGomea_Individual solution){};
	
	virtual void writeMIMatrixToFile(string folder, int populationIndex, int generation){};
};


class C_CGomea_LTFOS: public C_CGomea_FOS
{
private:
	vector<vector<double> > MI_Matrix;
	vector<vector<double> > S_Matrix;
	bool filtered;
	int similarityMeasure;
	int determineNearestNeighbour(int index, vector< vector< int > > &mpm);
	void computeMIMatrix(vector<C_CGomea_Individual*> &population);
	void computeNMIMatrix(vector<C_CGomea_Individual*> &population);
	void estimateParametersForSingleBinaryMarginal(vector<C_CGomea_Individual*> &population, vector<size_t> &indices, size_t  &factorSize, vector<double> &result);

public:	
	C_CGomea_LTFOS(size_t numberOfVariables_, size_t alphabetSize_, int similarityMeasure, bool filtered=false);
	~C_CGomea_LTFOS(){};

	void learnFOS(vector<C_CGomea_Individual*> &population, vector<vector<int> > *VIG = NULL, mt19937 *rng = NULL);
	void writeMIMatrixToFile(string folder, int populationIndex, int generation);
	void get_MI_Matrix(vector<vector<double> > &matrix)
	{
		matrix.resize(MI_Matrix.size());
		for (int i = 0; i < numberOfVariables; ++i)
		{
			matrix[i].resize(MI_Matrix[i].size());
			for (int j = 0; j < numberOfVariables; ++j)
			{
				matrix[i][j] = MI_Matrix[i][j];
				//cout << matrix[i][j] << " ";
			}
		}
	}

};

class C_CGomea_LTFOSEfficient: public C_CGomea_FOS
{
private:
	vector<vector<int> > single_counters;
	vector<vector<vector<int> > > pair_counters;

	vector<vector<double> > MI_Matrix;
	vector<vector<double> > S_Matrix;
	bool filtered;
	int similarityMeasure;
	int determineNearestNeighbour(int index, vector< vector< int > > &mpm);
	void computeMIMatrix(vector<C_CGomea_Individual*> &population);
	void computeNMIMatrix(vector<C_CGomea_Individual*> &population);
	void estimateParametersForSingleBinaryMarginal(vector<C_CGomea_Individual*> &population, vector<size_t> &indices, size_t  &factorSize, vector<double> &result);
	vector<C_CGomea_Individual> minHeap;
	vector<C_CGomea_Individual> maxHeap;
	
public:	
	C_CGomea_LTFOSEfficient(size_t numberOfVariables_, size_t alphabetSize_, int similarityMeasure, bool filtered=false);
	~C_CGomea_LTFOSEfficient(){};

	void learnFOS(vector<C_CGomea_Individual*> &population, vector<vector<int> > *VIG = NULL, mt19937 *rng = NULL);
	void buildGraph(double thresholdValue, mt19937 *rng);
	void writeMIMatrixToFile(string folder, int populationIndex, int generation);
	void addSolution(C_CGomea_Individual *solution);
	void addSolutionTournamentSelection(C_CGomea_Individual solution);
	
	void get_MI_Matrix(vector<vector<double> > &matrix)
	{
		matrix.resize(MI_Matrix.size());
		for (int i = 0; i < numberOfVariables; ++i)
		{
			matrix[i].resize(MI_Matrix[i].size());
			for (int j = 0; j < numberOfVariables; ++j)
			{
				matrix[i][j] = MI_Matrix[i][j];
				//cout << matrix[i][j] << " ";
			}
		}
	}

};


struct ascendingFitness{
  bool operator()(const C_CGomea_Individual &a, const C_CGomea_Individual &b) const{
    return a.fitness < b.fitness;
  }
};

struct descendingFitness{
  bool operator()(const C_CGomea_Individual &a, const C_CGomea_Individual &b) const{
    return a.fitness > b.fitness;
  }
};

bool FOSNameByIndex(size_t FOSIndex, string &FOSName);
void createFOSInstance(size_t FOSIndex, C_CGomea_FOS **FOSInstance, size_t numberOfVariables, size_t alphabetSize, int similarityMeasure);
