#ifndef PERMUTATION_EVALUATION_H
#define PERMUTATION_EVALUATION_H

#define EVALUATION_PERMUTATION_TAILLARD_FLOWSHOP_ARGUMENT_NUMBER_OF_JOBS "evaluation_number_of_jobs"
#define EVALUATION_PERMUTATION_TAILLARD_FLOWSHOP_ARGUMENT_NUMBER_OF_MACHINES "evaluation_number_of_machines"
#define EVALUATION_PERMUTATION_TAILLARD_FLOWSHOP_ARGUMENT_INSTANCE_INDEX "evaluation_instance_index"

#include "Error.h"
#include "Evaluation.h"
#include "PermutationCoding.h"
#include "StringUtils.h"

#include <atlstr.h>
#include <cstdint>
#include <iostream>
#include <unordered_map>

using namespace std;


class CPermutationEvaluation : public CEvaluation<CPermutationCoding>
{
public:
	virtual CPermutationCoding *pcCreateSampleFenotype();
};//class CPermutationEvaluation : public CEvaluation<CPermutationCoding>


class CPermutationSampleEvaluation : public CPermutationEvaluation
{
public:
	virtual CError eConfigure(istream *psSettings);

protected:
	virtual double d_evaluate(CPermutationCoding *pcFenotype, uint16_t iShift);
};//class CPermutationSampleEvaluation : public CPermutationEvaluation


class CPermutationTaillardFlowshopBasedEvaluation : public CPermutationEvaluation
{
public:
	CPermutationTaillardFlowshopBasedEvaluation();

	virtual ~CPermutationTaillardFlowshopBasedEvaluation();

	virtual CError eConfigure(istream *psSettings);

protected:
	uint32_t i_number_of_machines;

	double **ppd_processing_times;
	double **ppd_calculations;

private:
	void v_clear();

	void v_clear_processing_times();
	void v_create_processing_times(uint16_t iNumberOfJobs, uint32_t iNumberOfMachines);

	void v_clear_calculations();
	void v_create_calculations(uint16_t iNumberOfJobs, uint32_t iNumberOfMachines);

	CError e_load(istream *psDefinition, uint16_t iNumberOfJobs, uint32_t iNumberOfMachines, uint8_t iInstanceIndex);
};//class CPermutationTaillardFlowshopBasedEvaluation : public CPermutationEvaluation


class CPermutationTaillardFlowshopEvaluation : public CPermutationTaillardFlowshopBasedEvaluation
{
protected:
	virtual double d_evaluate(CPermutationCoding *pcFenotype, uint16_t iShift);
};//class CPermutationTaillardFlowshopEvaluation : public CPermutationTaillardFlowshopBasedEvaluation


class CPermutationChainTaillardFlowshopEvaluation : public CPermutationTaillardFlowshopBasedEvaluation
{
public:
	CPermutationChainTaillardFlowshopEvaluation();

	virtual ~CPermutationChainTaillardFlowshopEvaluation();

	virtual CError eConfigure(istream *psSettings);

protected:
	virtual double d_evaluate(CPermutationCoding *pcFenotype, uint16_t iShift);

private:
	void v_create_last_permutation();

	int32_t *pi_last_permutation;
};//class CPermutationChainTaillardFlowshopEvaluation : public CPermutationTaillardFlowshopBasedEvaluation


class CPermutationLinearOrderingProblemEvaluation : public CPermutationEvaluation
{
public:
	CPermutationLinearOrderingProblemEvaluation();

	virtual ~CPermutationLinearOrderingProblemEvaluation();

	virtual CError eConfigure(istream *psSettings);

protected:
	virtual double d_evaluate(CPermutationCoding *pcFenotype, uint16_t iShift);

private:
	void v_clear();

	double **ppd_coefficients;
};//class CPermutationLinearOrderingProblemEvaluation : public CPermutationEvaluation


class CPermutationRelativeOrderingEvaluation : public CPermutationEvaluation
{
public:
	CPermutationRelativeOrderingEvaluation();

protected:
	virtual double d_evaluate(CPermutationCoding *pcFenotype, uint16_t iShift);

private:
	static unordered_map<CString, double> m_possible_values;
};//class CPermutationRelativeOrderingEvaluation : public CPermutationEvaluation


class CPermutationAbsoluteOrderingEvaluation : public CPermutationEvaluation
{
public:
	CPermutationAbsoluteOrderingEvaluation();

protected:
	virtual double d_evaluate(CPermutationCoding *pcFenotype, uint16_t iShift);

private:
	static unordered_map<CString, double> m_possible_values;
};//class CPermutationAbsoluteOrderingEvaluation : public CPermutationEvaluation


//TODO_SZYMON


#endif//PERMUTATION_EVALUATION_H