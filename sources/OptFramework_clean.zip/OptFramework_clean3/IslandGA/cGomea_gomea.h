#pragma once

#include <string> 
#include <iostream>
using namespace std;

#include "cGomea_Config.h"
#include "cGomea_Individual.h"
#include "cGomea_shared.h"
#include "cGomea_problems.h"

class C_CGomea_GOMEA
{
public:
	C_CGomea_Config *config;
	C_CGomea_Problem *problemInstance = NULL;
	C_CGomea_sharedInformation *sharedInformationInstance = NULL;

	C_CGomea_GOMEA(C_CGomea_Config *config_): config(config_){};
	virtual ~C_CGomea_GOMEA(){};

	virtual void run() = 0;
	double readVTR();
};