#include "ProblemStructureAnalysis_DLED.h"



using  namespace ProblemStructureAnalysis;



uint32_t CProblemStructAnal_DLED::iERROR_PARENT_CProblemStructAnal_DLED = CError::iADD_ERROR_PARENT("iERROR_PARENT_CProblemStructAnal_DLED");
uint32_t CProblemStructAnal_DLED::iERROR_CODE_PSA_DLED_GENOTYPE_LEN_BELOW_0 = CError::iADD_ERROR("iERROR_CODE_PSA_DLED_GENOTYPE_LEN_BELOW_0");
uint32_t CProblemStructAnal_DLED::iERROR_CODE_PSA_DLED_SAVE_ERR = CError::iADD_ERROR("iERROR_CODE_PSA_DLED_SAVE_ERR");


//---------------------------------------------CProblemStructAnal_DLED-------------------------------------------------------
CProblemStructAnal_DLED::CProblemStructAnal_DLED(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)
	: CBinaryOptimizer(pcProblem, pcLog, iRandomSeed)
{
	pc_link_pack = NULL;
};//CProblemStructAnal_DLED::CProblemStructAnal_DLED(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed)



CProblemStructAnal_DLED::CProblemStructAnal_DLED(CProblemStructAnal_DLED *pcOther) : CBinaryOptimizer(pcOther)
{
	::MessageBox(NULL, "Brak implementacji: CProblemStructAnal_DLED::CProblemStructAnal_DLED(CProblemStructAnal_DLED *pcOther) : CBinaryOptimizer(pcOther)", "BRAK", MB_OK);
}//CProblemStructAnal_DLED::CProblemStructAnal_DLED(CProblemStructAnal_DLED *pcOther) : CBinaryOptimizer(pcOther)



CProblemStructAnal_DLED::~CProblemStructAnal_DLED()
{
	pc_link_pack->eSaveDSM_DLED(pc_log->sGetLogFile() + _PROB_STRUCT_ANAL_DSM_DLED_POSFIX + ".txt", pc_link_pack->piGet_DSM_DLED());
	pc_link_pack->eSaveDSM_DLED(pc_log->sGetLogFile() + _PROB_STRUCT_ANAL_DSM_DLED_DISTANCES_POSTFIX + ".txt", pc_link_pack->piGet_DSM_DLED_Distances());
	eSaveDSM_DetailedDistanceReport(pc_log->sGetLogFile() + _PROB_STRUCT_ANAL_DSM_DLED_DISTANCES_DET_REP_POSTFIX + ".txt");
	

	if (pc_link_pack != NULL)  delete  pc_link_pack;
}//CProblemStructAnal_DLED::~CProblemStructAnal_DLED()


CError  CProblemStructAnal_DLED::eSaveDSM_DetailedDistanceReport(CString  sDest)
{
	CError  c_err(iERROR_PARENT_CProblemStructAnal_DLED);

	FILE  *pf_dest;
	pf_dest = fopen(sDest, "w+");

	if (pf_dest == NULL)
	{
		c_err.vSetError(iERROR_CODE_PSA_DLED_SAVE_ERR, sDest);
		return(c_err);
	}//if  (pf_dest == NULL)

	vSaveDSM_DetailedDistanceReport(pf_dest);

	fclose(pf_dest);
	return(c_err);
}//CError  CProblemStructAnal_DLED::eSaveDSM_DetailedDistanceReport(CString  sDest)



void  CProblemStructAnal_DLED::vSaveDSM_DetailedDistanceReport(FILE  *pfDest)
{
	CString  s_line, s_buf;

	int  i_hop_min, i_hop_max;
	double  d_hop_avr;

	for (int i_gene = 0; i_gene < i_templ_length; i_gene++)
	{
		v_get_min_max_avr_hop_for_gene(i_gene, &i_hop_min, &i_hop_max, &d_hop_avr);
		s_line.Format("Gene: %d \t Avr: %.4lf \t Min: %d \t Max: %d \t", i_gene, d_hop_avr, i_hop_min, i_hop_max);

		s_buf.Format("DISTANCES: \t Inf: %d \t", v_dled_distances.at(0).pvGetGeneHopCoverage()->at(i_gene));
		s_line += s_buf;

		for (int i_hop = 1; i_hop < v_dled_distances.size(); i_hop++)
		{
			s_buf.Format("d%.2d: %d \t", i_hop, v_dled_distances.at(i_hop).pvGetGeneHopCoverage()->at(i_gene));
			s_line += s_buf;
		}//for (int i_hop = 1; i_hop < v_dled_distances.size(); i_hop++)

		fprintf(pfDest, s_line + "\n");
	}//for (int i_gene = 0; i_gene < i_templ_length; i_gene++)
}//void  CProblemStructAnal_DLED::vSaveDSM_DetailedDistanceReport(FILE  *pfDest)


void  CProblemStructAnal_DLED::v_get_min_max_avr_hop_for_gene(int  iGene, int  *piHopMin, int  *piHopMax, double  *pdHopAvr)
{
	*piHopMin = -1;
	*piHopMax = -1;
	*pdHopAvr = 0;

	int  i_hop_cur;
	int  i_hop_total = 0;
	//we start from i_hop = 1, beacuse i_hop = 0 stands for the infinity...
	for (int i_hop = 1; i_hop < v_dled_distances.size(); i_hop++)
	{
		i_hop_cur = v_dled_distances.at(i_hop).pvGetGeneHopCoverage()->at(iGene);
		i_hop_total += i_hop_cur;

		(*pdHopAvr) += i_hop_cur * i_hop;

		if (i_hop_cur > 0)
		{
			if (*piHopMin == -1)  *piHopMin = i_hop;
			if (*piHopMax == -1)  *piHopMax = i_hop;
			if (*piHopMax < i_hop)  *piHopMax = i_hop;
		}//if (i_hop_cur > 0)
	}//for (int i_hop = 0; i_hop < v_dled_distances.size(); i_hop++)

	(*pdHopAvr) = (*pdHopAvr) / i_hop_total;
	
}//void  CProblemStructAnal_DLED::v_get_min_max_avr_hop_for_gene(int  iGene, int  *piHopMin, int  *piHopMax, double  *pdHopAvr)




void  CProblemStructAnal_DLED::vInitialize()
{
	i_templ_length = pc_problem->pcGetEvaluation()->iGetNumberOfElements();
	c_optimizer_timer.vSetStartNow();
}//void  CProblemStructAnal_DLED::vInitialize(time_t tStartTime)



void  CProblemStructAnal_DLED::vCopyFrom(CProblemStructAnal_DLED *pcOther)
{
	::MessageBox(NULL, "Brak implementacji: CProblemStructAnal_DLED::vCopyFrom(CProblemStructAnal_DLED *pcOther)", "BRAK", MB_OK);

	i_templ_length = pcOther->i_templ_length;
}//void  CProblemStructAnal_DLED::vCopyFrom(CProblemStructAnal_DLED *pcOther)



CError CProblemStructAnal_DLED::eConfigure(istream *psSettings)
{
	CError c_err(iERROR_PARENT_CProblemStructAnal_DLED);


	c_err = CBinaryOptimizer::eConfigure3LO(psSettings);

	pc_linkage_analyzer = new CLinkageAnalyzer();//new CLinkageAnalyzer(pc_log);
	c_err = pc_linkage_analyzer->eConfigure(psSettings);


	

	return c_err;
};//CError CProblemStructAnal_DLED::eConfigure(istream *psSettings)





bool CProblemStructAnal_DLED::bRunIteration(uint32_t iIterationNumber)
{
	CError c_err(iERROR_PARENT_CProblemStructAnal_DLED);

	CString  s_buf;


	
	CProblemStructAnal_Ind  *pc_ind_test;
	pc_ind_test = new CProblemStructAnal_Ind(i_templ_length, pc_problem, this);
	pc_ind_test->dComputeFitnessOptimize();


	
	if (pc_link_pack == NULL)
	{
		pc_linkage_analyzer->bLinkagePackCreate(&pc_link_pack);
		pc_link_pack->vConfigure(pc_problem->pcGetEvaluation(), NULL, pc_evaluation_individual->pcGetPhenotype());
	}//if  (pc_link_pack == NULL)


	pc_link_pack->vSetIndividual3LOa(pc_ind_test->piGetGenotype());
	pc_link_pack->vComputeDSM_ProblemDEcomp_DLED();
	pc_link_pack->vCompute_DLED_Distances();

	//pc_link_pack_test->eSaveDSM_DLED("zzz_test_dsm_dled.txt", pc_link_pack_test->piGet_DSM_DLED());
	//pc_link_pack_test->eSaveDSM_DLED("zzz_test_dsm_dled_distances.txt", pc_link_pack_test->piGet_DSM_DLED_Distances());

	vector<CDledDistanceStats>  v_dled_distances_old;
	v_dled_distances_old = v_dled_distances;
	v_dled_distances.clear();
	pc_link_pack->vGet_DLED_DistanceStats(&v_dled_distances);

	bool  b_generate_report;

	if (v_dled_distances_old.size() != v_dled_distances.size())
		b_generate_report = true;
	else
	{
		b_generate_report = false;
		for (int ii = 0; (ii < v_dled_distances_old.size()) && (b_generate_report == false); ii++)
		{
			if  (v_dled_distances_old.at(ii).iCoverTotal != v_dled_distances.at(ii).iCoverTotal)  b_generate_report = true;
		}//for (int ii = 0; (ii < v_dled_distances_old.size()) && (b_generate_report == false); ii++)
	}//else  if (v_dled_distances_old.size() != v_dled_distances.size())
	



	if (b_generate_report == true)
	{
		CString  s_line;

		for (int ii = 0; ii < v_dled_distances.size(); ii++)
			s_line += v_dled_distances.at(ii).sGetAsStringShort() + "\t";

		s_buf.Format("distances:\t %d\t", v_dled_distances.size());
		s_line = s_buf + s_line;

		d_psa_update_last_time_time = c_optimizer_timer.dGetTimePassed();
		d_psa_update_last_time_ffe = (double)pc_problem->pcGetEvaluation()->iGetFFE();
		s_buf.Format
		(
			"\t [time: %.8lf] [FFE:%.0lf]",
			d_psa_update_last_time_time, d_psa_update_last_time_ffe
		);

		s_line += s_buf;
		pc_log->vPrintLine(s_line, true);
	}//if (b_generate_report == true)
		

	b_update_best_individual(iIterationNumber, pc_ind_test->piGetGenotype(), pc_ind_test->dComputeFitness());


	return(true);
}//bool CProblemStructAnal_DLED::bRunIteration(uint32_t iIterationNumber, time_t tStartTime)




CString  CProblemStructAnal_DLED::sAdditionalSummaryInfo()
{
	CString  s_line;

	s_line.Format(" {ProblDecompLastUpdateTime} \t %.0lf \t {ProblDecompLastUpdateFFE} \t %.0lf \t %s \t %d \t", d_psa_update_last_time_time, d_psa_update_last_time_ffe, OPT_LINK_QUALITY_MAX_HOP, v_dled_distances.size());
	for (int ii = 0; ii < v_dled_distances.size(); ii++)
		s_line += v_dled_distances.at(ii).sGetAsStringShort() + "\t";

	return(s_line);
};//CString  CProblemStructAnal_DLED::sAdditionalSummaryInfo() 



double CProblemStructAnal_DLED::dComputeFitness(int32_t *piBits)
{
	double d_fitness_value = d_compute_fitness_value(piBits);
	return(d_fitness_value);
}//double CProblemStructAnal_DLED::dComputeFitness(int32_t *piBits)



 //---------------------------------------------CProblemStructAnal_Ind-------------------------------------------------------
CProblemStructAnal_Ind::CProblemStructAnal_Ind(int  iTemplLength, CProblem<CBinaryCoding, CBinaryCoding > *pcProblem, CProblemStructAnal_DLED  *pcParent)
{
	i_templ_length = iTemplLength;
	pc_parent = pcParent;

	pi_genotype = new int[i_templ_length];

	pc_problem = pcProblem;

	d_fitnes_buf = -1;
	b_fitness_actual = false;

	vRandomizeGenotype();
}//CProblemStructAnal_Ind::CProblemStructAnal_Ind(int iLevel, int  iTemplLength, CProblem<CBinaryCoding, CBinaryCoding > *pcProblem, CProblemStructAnal_DLED  *pcParent)


CProblemStructAnal_Ind::CProblemStructAnal_Ind(CProblemStructAnal_Ind &pcOther)
{
	::Tools::vShow("No implementation: C3LOscrappedIndividual::C3LOscrappedIndividual(C3LOscrappedIndividual &pcOther) ");
};//CProblemStructAnal_Ind::CProblemStructAnal_Ind(CProblemStructAnal_Ind &pcOther)


CProblemStructAnal_Ind::~CProblemStructAnal_Ind()
{
	delete  pi_genotype;
};//CProblemStructAnal_Ind::~CProblemStructAnal_Ind()


void  CProblemStructAnal_Ind::vCopyFrom(CProblemStructAnal_Ind  *pcOther)
{
	this->pc_parent = pcOther->pc_parent;
	this->i_templ_length = pcOther->i_templ_length;
	this->v_opt_order = pcOther->v_opt_order;
	this->d_fitnes_buf = pcOther->d_fitnes_buf;
	this->b_fitness_actual = pcOther->b_fitness_actual;
	this->i_level = pcOther->i_level;
	this->pc_problem = pcOther->pc_problem;


	for (int ii = 0; ii < i_templ_length; ii++)
		pi_genotype[ii] = pcOther->pi_genotype[ii];

}//void  CProblemStructAnal_Ind::vCopyFrom(CProblemStructAnal_Ind  *pcOther)



bool  CProblemStructAnal_Ind::bIsTheSame(CProblemStructAnal_Ind  *pcOther)
{
	if ((pi_genotype == NULL))  return(false);
	if ((pcOther->pi_genotype == NULL))  return(false);

	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (pi_genotype[ii] != pcOther->pi_genotype[ii])  return(false);
	}//for  (int  ii = 0; ii < i_templ_length;  ii++)

	return(true);
}//bool  CProblemStructAnal_Ind::bIsTheSame(CProblemStructAnal_Ind  *pcOther)



double  CProblemStructAnal_Ind::dGetSimilarity(CProblemStructAnal_Ind  *pcOther, int  *piGenesTheSame)
{
	int  i_genes_the_same;
	if (piGenesTheSame == NULL)  piGenesTheSame = &i_genes_the_same;
	*piGenesTheSame = 0;

	if ((pi_genotype == NULL))  return(0);
	if ((pcOther->pi_genotype == NULL))  return(0);


	for (int ii = 0; ii < i_templ_length; ii++)
	{
		if (pi_genotype[ii] == pcOther->pi_genotype[ii])  (*piGenesTheSame)++;
	}//for  (int  ii = 0; ii < i_templ_length;  ii++)

	double  d_res;
	d_res = *piGenesTheSame;
	d_res = d_res / i_templ_length;

	return(d_res);
}//double  CProblemStructAnal_Ind::dGetSimilarity(CProblemStructAnal_Ind  *pcOther, int  *piGenesTheSame)


void  CProblemStructAnal_Ind::vRandomizeGenotype()
{
	d_fitnes_buf = -1;
	b_fitness_actual = false;

	for (int ii = 0; ii < i_templ_length; ii++)
		pi_genotype[ii] = RandUtils::iRandNumber(0, 1);

};//void  CProblemStructAnal_Ind::vRandomizeGenotype()


double  CProblemStructAnal_Ind::dComputeFitness()
{
	if (b_fitness_actual == true)  return(d_fitnes_buf);

	d_fitnes_buf = pc_parent->dComputeFitness(pi_genotype);
	b_fitness_actual = true;

	return(d_fitnes_buf);
};//double  CProblemStructAnal_Ind::dComputeFitness()


double  CProblemStructAnal_Ind::dComputeFitnessOptimize(vector<int>  *pvOrder /*= NULL*/)
{
	CString  s_buf;

	if (pvOrder == NULL)  pvOrder = &v_opt_order;
	if (pvOrder->size() != i_templ_length)  v_create_opt_order(pvOrder);


	int  i_opt_gene;
	int  i_orig_gene_val;
	bool  b_changed;

	b_changed = true;

	//::Tools::vShow("IN");


	int  i_opt_counter = 0;
	while (b_changed == true)
	{
		//double  d_start, d_end;
		//d_start = dComputeFitness();

		i_opt_counter++;
		b_changed = false;
		for (int ii = 0; ii < pvOrder->size(); ii++)
		{
			i_opt_gene = pvOrder->at(ii);
			i_orig_gene_val = pi_genotype[i_opt_gene];

			d_optimize_single_gene(i_opt_gene);

			if (i_orig_gene_val != pi_genotype[i_opt_gene])  b_changed = true;
		}//for  (int  i_opt_traj = 0; i_opt_traj < i_number_of_pairs; i_opt_traj++)

		//d_end = dComputeFitness();
		//s_buf.Format("%.8lf -> %.8lf", d_start, d_end);
		//::Tools::vShow(s_buf);
	}//while (b_changed == true)

	//::Tools::vShow(i_opt_counter);


	return(dComputeFitness());
};//double  CProblemStructAnal_Ind::dComputeFitnessOptimize(vector<int>  *pvOrder /*= NULL*/)



void  CProblemStructAnal_Ind::v_create_opt_order(vector<int>  *pvOrder)
{
	vector<int>  v_temp;

	pvOrder->clear();

	for (int ii = 0; ii < i_templ_length; ii++)
		v_temp.push_back(ii);

	int  i_pos;
	while (v_temp.size() > 0)
	{
		i_pos = RandUtils::iRandNumber(0, v_temp.size() - 1);
		pvOrder->push_back(v_temp.at(i_pos));
		v_temp.erase(v_temp.begin() + i_pos);
	}//while  (v_temp.size() > 0)
}//void  CProblemStructAnal_Ind::v_create_opt_order(vector<int>  *pvOrder)



double  CProblemStructAnal_Ind::d_optimize_single_gene(int  iOptGene)
{
	double  d_fitness_current, d_fit_new;
	d_fitness_current = dComputeFitness();

	if (pi_genotype[iOptGene] == 1)
		pi_genotype[iOptGene] = 0;
	else
		pi_genotype[iOptGene] = 1;

	b_fitness_actual = false;
	d_fit_new = dComputeFitness();

	if (d_fit_new > d_fitness_current)  return(d_fit_new);


	//flip back...
	if (pi_genotype[iOptGene] == 1)
		pi_genotype[iOptGene] = 0;
	else
		pi_genotype[iOptGene] = 1;
	b_fitness_actual = true;
	this->d_fitnes_buf = d_fitness_current;

	return(this->d_fitnes_buf);
};//double  CProblemStructAnal_Ind::d_optimize_single_gene(int  iOptGene)



