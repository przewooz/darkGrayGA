#include "PermutationCoding.h"

CPermutationCoding::CPermutationCoding(uint16_t iSize)
	: CPermutationCoding(iSize, new int32_t[iSize], true)
{

}//CPermutationCoding::CPermutationCoding(uint16_t iSize)

CPermutationCoding::CPermutationCoding(uint16_t iSize, int32_t *piPermutation, bool bOwnPermutation)
{
	i_size = iSize;
	pi_permutation = piPermutation;
	b_own_permutation = bOwnPermutation;
}//CPermutationCoding::CPermutationCoding(uint16_t iSize, int32_t *piPermutation, bool bOwnPermutation)

CPermutationCoding::CPermutationCoding(CPermutationCoding *pcOther)
{
	i_size = pcOther->i_size;

	pi_permutation = new int32_t[pcOther->i_size];

	for (uint16_t i = 0; i < i_size; i++)
	{
		*(pi_permutation + i) = *(pcOther->pi_permutation + i);
	}//for (uint16_t i = 0; i < i_size; i++)

	b_own_permutation = true;
}//CPermutationCoding::CPermutationCoding(CPermutationCoding *pcOther)

CPermutationCoding::~CPermutationCoding()
{
	if (b_own_permutation)
	{
		delete pi_permutation;
	}//if (b_own_permutation)
}//CPermutationCoding::~CPermutationCoding()

void CPermutationCoding::vMerge(CPermutationCoding *pcOther)
{
	i_size += pcOther->iGetSize();
	vSetPermutation(new int32_t[i_size], true);
}//void CPermutationCoding::vMerge(CPermutationCoding *pcOther)

void CPermutationCoding::vSetPermutation(int32_t *piPermutation, bool bOwnPermutation)
{
	if (b_own_permutation)
	{
		delete pi_permutation;
	}//if (b_own_permutation)

	pi_permutation = piPermutation;
	b_own_permutation = bOwnPermutation;
}//void CPermutationCoding::vSetPermutation(int32_t *piPermutation, bool bOwnPermutation)

CString CPermutationCoding::sToString()
{
	CString s_result;

	s_result.Append("[");

	for (uint16_t i = 0; i < i_size; i++)
	{
		s_result.AppendFormat("%d", *(pi_permutation + i));

		if (i + 1 < i_size)
		{
			s_result.Append(", ");
		}//if (i + 1 < i_size)
	}//for (uint16_t i = 0; i < i_number_of_dimensions; i++)

	s_result.Append("]");

	return s_result;
}//CString CPermutationCoding::sToString()

bool CPermutationCoding::operator==(CPermutationCoding &cOther)
{
	bool b_equal = true;

	for (uint16_t i = 0; i < i_size && b_equal; i++)
	{
		b_equal &= *(pi_permutation + i) == *(cOther.pi_permutation + i);
	}//for (uint16_t i = 0; i < i_size && b_equal; i++)

	return b_equal;
}//bool CPermutationCoding::operator==(CPermutationCoding &cOther)

bool CPermutationCoding::operator!=(CPermutationCoding &cOther)
{
	return !(*this == cOther);
}//bool CPermutationCoding::operator!=(CPermutationCoding &cOther)

ostream & operator<<(ostream &sOutput, CPermutationCoding *pcPermutationCoding)
{
	sOutput << pcPermutationCoding->sToString();

	return sOutput;
}//ostream & operator<<(ostream &sOutput, CPermutationCoding *pcPermutationCoding)