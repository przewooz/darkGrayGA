#ifndef CMO_EM_PF_DEC_OPTIMIZER_H
#define CMO_EM_PF_DEC_OPTIMIZER_H


#include "BinaryCoding.h"
#include "BinaryOptimizer.h"
#include "CommandParam.h"
#include "StringCommandParam.h"
#include "Error.h"
#include "Log.h"
#include "MathUtils.h"
#include "Optimizer.h"
#include "Problem.h"
#include  "util\timer.h"
#include  "util\tools.h"

#include "MultiObjectiveOptimizer.h"
#include "BinaryOptimizer.h"
#include "BinaryEvaluationMultiObjective.h"

#include "P3.h"
#include "../P3/Pyramid.h"

#include <atlstr.h>
#include <cstdint>
#include <ctime>
#include <istream>

#include <istream>
#include <algorithm>



namespace EmPfDec
{

	class   CEmPFDec_Individual;
	class  CEmPFDec_Ordering;
	class  CEmPFDec_DirectedOptimizer;
	class  CEmPFDec_DirectedLastResult;

	#define EMPIRICAL_PF_DECOMPOSER_ARGUMENT_ORDERING_INDIVIDUALS_NUMBER "ordering_individuals_number"
	#define EMPIRICAL_PF_DECOMPOSER_ARGUMENT_ORDERINGS_NUMBER "orderings_number"
	#define EMPIRICAL_PF_DECOMPOSER_ARGUMENT_DECOMPOSITION_TYPE "decomposition_type"

	#define EMPIRICAL_PF_DECOMPOSER_DECOMPOSITION_TYPE_UNIFORM_TEXT "uniform"
	#define EMPIRICAL_PF_DECOMPOSER_DECOMPOSITION_TYPE_EMPIRICAL_TEXT "empirical"

	#define EMPIRICAL_PF_DECOMPOSER_DECOMPOSITION_TYPE_UNIFORM 0
	#define EMPIRICAL_PF_DECOMPOSER_DECOMPOSITION_TYPE_EMPIRICAL 1

	class  CMO_EmPfDec : public CBinaryMultiObjectiveOptimizer  //CBinaryOptimizer
	{
	public:
		static uint32_t iERROR_PARENT_CMO_EmPfDec_Optimizer;
		static uint32_t iERROR_CODE_CMO_EmPfDec_GENOTYPE_LEN_BELOW_0;
		static uint32_t iERROR_CODE_CMO_EmPfDec_UNKNOWN_DECOMPOSITION_TYPE;


		CMO_EmPfDec(CProblem<CBinaryCoding, CBinaryCoding>* pcProblem, CLog * pcLog, uint32_t iRandomSeed);
		CMO_EmPfDec(CMO_EmPfDec *pcOther);
		~CMO_EmPfDec();


		virtual COptimizer<CBinaryCoding, CBinaryCoding> *pcCopy() { return new CMO_EmPfDec(this); };

		virtual CError eConfigure(istream *psSettings);

		virtual void vInitialize();
		virtual bool bRunIteration(uint32_t iIterationNumber);
		bool bRunIteration_test_vector(uint32_t iIterationNumber);
		bool bRunIteration_dummy(uint32_t iIterationNumber);


	private:
		bool b_update_best_individual(uint32_t iIterationNumber);

		void  v_generate_ordering_individuals(int iOrderingIndividualsNumber);
		void  v_generate_orderings(int iMaxOrderingsNumnber);
		void  v_generate_orderings_empirical(int iMaxOrderingsNumnber);
		void  v_generate_orderings_uniform(int iMaxOrderingsNumnber);
		void  v_generate_directed_populations();
		void  v_generate_directed_populations_simple();
		void  v_compute_cumulative_distributions_and_create_a_new_pop();


		void  v_add_pop_ordering(CBinaryMultiObjectiveProblem  *pc_multi_problem, vector<CEmPFDec_Ordering*>  *pvPopOrderings, vector<CEmPFDec_Individual *>  *pvDecompositionPopulation, double  dWeight0, double dWeight1);


		TimeCounters::CTimeCounter  c_time_counter;
		
		int  i_ordering_individuals_number;
		int  i_orderings_number;
		int  i_decomposition_type;

		int  i_templ_length;

		CP3  *pc_clear_p3;

		vector<CEmPFDec_DirectedOptimizer *>  v_directed_optimizers;
		vector<int>  v_improved_pf_tool;
		int  i_pop_p3_number;

		bool  b_pops_unlocked;
		int  i_pops_analysis_frequency;
		int  i_pops_analysis_remaining_iters;



		vector<CEmPFDec_Individual *>  v_decomposition_population;
		vector<CEmPFDec_Ordering*>  v_pop_orderings;


	};//class  CMO_EmPfDec : public CBinaryMultiObjectiveOptimizer  //CBinaryOptimizer



	class  CEmPFDec_DirectedOptimizer
	{
		friend class CMO_EmPfDec;
	public:
		CEmPFDec_DirectedOptimizer(CP3  *pcClearP3, CBinaryMultiObjectiveProblem  *pcProblem, CMO_EmPfDec  *pcParent);
		~CEmPFDec_DirectedOptimizer();
		
		void vInitialize();
		bool bRunIteration(uint32_t iIterationNumber);

		CString  sToString();
		CString  sToStringSimple();
		CString  sToStringRange();


		CIndividual<CBinaryCoding, CBinaryCoding> *pcGetBestIndividual() { return(pc_best); };

		void  vComputeCumulativeDistribution();
		void  vUpgradeCumulativeDistribution();
		void  vReportCumulativeDistribution();
		void  vDeleteLastResults();
		void  vUpdateDirections();

		int  iCumDistr_GetLastResultOffset(double  dWeight);
		void  vCumDistrGetMin(CEmPFDec_DirectedOptimizer *pcOther, CEmPFDec_DirectedLastResult  *pcDirection);
		double  dCumDistrGetMiddleWeight();
		double  dCumDistrGet(double  dWeight);

	private:
		void  v_report_weights_cumulative_distribution();

		CMO_EmPfDec  *pc_parent;
		CBinaryMultiObjectiveProblem  *pc_problem;
		CP3  *pc_p3;

		vector<CEmPFDec_DirectedLastResult*>  v_last_results;
		CIndividual<CBinaryCoding, CBinaryCoding>  *pc_best;

		double  d_weight_0_start, d_weight_0_direction, d_weight_0_end;
		double  d_weight_1_start, d_weight_1_direction, d_weight_1_end;
	};//class  CEmPFDec_DirectedOptimizer


	class  CEmPFDec_DirectedLastResult
	{
		friend class CEmPFDec_DirectedOptimizer;
		friend class CMO_EmPfDec;
	public:
		CEmPFDec_DirectedLastResult(CBinaryMultiObjectiveProblem  *pcProblem, CEmPFDec_DirectedOptimizer *pcParent);
		~CEmPFDec_DirectedLastResult();

		void  vSetGenotype(vector<bool>  *pvGenotype);
		void  vComputeObjAndWeights();

	private:
		CEmPFDec_DirectedOptimizer *pc_parent;
		CBinaryMultiObjectiveProblem  *pc_problem;

		CBinaryCoding *pc_genotype;

		vector<double>  v_objectives;
		vector<double>  v_weights;

		double  d_cumulative_distribution;


	};//class  CEmPFDec_DirectedLastResult



	class  CEmPFDec_Ordering
	{
	public:
		CEmPFDec_Ordering(CBinaryMultiObjectiveProblem  *pcMultiProblem, vector<CEmPFDec_Individual *>  *pvPopulationOrder);
		~CEmPFDec_Ordering() {};

		double  d_weight_0;
		double  d_weight_1;


		CString  sToString();
		void  vGetPopOrder();
		int  iCompare(CEmPFDec_Ordering *pcOther);

	private:
		CBinaryMultiObjectiveProblem  *pc_multi_problem;

		vector<CEmPFDec_Individual *>  v_population_order;//ll
	};



    #define EMPF_IND_DEBUG true

	class  CEmPFDec_Individual
	{
		friend class  CMO_EmPfDec;
		friend class  CEmPFDec_Ordering;
	public:
		CEmPFDec_Individual(int  iTemplLength, CProblem<CBinaryCoding, CBinaryCoding > *pcProblem, CMO_EmPfDec  *pcParent);
		CEmPFDec_Individual(const CEmPFDec_Individual &pcOther);
		~CEmPFDec_Individual();

		CString  sToString();

		double  dGetFitness();
		double  dReevaluate(bool  bOptimizePhenotype = true);

		void  vRandomInit();
		void  vRandomInitGenotype();
		void  vRandomInitOptOrder();

	private:
		void  v_optimize_phenotype();

		CProblem<CBinaryCoding, CBinaryCoding > *pc_problem;
		CBinaryMultiObjectiveProblem  *pc_multi_problem;
		vector<CMultiObjectiveMeasure*>  *pv_mesaures;

		CMO_EmPfDec  *pc_parent;
		vector<int> v_optimization_order;
		
		//data
		int  i_templ_length;
		CBinaryCoding *pc_genotype;
		CBinaryCoding *pc_phenotype;

		double  d_fitness;
		bool  b_fit_actual;

	};//class  CEmPFDec_Individual


}//namespace EmPfDec


#endif//C3LO_OPTIMIZER_H
