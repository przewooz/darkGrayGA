#pragma once

#include <vector>
#include <unordered_map>
using namespace std;

#include "cGomea_utils.h"
//#include "cGomea_time.h"
#include "cGomea_FOS.h"

struct C_CGomea_sharedInformation
{
	double numberOfEvaluations;
	long long startTimeMilliseconds;
	double elitistSolutionHittingTimeMilliseconds,
	       elitistSolutionHittingTimeEvaluations;

	C_CGomea_Individual elitist;
	C_CGomea_solutionsArchive *evaluatedSolutions;
	bool firstEvaluationEver;

	C_CGomea_Pyramid *pyramid;
	vector<C_CGomea_FOS* > FOSes;
	
	C_CGomea_sharedInformation(int maxArchiveSize)
	{
		numberOfEvaluations = 0;
		//startTimeMilliseconds = getCurrentTimeStampInMilliSeconds();
		firstEvaluationEver = true;
		evaluatedSolutions = new C_CGomea_solutionsArchive(maxArchiveSize);
		pyramid = new C_CGomea_Pyramid();
	}

	~C_CGomea_sharedInformation()
	{
		delete evaluatedSolutions;
		delete pyramid;
	}
};