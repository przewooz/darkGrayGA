#ifndef DETERMINISTIC_OPTIMIZER_CHANGE_DETECTOR_H
#define DETERMINISTIC_OPTIMIZER_CHANGE_DETECTOR_H

#define DETERMINISTIC_OPTIMIZER_CHANGE_DETECTOR_ARGUMENT_FRACTION_OF_SENSORS_TO_CLUSTERING "fraction_of_sensors_to_clustering"

#define DETERMINISTIC_OPTIMIZER_CHANGE_DETECTOR_ARGUMENT_STORE_FREQUENCY "store_frequency"

#include "Error.h"
#include "KMeansClustering.h"
#include "Log.h"
#include "Problem.h"
#include "RealCoding.h"
#include "RealLocalReducingOptimizer.h"
#include "SensorChangeDetector.h"
#include "PopulationOptimizer.h"

#include <cstdint>
#include <istream>
#include <vector>

using namespace Clustering;

using namespace std;


namespace ChangeDetector
{
	class CDeterministicOptimizerChangeDetector : public CSensorChangeDetector<CRealCoding, CRealCoding>
	{
	public:
		CDeterministicOptimizerChangeDetector(CProblem<CRealCoding, CRealCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed);
		
		virtual ~CDeterministicOptimizerChangeDetector();

		virtual CError eConfigure(istream *psSettings);

		virtual void vInitialize();
		virtual void vRun();

	protected:
		virtual bool b_detect_change();

		void v_clear_params();

	private:
		void v_clustering();

		void v_clear_population_optimizer_sensors();
		void v_set_population_optimizer_sensors();

		uint32_t i_random_seed;

		uint32_t i_store_frequency;

		float f_fraction_of_sensors_to_clustering;

		vector<CIndividual<CRealCoding, CRealCoding>*> *pv_population_optimizer_sensors;

		CKMeansClustering c_kmeans;
		CRealLocalReducingOptimizer c_local_optimizer;
		CPopulationOptimizer<CRealCoding, CRealCoding> *pc_population_optimizer;

		uint32_t i_sensor_detection_counter;
		uint32_t i_population_optimizer_detection_counter;
	};//class CDeterministicOptimizerChangeDetector : public CSensorChangeDetector<CRealCoding, CRealCoding>
}//namespace ChangeDetector

#endif//DETERMINISTIC_OPTIMIZER_CHANGE_DETECTOR_H