#ifndef CMAES_H
#define CMAES_H

#define CMAES_ARGUMENT_SIGMA "sigma"
#define CMAES_ARGUMENT_IS_SEP "is_sep"
#define CMAES_ARGUMENT_IS_VD "is_vd"

#include "CommandParam.h"
#include "Error.h"
#include "Evaluation.h"
#include "FloatCommandParam.h"
#include "Log.h"
#include "Optimizer.h"
#include "RealCoding.h"
#include "RealRandomGeneration.h"

#include "../libcmaes-0.9.5/acovarianceupdate.h"
#include "../libcmaes-0.9.5/bipopcmastrategy.h"
#include "../libcmaes-0.9.5/cmaparameters.h"
#include "../libcmaes-0.9.5/cmasolutions.h"
#include "../libcmaes-0.9.5/cmastrategy.h"
#include "../libcmaes-0.9.5/covarianceupdate.h"
#include "../libcmaes-0.9.5/esoptimizer.h"
#include "../libcmaes-0.9.5/esostrategy.h"
#include "../libcmaes-0.9.5/genopheno.h"
#include "../libcmaes-0.9.5/ipopcmastrategy.h"
#include "../libcmaes-0.9.5/pwq_bound_strategy.h"
#include "../libcmaes-0.9.5/vdcmaupdate.h"

#include <cfloat>
#include <ctime>
#include <cstdint>
#include <istream>
#include <vector>

using namespace libcmaes;

using namespace std;

template <class TESOStrategy>
class CCMAES : public COptimizer<CRealCoding, CRealCoding>
{
public:
	CCMAES(CProblem<CRealCoding, CRealCoding> *pcProblem, CLog *pcLog, uint32_t iRandomSeed);
	CCMAES(CCMAES<TESOStrategy> *pcOther);

	virtual ~CCMAES();

	virtual CError eConfigure(istream *psSettings);

	virtual COptimizer<CRealCoding, CRealCoding> *pcCopy() { return new CCMAES<TESOStrategy>(this); };

	virtual void vInitialize(time_t tStartTime);
	virtual bool bRunIteration(uint32_t iIterationNumber, time_t tStartTime);

private:
	void v_init();

	void v_create_cmaes();
	void v_clear_cmaes();

	using COptimizer<CRealCoding, CRealCoding>::b_update_best_individual;
	bool b_update_best_individual(uint32_t iIterationNumber, time_t tStartTime);

	ESOptimizer<TESOStrategy, CMAParameters<GenoPheno<pwqBoundStrategy>>> *pc_cmaes;

	CIndividual<CRealCoding, CRealCoding> *pc_candidate_individual;

	float f_sigma;
	bool b_is_sep;
	bool b_is_vd;
};//class CCMAES : public COptimizer<CRealCoding, CRealCoding>

#endif//CMAES_H