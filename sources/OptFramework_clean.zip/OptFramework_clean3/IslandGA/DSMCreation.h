#ifndef DSM_CREATION_H
#define DSM_CREATION_H

#define DSM_CREATION_TYPE "dsm_creation_type"
#define DSM_CREATION_TYPE_REAL_SURFACE_AREA "real_surface_area"
#define DSM_CREATION_TYPE_REAL_MUTUAL_INFORMATION "real_mutual_information"
#define DSM_CREATION_TYPE_RANDOM "random"

#define SURFACE_AREA_DSM_CREATION_ARGUMENT_DYNAMIC_MIN_MAX "dynamic_min_max"

#include "BinaryCoding.h"
#include "Error.h"
#include "Log.h"
#include "RealCoding.h"

#include <cstdint>
#include <iostream>

using namespace std;

namespace Linkage
{
	template <class TGenotype>
	class CDSMCreation
	{
	public:
		CDSMCreation(uint16_t iNumberOfElements, CLog *pcLog);

		virtual ~CDSMCreation();

		virtual CError eConfigure(istream *psSettings) { return CError(); };

		double **ppdCreateEmptyDSM();
		double **ppdCreateDSM(TGenotype **ppcGenotypes, uint32_t iNumberOfGenotypes);
		
		virtual void vFillDSM(TGenotype **ppcGenotypes, uint32_t iNumberOfGenotypes, double **ppdDSM);

	protected:
		virtual double d_calculate_dependency(TGenotype **ppcGenotypes, uint32_t iNumberOfGenotypes, uint16_t iIndex0, uint16_t iIndex1) = 0;

		uint16_t i_number_of_elements;
		
		CLog *pc_log;
	};//class CDSMCreation


	class CBucketDSMCreation : public CDSMCreation<CRealCoding>
	{
	public:
		CBucketDSMCreation(uint16_t iNumberOfElements, CLog *pcLog);

		virtual CError eConfigure(istream *psSettings);

		virtual void vFillDSM(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes, double **ppdDSM);

	protected:
		virtual double d_calculate_dependency(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes, uint16_t iIndex0, uint16_t iIndex1) = 0;

		void v_fill_bucket_indexes(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes, uint16_t iIndex0, uint16_t iIndex1);

		uint32_t i_number_of_buckets_per_element;
		uint32_t *pi_buckets_indexes;

	private:
		void v_calculate_min_and_max(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes, uint16_t iIndex, double *pdMin, double *pdMax);
		void v_calculate_min_and_step(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes, uint16_t iIndex, double *pdMin, double *pdStep);
		double d_calculate_value(CRealCoding *pcGenotype, uint16_t iIndex, double dMin);

		uint32_t i_calculate_bucket_element_index(double dValue, double dStep);
		uint32_t i_calculate_bucket_index(double dValue0, double dValue1, double dStep0, double dStep1);

		bool b_dynamic_min_max;
	};//class CBucketDSMCreation : public CDSMCreation<CRealCoding>


	class CSurfaceAreaDSMCreation : public CBucketDSMCreation
	{
	public:
		CSurfaceAreaDSMCreation(uint16_t iNumberOfElements, CLog *pcLog);

	protected:
		virtual double d_calculate_dependency(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes, uint16_t iIndex0, uint16_t iIndex1);

	private:
		uint32_t i_calculate_number_of_nonempty_buckets_indexes(uint32_t iNumberOfGenotypes);
	};//class CSurfaceAreaDSMCreation : public CBucketDSMCreation


	class CBiggestBucketDSMCreation : public CBucketDSMCreation
	{
	public:
		CBiggestBucketDSMCreation(uint16_t iNumberOfElements, CLog *pcLog);

	protected:
		virtual double d_calculate_dependency(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes, uint16_t iIndex0, uint16_t iIndex1);

	private:
		uint32_t i_calculate_size_of_biggest_bucket_index(uint32_t iNumberOfGenotypes);
	};//class CBiggestBucketDSMCreation : public CBucketDSMCreation


	class CRealMutualInformationDSMCreation : public CDSMCreation<CRealCoding>
	{
	public:
		CRealMutualInformationDSMCreation(uint16_t iNumberOfElements, CLog *pcLog);

		virtual void vFillDSM(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes, double **ppdDSM);

	protected:
		virtual double d_calculate_dependency(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes, uint16_t iIndex0, uint16_t iIndex1);

	private:
		void v_create_covariance_matrix(CRealCoding **ppcGenotypes, uint32_t iNumberOfGenotypes);

		double **ppd_covariance_matrix;
	};//class CRealMutualInformationDSMCreation : public CDSMCreation<CRealCoding>


	template <class TGenotype>
	class CRandomDSMCreation : public CDSMCreation<TGenotype>
	{
	public:
		CRandomDSMCreation(uint16_t iNumberOfElements, CLog *pcLog);

	protected:
		virtual double d_calculate_dependency(TGenotype **ppcGenotypes, uint32_t iNumberOfGenotypes, uint16_t iIndex0, uint16_t iIndex1);
	};//class CRandomDSMCreation : public CDSMCreation<TGenotype>


	namespace DSMCreationUtils
	{
		template <class TGenotype>
		CDSMCreation<TGenotype> *pcGetDSMCreation(istream *psSettings, uint16_t iNumberOfElements, CLog *pcLog, CError *pcError, bool bIsObligatory = true);
	}//namespace DSMCreationUtils
}//namespace Linkage

#endif//DSM_CREATION_H